/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
/*
 * IPTV 浏览器执行端 · 后台 Service Worker（Manifest V3）
 *
 * 它干三件事：
 *   1. 每 30 秒向本机执行端 http://127.0.0.1:3212 领任务（chrome.alarms 驱动）；
 *   2. 按任务里的服务器，把动作转发给对应面板标签页里的 content script；
 *   3. 把执行结果回传本机执行端，并把最近状态写进 chrome.storage.local 给弹窗看。
 *
 * 所有本机请求都带 X-Local-Key（用户在弹窗里粘贴的连接码）。
 */
import { serverById, serverForUrl } from "./server-registry.mjs";
import { planChannels } from "./channel-plan.mjs";
import { runStrong } from "./strong-worker.mjs";
import { runLion } from "./lion-worker.mjs";
import { runClassic } from "./classic-worker.mjs";
import { sessionNames } from "./session-health.mjs";
let magJobRunning = false;
const sleep = delayMs => new Promise(resolveDelay => setTimeout(resolveDelay, delayMs));
// 给面板页发登录守卫指令；如果页面还没注入过守卫，就先注入 session-guard.js 再重试一次。
async function callSessionGuard(tabId, serverId, action) {
  const guardMessage = {
    type: "iptv-session-guard",
    server: serverId,
    action: action
  };
  try {
    return await chrome.tabs.sendMessage(tabId, guardMessage);
  } catch (sendError) {
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId: tabId
        },
        files: ["session-guard.js"]
      });
    } catch {
      throw Error("session_guard_unavailable", {
        cause: sendError
      });
    }
    try {
      return await chrome.tabs.sendMessage(tabId, guardMessage);
    } catch {
      throw Error("session_guard_unavailable", {
        cause: sendError
      });
    }
  }
}
// 本机桥请求：有 body 用 POST，没有用 GET；默认 12 秒超时，超时算失败。
async function bridgeFetch(binding, path, body, timeoutMs = 12000) {
  const response = await fetch("http://127.0.0.1:3212" + path, {
    method: body ? "POST" : "GET",
    headers: {
      "X-Local-Key": binding.key,
      ...(body ? {
        "Content-Type": "application/json"
      } : {})
    },
    ...(body ? {
      body: JSON.stringify(body)
    } : {}),
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!response.ok) {
    throw Error("本机连接失败 " + response.status);
  }
  return response.json();
}
// 取 MEGA 标签页；如果标签已经被导航到别的站点，直接报错，避免在错误页面上瞎点。
async function getMegaTab(binding) {
  const tab = await chrome.tabs.get(binding.tabId);
  if (!tab.url?.startsWith("https://megaott.net/")) {
    throw Error("绑定标签已离开 MegaOTT；请重新绑定");
  }
  return tab;
}
// 给 MEGA 页面助手发指令，消息类型固定为 iptv-command。
async function sendMegaCommand(binding, action, args = {}) {
  await getMegaTab(binding);
  const reply = await chrome.tabs.sendMessage(binding.tabId, {
    type: "iptv-command",
    action: action,
    args: args
  });
  if (!reply?.ok) {
    throw Error(reply?.error || "页面助手未就绪");
  }
  return reply.result;
}
// 给 MEGA 的 MAG 页面助手发指令，消息类型固定为 iptv-mega-mag-command。
async function sendMagCommand(binding, action, args = {}) {
  await getMegaTab(binding);
  const reply = await chrome.tabs.sendMessage(binding.tabId, {
    type: "iptv-mega-mag-command",
    action: action,
    args: args
  });
  if (!reply?.ok) {
    throw Error(reply?.error || "MAG 页面助手未就绪");
  }
  return reply.result;
}
// 轮询等待 MEGA 页面加载到指定路径，并确认页面助手能应答 ping（最长 25 秒）。
async function waitForMegaPageReady(binding, pathname) {
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    const tab = await getMegaTab(binding);
    if (tab.status === "complete" && new URL(tab.url).pathname === pathname) {
      try {
        await sendMegaCommand(binding, "ping");
        return;
      } catch {}
    }
    await sleep(250);
  }
  throw Error("后台页面加载失败或需要登录");
}
// 跳到 MEGA 的某个路径，然后等页面就绪。
async function navigateMega(binding, path) {
  await getMegaTab(binding);
  await chrome.tabs.update(binding.tabId, {
    url: "https://megaott.net" + path
  });
  await waitForMegaPageReady(binding, path.split("?")[0]);
}
// 已经在目标页面就不跳，省一次刷新；否则跳过去。
async function ensureMegaPage(binding, path) {
  const tab = await getMegaTab(binding);
  if (tab.status === "complete" && new URL(tab.url).pathname === path.split("?")[0]) {
    try {
      await sendMegaCommand(binding, "ping");
      return;
    } catch {}
  }
  await navigateMega(binding, path);
}
// 等 MAG 页面就绪。必须 documentToken 变了才算真的换了页面，
// 防止单页应用里 URL 没变但内容还是旧的，导致在旧页面上操作。
async function waitForMagPageReady(binding, path, previousToken = null) {
  const targetUrl = new URL("https://megaott.net" + path);
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    const tab = await getMegaTab(binding);
    if (new URL(tab.url).href === targetUrl.href) {
      try {
        const reply = await sendMagCommand(binding, "ping");
        if (reply.version === "0.4.12" && typeof reply.documentToken == "string" && reply.documentToken && (!previousToken || reply.documentToken !== previousToken) && new URL(reply.url).href === targetUrl.href) {
          return;
        }
      } catch {}
    }
    await sleep(250);
  }
  throw Error("mega_mag_page_not_ready");
}
// 跳转 MAG 页面，并记下跳转前的 documentToken，交给 waitForMagPageReady 比对。
async function navigateMag(binding, path) {
  await getMegaTab(binding);
  let previousToken = null;
  try {
    const reply = await sendMagCommand(binding, "ping");
    if (typeof reply.documentToken == "string" && reply.documentToken) {
      previousToken = reply.documentToken;
    }
  } catch {}
  await chrome.tabs.update(binding.tabId, {
    url: "https://megaott.net" + path
  });
  await waitForMagPageReady(binding, path, previousToken);
}
// 提交后等页面离开当前路径，说明提交动作已经被面板受理。
async function waitForMagSubmitDone(binding, pathname) {
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    const tab = await getMegaTab(binding);
    if (new URL(tab.url).pathname !== pathname && tab.status === "complete") {
      try {
        await sendMagCommand(binding, "ping");
        return;
      } catch {}
    }
    await sleep(250);
  }
  throw Error("mega_mag_submit_result_unknown");
}
// 提交后等页面离开当前路径。超时直接报错，并且禁止自动重试，避免重复开号。
async function waitForSubmitDone(binding, pathname) {
  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    const tab = await getMegaTab(binding);
    if (new URL(tab.url).pathname !== pathname && tab.status === "complete") {
      await sendMegaCommand(binding, "ping");
      return;
    }
    await sleep(250);
  }
  throw Error("提交结果不明；禁止自动重试");
}
// 普通线路任务。按 job.action 分五种：
//   prepare  预检（打开新增页、读套餐）
//   inspect  读某个线路的详情
//   create   开新号：预检 → 配频道 → 提交 → 标记已派发 → 等结果 → 回查
//   recover  按 marker 找回已开的号，并核对归属
//   edit     改频道：核对账号 → 算差异 → 应用 → 提交 → 回查验证
async function runLinesJob(binding, job) {
  const args = job.args;
  if (job.action === "prepare") {
    await ensureMegaPage(binding, "/subscriptions/lines/add");
    return sendMegaCommand(binding, "prepare");
  }
  if (job.action === "inspect") {
    await navigateMega(binding, "/subscriptions/lines/" + args.id + "/edit");
    return sendMegaCommand(binding, "inspect", args);
  }
  if (job.action === "create") {
    await ensureMegaPage(binding, "/subscriptions/lines/add");
    const prepared = await sendMegaCommand(binding, "prepare");
    const plan = planChannels(prepared.catalog, args.operations || []);
    await sendMegaCommand(binding, "configure", {
      ...args,
      plan: plan
    });
    await sendMegaCommand(binding, "submit", {
      ...args,
      mode: "create"
    });
    try {
      await bridgeFetch(binding, "/dispatched", {
        id: job.id
      });
    } catch {}
    try {
      await waitForSubmitDone(binding, "/subscriptions/lines/add");
      const expiry = await sendMegaCommand(binding, "expiry");
      await navigateMega(binding, "/subscriptions/lines?filter_by_trial=all&search=" + encodeURIComponent(args.marker) + "&searchBy=note");
      return {
        ...(await sendMegaCommand(binding, "find", args)),
        ...expiry,
        descriptions: plan.descriptions
      };
    } catch (error) {
      error.writeDispatched = true;
      throw error;
    }
  }
  if (job.action === "recover") {
    await navigateMega(binding, "/subscriptions/lines?filter_by_trial=all&search=" + encodeURIComponent(args.marker) + "&searchBy=note");
    const found = await sendMegaCommand(binding, "find", args);
    await navigateMega(binding, "/subscriptions/lines/" + found.id + "/edit");
    const inspected = await sendMegaCommand(binding, "inspect", {
      ...args,
      id: found.id
    });
    if (inspected.username !== args.username || inspected.note !== args.marker) {
      throw Error("恢复账号归属核验失败");
    }
    return {
      id: String(found.id),
      username: inspected.username,
      note: inspected.note
    };
  }
  if (job.action === "edit") {
    const account = args.account;
    await navigateMega(binding, "/subscriptions/lines/" + account.id + "/edit");
    const inspected = await sendMegaCommand(binding, "inspect", account);
    if (inspected.username !== account.username || inspected.note !== account.marker) {
      throw Error("客户账号不匹配");
    }
    const plan = planChannels(inspected.catalog, args.operations || []);
    if (!plan.changed.length) {
      throw Error("没有需要更改的内容");
    }
    await sendMegaCommand(binding, "apply", {
      ...account,
      plan: plan
    });
    await sendMegaCommand(binding, "submit", {
      ...account,
      mode: "edit"
    });
    try {
      await bridgeFetch(binding, "/dispatched", {
        id: job.id
      });
    } catch {}
    try {
      await waitForSubmitDone(binding, "/subscriptions/lines/" + account.id + "/edit");
      await navigateMega(binding, "/subscriptions/lines/" + account.id + "/edit");
      await sendMegaCommand(binding, "inspect", account);
      await sendMegaCommand(binding, "verify", {
        plan: plan
      });
      return {
        updated: true,
        descriptions: plan.descriptions
      };
    } catch (error) {
      error.writeDispatched = true;
      throw error;
    }
  }
  throw Error("unsupported_job");
}
// MAG 线路任务（按 MAC 地址）。除了 prepare/inspect/create/recover/edit，
// 还会先查 MAC 是否已存在，存在就拒绝，避免重复开号。
async function runMagJob(binding, job) {
  const args = job.args;
  const searchPath = () => "/subscriptions/mag?filter_by_trial=all&search=" + encodeURIComponent(args.macAddress) + "&searchBy=mac_address";
  if (job.action === "prepare") {
    await navigateMag(binding, searchPath());
    if ((await sendMagCommand(binding, "lookup", args)).exists) {
      throw Error("mega_mag_mac_exists");
    }
    await navigateMag(binding, "/subscriptions/mag/add");
    return {
      ...(await sendMagCommand(binding, "prepare", args)),
      exists: false
    };
  }
  if (job.action === "create") {
    await navigateMag(binding, searchPath());
    if ((await sendMagCommand(binding, "lookup", args)).exists) {
      throw Error("mega_mag_mac_exists");
    }
    await navigateMag(binding, "/subscriptions/mag/add");
    const prepared = await sendMagCommand(binding, "prepare", args);
    const plan = planChannels(prepared.catalog, args.operations || []);
    await sendMagCommand(binding, "configure", {
      ...args,
      plan: plan
    });
    await sendMagCommand(binding, "submitCreate", {
      ...args,
      plan: plan
    });
    await waitForMagSubmitDone(binding, "/subscriptions/mag/add");
    await navigateMag(binding, searchPath());
    const found = await sendMagCommand(binding, "find", args);
    await navigateMag(binding, "/subscriptions/mag/" + found.id + "/edit");
    const inspected = await sendMagCommand(binding, "inspect", {
      ...args,
      id: found.id
    });
    await navigateMag(binding, "/subscriptions/mag/add");
    const ledger = await sendMagCommand(binding, "ledger");
    return {
      account: {
        serverId: "MEGA",
        id: String(found.id),
        macAddress: args.macAddress,
        portalUrl: found.portalUrl,
        expiryLabel: found.expiryLabel,
        marker: args.marker
      },
      baseCatalog: prepared.catalog,
      catalog: inspected.catalog,
      before: prepared.summary,
      after: ledger,
      verified: inspected.macAddress === args.macAddress && inspected.marker === args.marker
    };
  }
  if (job.action === "inspect") {
    await navigateMag(binding, "/subscriptions/mag/" + args.id + "/edit");
    return sendMagCommand(binding, "inspect", args);
  }
  if (job.action === "recover") {
    await navigateMag(binding, searchPath());
    const found = await sendMagCommand(binding, "find", args);
    await navigateMag(binding, "/subscriptions/mag/" + found.id + "/edit");
    const inspected = await sendMagCommand(binding, "inspect", {
      ...args,
      id: found.id
    });
    await navigateMag(binding, "/subscriptions/mag/add");
    const ledger = await sendMagCommand(binding, "ledger");
    return {
      account: {
        serverId: "MEGA",
        id: String(found.id),
        macAddress: args.macAddress,
        portalUrl: found.portalUrl,
        expiryLabel: found.expiryLabel,
        marker: args.marker
      },
      catalog: inspected.catalog,
      after: ledger,
      verified: inspected.macAddress === args.macAddress && inspected.marker === args.marker
    };
  }
  if (job.action === "edit") {
    const account = args.account;
    await navigateMag(binding, "/subscriptions/mag/" + account.id + "/edit");
    const inspected = await sendMagCommand(binding, "inspect", account);
    const plan = planChannels(inspected.catalog, args.operations || []);
    if (!plan.changed.length) {
      throw Error("mega_mag_no_channel_change");
    }
    await sendMagCommand(binding, "apply", {
      ...account,
      plan: plan
    });
    await sendMagCommand(binding, "submitEdit", {
      ...account,
      plan: plan
    });
    await waitForMagSubmitDone(binding, "/subscriptions/mag/" + account.id + "/edit");
    await navigateMag(binding, "/subscriptions/mag/" + account.id + "/edit");
    const inspected2 = await sendMagCommand(binding, "inspect", account);
    await sendMagCommand(binding, "verify", {
      plan: plan
    });
    return {
      updated: true,
      refreshRequired: true,
      id: account.id,
      macAddress: account.macAddress,
      marker: account.marker,
      catalog: inspected2.catalog,
      descriptions: plan.descriptions
    };
  }
  throw Error("mega_mag_unsupported_job");
}
// 先领 MAG 任务，再领通用任务。结果最多重报 2 次（网络抖动时兜底）。
async function pollMegaQueues() {
  if (!magJobRunning) {
    magJobRunning = true;
    try {
      const binding = await chrome.storage.local.get(["enabled", "key", "tabId"]);
      if (!binding.enabled || !binding.key || !binding.tabId) {
        return;
      }
      await getMegaTab(binding);
      const {
        job: magJob
      } = await bridgeFetch(binding, "/mag/next?version=0.4.12");
      if (magJob) {
        let magResult;
        try {
          magResult = {
            id: magJob.id,
            server: "MEGA",
            result: await runMagJob(binding, magJob)
          };
        } catch (magError) {
          magResult = {
            id: magJob.id,
            server: "MEGA",
            error: magError.message
          };
        }
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            await bridgeFetch(binding, "/mag/result", magResult);
            break;
          } catch (error) {
            if (attempt === 1) {
              throw error;
            }
          }
        }
        await chrome.storage.local.set({
          lastStatus: magResult.error ? "MAG 任务已停止：" + magResult.error : "MAG 任务完成"
        });
        return;
      }
      const {
        job: job
      } = await bridgeFetch(binding, "/next");
      if (!job) {
        await chrome.storage.local.set({
          lastStatus: "已连接，等待本机任务"
        });
        return;
      }
      let result;
      try {
        result = {
          id: job.id,
          result: await runLinesJob(binding, job)
        };
      } catch (error) {
        result = {
          id: job.id,
          error: error.message,
          writeDispatched: error.writeDispatched === true
        };
      }
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          await bridgeFetch(binding, "/result", result);
          break;
        } catch (error) {
          if (attempt === 1) {
            throw error;
          }
        }
      }
      await chrome.storage.local.set({
        lastStatus: result.error ? "任务已停止：" + result.error : "任务完成"
      });
    } catch (error) {
      await chrome.storage.local.set({
        lastStatus: error.message
      });
    } finally {
      magJobRunning = false;
    }
  }
}
let panelJobRunning = false;
let sessionCheckRunning = false;
// 五台服务器的登录状态巡检。返回 skipped 表示这一轮跳过（有业务任务在跑 / 刚查过）。
// 状态：unbound 未绑定、tab_closed 标签关了、wrong_page 页面不对、
//       helper_unavailable 助手不可用、expired 已过期（30 分钟内只自动恢复一次）。
async function checkSessions({
  force = false,
  now = Date.now()
} = {}) {
  if (sessionCheckRunning) {
    return {
      skipped: true,
      reason: "session_check_running"
    };
  }
  if (magJobRunning || panelJobRunning) {
    return {
      skipped: true,
      reason: "business_task_running"
    };
  }
  sessionCheckRunning = true;
  try {
    const stored = await chrome.storage.local.get(["tabId", "panelBindings", "sessionHealth", "sessionLoginAttempts", "lastSessionKeepAlive"]);
    if (!force && Number.isFinite(stored.lastSessionKeepAlive) && now - stored.lastSessionKeepAlive < 25000) {
      return {
        skipped: true,
        reason: "recently_checked"
      };
    }
    const bindings = {
      ...(stored.tabId ? {
        MEGA: {
          tabId: stored.tabId
        }
      } : {}),
      ...(stored.panelBindings || {})
    };
    const health = {};
    const loginAttempts = {
      ...(stored.sessionLoginAttempts || {})
    };
    for (const serverId of sessionNames) {
      const binding = bindings[serverId];
      if (!binding?.tabId) {
        health[serverId] = {
          state: "unbound",
          checkedAt: now
        };
        continue;
      }
      let tab;
      try {
        tab = await chrome.tabs.get(binding.tabId);
      } catch {
        health[serverId] = {
          state: "tab_closed",
          checkedAt: now
        };
        continue;
      }
      if (serverForUrl(tab.url)?.id !== serverId) {
        health[serverId] = {
          state: "wrong_page",
          checkedAt: now
        };
        continue;
      }
      let reply;
      try {
        reply = await callSessionGuard(binding.tabId, serverId, "keepAlive");
      } catch {
        health[serverId] = {
          state: "helper_unavailable",
          checkedAt: now
        };
        continue;
      }
      if (!reply?.ok || !reply.result) {
        health[serverId] = {
          state: "helper_unavailable",
          checkedAt: now
        };
        continue;
      }
      let result = reply.result;
      if (result.state === "expired" && result.canAutoResume && now - Number(loginAttempts[serverId] || 0) >= 1800000) {
        try {
          const resumed = await callSessionGuard(binding.tabId, serverId, "resume");
          if (resumed?.ok && resumed.result?.state === "login_submitted") {
            loginAttempts[serverId] = now;
            result = resumed.result;
          }
        } catch {}
      }
      health[serverId] = {
        state: result.state,
        checkedAt: now,
        ...(result.needsVerification ? {
          needsVerification: true
        } : {}),
        ...(result.needsCredentials ? {
          needsCredentials: true
        } : {})
      };
    }
    await chrome.storage.local.set({
      sessionHealth: health,
      sessionLoginAttempts: loginAttempts,
      lastSessionKeepAlive: now
    });
    return {
      skipped: false,
      health: health
    };
  } finally {
    sessionCheckRunning = false;
  }
}
// 遍历所有已绑定的面板，按服务器类型走各自的队列：
//   STRONG         → /strong/next
//   LION           → /lion/next
//   DINO / TREX    → /classic/next
//   其它（MEGA 等）→ /panels/next，只做 prepare 预检
async function pollPanels() {
  await pollMegaQueues();
  if (!panelJobRunning) {
    panelJobRunning = true;
    try {
      const stored = await chrome.storage.local.get(["key", "panelBindings"]);
      if (!stored.key) {
        return;
      }
      for (const [serverId, binding] of Object.entries(stored.panelBindings || {})) {
        if (!binding.enabled) {
          continue;
        }
        const server = serverById(serverId);
        if (server.id !== "MEGA") {
          try {
            const tab = await chrome.tabs.get(binding.tabId);
            if (serverForUrl(tab.url)?.id !== serverId) {
              throw Error("绑定标签已离开指定后台");
            }
            if (serverId === "STRONG") {
              const {
                job: strongJob
              } = await bridgeFetch(stored, "/strong/next?version=0.4.5");
              if (strongJob) {
                let strongResult;
                try {
                  strongResult = {
                    id: strongJob.id,
                    server: "STRONG",
                    result: await runStrong(binding.tabId, strongJob)
                  };
                } catch (error) {
                  strongResult = {
                    id: strongJob.id,
                    server: "STRONG",
                    error: error.message
                  };
                }
                for (let attempt = 0; attempt < 2; attempt++) {
                  try {
                    await bridgeFetch(stored, "/strong/result", strongResult);
                    break;
                  } catch (error) {
                    if (attempt === 1) {
                      throw error;
                    }
                  }
                }
                continue;
              }
            }
            if (serverId === "LION" || serverId === "DINO" || serverId === "TREX") {
              const queuePath = serverId === "LION" ? "/lion" : "/classic";
              const queueVersion = serverId === "LION" ? "0.4.5" : "0.4.7";
              const {
                job: job2
              } = await bridgeFetch(stored, queuePath + "/next?version=" + queueVersion + (serverId === "LION" ? "" : "&server=" + serverId));
              if (job2) {
                let result2;
                try {
                  result2 = {
                    id: job2.id,
                    server: serverId,
                    result: await (serverId === "LION" ? runLion : runClassic)(binding.tabId, job2)
                  };
                } catch (error) {
                  result2 = {
                    id: job2.id,
                    server: serverId,
                    error: error.message
                  };
                }
                for (let attempt = 0; attempt < 2; attempt++) {
                  try {
                    await bridgeFetch(stored, queuePath + "/result", result2);
                    break;
                  } catch (error) {
                    if (attempt === 1) {
                      throw error;
                    }
                  }
                }
                continue;
              }
            }
            const {
              job: job
            } = await bridgeFetch(stored, "/panels/next?server=" + serverId);
            if (!job) {
              continue;
            }
            let result;
            try {
              if (job.server !== serverId || job.action !== "prepare") {
                throw Error("invalid_panel_job");
              }
              const origin = new URL(tab.url).origin;
              await chrome.tabs.update(binding.tabId, {
                url: origin + server.createPath
              });
              const deadline = Date.now() + 22000;
              let ready = false;
              while (Date.now() < deadline) {
                const tab2 = await chrome.tabs.get(binding.tabId);
                if (tab2.status === "complete" && serverForUrl(tab2.url)?.id === serverId && new URL(tab2.url).pathname === server.createPath.split("?")[0]) {
                  try {
                    if ((await chrome.tabs.sendMessage(tab2.id, {
                      type: "iptv-panel-command",
                      server: serverId,
                      action: "ping"
                    }))?.ok) {
                      ready = true;
                      break;
                    }
                  } catch {}
                }
                await sleep(250);
              }
              if (!ready) {
                throw Error("页面未就绪");
              }
              const prepareReply = await chrome.tabs.sendMessage(binding.tabId, {
                type: "iptv-panel-command",
                server: serverId,
                action: "prepare"
              });
              if (!prepareReply?.ok) {
                throw Error(prepareReply?.error || "预检未完成");
              }
              result = {
                id: job.id,
                server: serverId,
                result: prepareReply.result
              };
            } catch (error) {
              result = {
                id: job.id,
                server: serverId,
                error: error.message
              };
            }
            await bridgeFetch(stored, "/panels/result", result);
          } catch {
            await chrome.storage.local.set({
              panelStatus: serverId + " 连接或预检未完成，请检查后台标签"
            });
          }
        }
      }
    } finally {
      panelJobRunning = false;
    }
  }
}
let waitLoopRunning = false;
// 长轮询 /wait：有新任务就立刻触发一轮 poll，没有就等 20 秒再来。
async function waitForWork() {
  if (!waitLoopRunning) {
    waitLoopRunning = true;
    try {
      while (true) {
        const stored = await chrome.storage.local.get(["key"]);
        if (!stored.key) {
          return;
        }
        let waited;
        try {
          waited = await bridgeFetch(stored, "/wait?timeout=20000", undefined, 25000);
        } catch {
          return;
        }
        if (waited?.ready) {
          await pollPanels();
        }
      }
    } finally {
      waitLoopRunning = false;
    }
  }
}
// 30 秒一次的心跳；同时监听弹窗发来的手动 poll 和 session-keepalive。
chrome.alarms.create("iptv-poll", {
  periodInMinutes: 0.5
});
chrome.alarms.onAlarm.addListener(_p138 => {
  if (_p138.name === "iptv-poll") {
    pollPanels().finally(() => checkSessions().catch(() => {}));
    waitForWork();
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "poll") {
    pollPanels().then(() => {
      waitForWork();
      sendResponse({
        ok: true
      });
    });
    return true;
  }
  if (message.type === "session-keepalive") {
    checkSessions({
      force: true
    }).then(result => sendResponse({
      ok: true,
      result: result
    })).catch(error => sendResponse({
      ok: false,
      error: error?.message || "session_keepalive_failed"
    }));
    return true;
  }
});
waitForWork();
export { ensureMegaPage as ensure, waitForMagPageReady as readyMag, navigateMag as goMag, runLinesJob as runMega, runMagJob as runMag, checkSessions as keepSessionsAlive };