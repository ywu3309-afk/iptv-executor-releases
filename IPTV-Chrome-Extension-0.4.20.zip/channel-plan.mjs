/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
/*
 * 频道操作规划器
 *
 * 输入：客户的一句话（例如「添加 UFC」「不要电影」「只要德国直播」）
 * 输出：每个分类最终要勾选哪些项目（selected）、哪些分类被改过（changed）、给客户看的说明（descriptions）
 *
 * 它不碰页面，只算「应该选什么」；真正去点的是各面板的 content script。
 */
import { resolveCountryModule } from "./country-channel-modules.mjs";
const scopePatterns = {
  live: /^(直播|直播频道|频道|live|live channels)$/iu,
  movies: /^(电影|电影包|movies|films)$/iu,
  series: /^(电视剧|剧集|series)$/iu
};
// 把一句话拆成操作列表。
// 支持：添加/增加/加入、删除/移除/去掉、只要/只保留；一句话可以用逗号分多段。
// 开头带 trial/test/测试/试用 的，标记成试用请求。
// 看不懂就返回 clarify，让 AI 追问，而不是瞎猜。
export function parseRequest(text) {
  let cleaned = String(text).trim().replace(/[。.!！]+$/u, "");
  const isTrial = /^(trial|test|测试|试用)(?=\s|[，,;；:]|$)/iu.test(cleaned);
  if (isTrial) {
    cleaned = cleaned.replace(/^(trial|test|测试|试用)[\s，,;；:：]*/iu, "");
  }
  if (!cleaned) {
    return {
      kind: isTrial ? "trial" : "ignore",
      operations: []
    };
  }
  const operations = [];
  for (let part of cleaned.split(/[，,;；\n]+/u).map(chunk => chunk.trim()).filter(Boolean)) {
    part = part.replace(/^(请|please\s+|帮我)/iu, "").trim();
    const match = part.match(/^(添加|增加|加上|加入|add\s+|include\s+|删除|移除|去掉|不要|remove\s+|delete\s+|exclude\s+|no\s+|只要|只保留|only\s+)(.+)$/iu);
    if (!match) {
      return {
        kind: isTrial || /频道|直播|电影|电视剧|ufc|channel|trial|movie|series/iu.test(cleaned) ? "clarify" : "ignore",
        question: "请明确要添加或删除的分类，例如：添加 UFC、删除 UFC、不要电影、只要德国直播。",
        operations: []
      };
    }
    const op = /^(添加|增加|加上|加入|add|include)/iu.test(match[1]) ? "add" : /^(只要|只保留|only)/iu.test(match[1]) ? "only" : "remove";
    operations.push({
      op: op,
      target: match[2].trim()
    });
  }
  return {
    kind: isTrial ? "trial" : "edit",
    operations: operations
  };
}
// 把操作套到目录上。catalog 是面板当前结构：{live:[], movies:[], series:[]}，
// 每项带 id/label/selected。
// 顺序：先按分类名匹配（直播/电影/电视剧）→ 再按国家模组匹配 → 最后按完整分类名精确匹配。
// 三个分类全空会直接报错，避免开出一个没有任何内容的账号。
export function planChannels(catalog, requestedOps) {
  const scopes = ["live", "movies", "series"];
  const selected = Object.fromEntries(scopes.map(scope => [scope, new Set(catalog[scope].filter(item => item.selected).map(item => item.id))]));
  const changedScopes = new Set();
  const descriptions = [];
  for (const {
    op: op,
    target: target
  } of requestedOps) {
    if (!["add", "remove", "only"].includes(op)) {
      throw Error("invalid_operation");
    }
    let scope = scopes.find(scope2 => scopePatterns[scope2].test(target));
    let items = [];
    if (scope) {
      items = catalog[scope];
      if (op === "only") {
        throw Error("请说明只保留哪个国家或具体分类；例如“只要德国直播”。");
      }
    } else {
      // 国家模组：一个「德国」可能对应多个分类下的几十个包，这里一次性全选或全删。
      const countryModule = resolveCountryModule(catalog, target);
      if (countryModule) {
        if (op === "only") {
          for (const scope2 of countryModule.scope === "live" ? ["live"] : scopes) {
            selected[scope2].clear();
            for (const item of countryModule.matches[scope2]) {
              selected[scope2].add(item.id);
            }
            changedScopes.add(scope2);
          }
        } else {
          for (const scope2 of scopes) {
            if (countryModule.matches[scope2].length) {
              for (const item of countryModule.matches[scope2]) {
                if (op === "remove") {
                  selected[scope2].delete(item.id);
                } else {
                  selected[scope2].add(item.id);
                }
              }
              changedScopes.add(scope2);
            }
          }
        }
        descriptions.push((op === "add" ? "添加" : op === "remove" ? "移除" : "仅保留") + " " + target + "（" + countryModule.count + " 个国家模组分类）");
        continue;
      } else {
        const normalizedTarget = target.toUpperCase().replace(/\s+/g, "");
        for (const scope2 of scopes) {
          const matches = catalog[scope2].filter(item => item.label.toUpperCase().replace(/\s+/g, "") === normalizedTarget || item.label.split("|").at(-1).trim().toUpperCase().replace(/\s+/g, "") === normalizedTarget);
          if (matches.length) {
            if (scope) {
              throw Error("该名称对应多种内容，请提供完整分类名称。");
            }
            scope = scope2;
            items = matches;
          }
        }
      }
    }
    if (!scope || !items.length) {
      throw Error("未找到明确分类：" + target + "。请提供后台完整分类名称；单个电视频道不一定可单独选择。");
    }
    if (!scopes.includes(scope)) {
      throw Error("invalid_scope");
    }
    if (op === "only") {
      selected[scope].clear();
    }
    for (const item of items) {
      if (op === "remove") {
        selected[scope].delete(item.id);
      } else {
        selected[scope].add(item.id);
      }
    }
    changedScopes.add(scope);
    descriptions.push((op === "add" ? "添加" : op === "remove" ? "移除" : "仅保留") + " " + target + "（" + items.length + " 个分类）");
  }
  if (scopes.every(scope => selected[scope].size === 0)) {
    throw Error("不能生成没有任何内容的账号。");
  }
  return {
    selected: Object.fromEntries(scopes.map(scope => [scope, [...selected[scope]]])),
    changed: [...changedScopes],
    descriptions: descriptions
  };
}