/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
/*
 * 插件弹窗（点扩展图标看到的那一页）
 *
 * 三件事：
 *   1. 粘贴「本机连接码」，把五个面板的标签页绑定起来；
 *   2. 显示五台服务器当前登录状态（在线/过期/需要验证码…）；
 *   3. 一键暂停全部服务器，或手动触发一次登录检查。
 */
import { bindingPlan } from "./binding-plan.mjs";
import { checkedSessionResult, sessionLabels, sessionNames } from "./session-health.mjs";
const statusEl = document.querySelector("#status");
const connectButton = document.querySelector("#connect");
const extensionVersion = chrome.runtime.getManifest().version;
document.querySelector("#version").textContent = "v" + extensionVersion;
// 按固定顺序渲染五行状态；没有记录的一律显示「未绑定」。
function renderSessionHealth(health = {}) {
  document.querySelector("#session-health").replaceChildren(...sessionNames.map(serverName => {
    const rowEl = document.createElement("div");
    const nameEl = document.createElement("strong");
    const stateEl = document.createElement("span");
    const state = health[serverName]?.state || "unbound";
    nameEl.textContent = serverName;
    stateEl.textContent = sessionLabels[state] || state;
    stateEl.className = state === "active" ? "good" : state === "unbound" ? "" : "warn";
    rowEl.append(nameEl, stateEl);
    return rowEl;
  }));
}
// 打开弹窗先读本地缓存，避免空白等接口。
chrome.storage.local.get(["lastStatus", "key", "sessionHealth"]).then(stored => {
  statusEl.textContent = stored.lastStatus || "等待连接";
  document.querySelector("#saved").textContent = stored.key ? "已保存连接码，正常使用无需再次粘贴。" : "打开下方连接教程，点击“复制本机连接码”。";
  renderSessionHealth(stored.sessionHealth);
});
// 绑定流程：先校验连接码能不能连上本机桥，再把标签页方案存进 storage。
// bindingPlan 会按当前打开的标签页，找出五个面板各自对应哪个 tab。
connectButton.onclick = async () => {
  connectButton.disabled = true;
  try {
    const storedKey = await chrome.storage.local.get(["key"]);
    const inputKey = document.querySelector("#key").value.trim() || storedKey.key;
    const plan = bindingPlan(await chrome.tabs.query({}), inputKey);
    const checkResponse = await fetch("http://127.0.0.1:3212/connection-check", {
      headers: {
        "X-Local-Key": inputKey
      },
      signal: AbortSignal.timeout(4000)
    });
    if (!checkResponse.ok) {
      throw Error("本机连接码未通过验证。请确认向导已启动并重新复制连接码。");
    }
    if ((await checkResponse.json()).ok !== true) {
      throw Error("请先更新并启动本机连接服务。");
    }
    const {
      names: boundNames,
      ...bindings
    } = plan;
    await chrome.storage.local.set(bindings);
    document.querySelector("#key").value = "";
    chrome.runtime.sendMessage({
      type: "poll"
    }).catch(() => {});
    statusEl.textContent = "已绑定 " + boundNames.join("、") + "。请回管理台检查各服务器实际状态。";
  } catch (error) {
    statusEl.textContent = error instanceof TypeError ? "无法连接本机服务。请双击执行端连接入口并启动服务。" : error.message;
  } finally {
    connectButton.disabled = false;
  }
};
// 全部暂停：只关掉「领新任务」的开关，已经提交的操作不会被中断。
document.querySelector("#stop").onclick = async () => {
  const storedBindings = await chrome.storage.local.get(["panelBindings"]);
  await chrome.storage.local.set({
    enabled: false,
    panelBindings: Object.fromEntries(Object.entries(storedBindings.panelBindings || {}).map(([serverId, binding]) => [serverId, {
      ...binding,
      enabled: false
    }]))
  });
  statusEl.textContent = "全部服务器已暂停领取新任务；已提交的操作可能继续完成。";
};
// 手动触发一次登录检查（走 worker 的 session-keepalive）。
document.querySelector("#check-sessions").onclick = async event => {
  event.currentTarget.disabled = true;
  statusEl.textContent = "正在检查五个后台登录状态…";
  try {
    const reply = await chrome.runtime.sendMessage({
      type: "session-keepalive"
    });
    const checked = checkedSessionResult(reply);
    if (checked.health) {
      renderSessionHealth(checked.health);
    }
    statusEl.textContent = checked.message;
  } catch (error) {
    statusEl.textContent = error?.message || "检查失败，请确认扩展已重载并重新绑定后台页面。";
  } finally {
    event.currentTarget.disabled = false;
  }
};
document.querySelector("#setup").onclick = () => chrome.tabs.create({
  url: "http://127.0.0.1:3221/extension"
});