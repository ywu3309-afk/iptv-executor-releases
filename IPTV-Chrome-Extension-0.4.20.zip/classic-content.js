/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
/*
 * DINO / TREX 面板助手（tvpluspanel.ru、activationpanel.ru 共用一套）
 *
 * 两个站点结构几乎一样，靠 location.origin 区分 serverId。
 * 页面是老的 jQuery + DataTables 后台，所以：
 *   - 列表数据要靠 classic-datatables-guard.js 在页面主世界打补丁才能读；
 *   - 成功/失败提示是 SweetAlert，要兼容 .swal2 / .sweet-alert 两代。
 *
 * 所有动作都会「先核对再动手」：账号、备注、ID、字段快照任何一项对不上就停，
 * 宁可失败也不要在别人的账号上操作。
 */
(() => {
  const serverId = {
    "https://www.tvpluspanel.ru": "DINO",
    "https://tvpluspanel.ru": "DINO",
    "https://activationpanel.ru": "TREX"
  }[location.origin];
  if (!serverId || globalThis.__classicBrowser044) {
    return;
  }
  globalThis.__classicBrowser044 = true;
  const documentId = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  let lastInvalidJsonAt = 0;
  const windowRef = globalThis.window || globalThis;
  // DataTables 的 JSON 解析补丁会通过 postMessage 报「JSON 坏了」，
  // 收到就记个时间戳，后续读表格前先检查，避免读到脏数据。
  windowRef.addEventListener?.("message", postMessageEvent => {
    if (postMessageEvent.source === windowRef && postMessageEvent.origin === location.origin && postMessageEvent.data?.source === "iptv-classic-datatables" && postMessageEvent.data?.type === "invalid-json") {
      lastInvalidJsonAt = Date.now();
    }
  });
  const sleep = ms => new Promise(resolveLater => setTimeout(resolveLater, ms));
  const waitFor = async probe => {
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      const value = probe();
      if (value) {
        return value;
      }
      await sleep(150);
    }
    throw Error("classic_page_not_ready");
  };
  const textOf = node => (node?.innerText || "").trim();
  const VERSION = "0.4.7";
  const isMarker = marker => new RegExp("^IPTVBOT-" + serverId + "-[A-Z0-9-]{8,90}$").test(marker || "");
  const channelCheckboxes = scopeNode => [...scopeNode.querySelectorAll("input[type=checkbox]")].filter(checkbox => /^(pack|vod)-fill-\d+$/.test(checkbox.id));
  const sameSet = (left, right) => JSON.stringify([...left].sort()) === JSON.stringify([...right].sort());
  // 读频道目录：所有 pack-*/vod-* 复选框，按标签分成 直播/电影/剧集/混合。
  // 标签前面的「12 - 」序号会被去掉。
  function readCatalog(root = document) {
    const catalog = {
      live: [],
      movies: [],
      series: [],
      mixed: []
    };
    for (const checkbox of channelCheckboxes(root)) {
      const label = textOf(checkbox.closest("label") || root.querySelector("label[for=" + checkbox.id + "]")).replace(/^\d+\s*-\s*/, "");
      let scope = checkbox.id.startsWith("pack-") ? "live" : /MOVIES\s*&\s*SERIES/i.test(label) ? "mixed" : /\b(?:SERIES?|SRS)\b/i.test(label) ? "series" : /\b(?:MOVIES|VOD)\b/i.test(label) ? "movies" : "mixed";
      if (!label || !/^\d+$/.test(checkbox.value)) {
        throw Error("classic_catalog_invalid");
      }
      catalog[scope].push({
        id: checkbox.value,
        label: label,
        selected: checkbox.checked
      });
    }
    return catalog;
  }
  const selectedValues = root => channelCheckboxes(root).filter(checkbox => checkbox.checked).map(checkbox => checkbox.value).sort();
  const userRows = () => [...document.querySelectorAll("#datatable-users tbody tr")].filter(row => row.cells?.length >= 11);
  const anyRows = () => [...new Set([...document.querySelectorAll("#datatable-users tbody tr,#datatable-subscriptions tbody tr,table tbody tr")])].filter(row => row.cells?.length >= 8);
  // 按「用户名 + marker」在用户表里找唯一一行；不唯一直接报错，避免改错人。
  function findAccountRow(binding) {
    if (!isMarker(binding.marker) || !binding.username || binding.serverId && binding.serverId !== serverId) {
      throw Error("classic_binding_missing");
    }
    const rows = userRows().filter(row => textOf(row.cells[1]) === binding.username && textOf(row.cells[10]) === binding.marker);
    if (rows.length !== 1) {
      throw Error("classic_account_not_unique");
    }
    return rows[0];
  }
  function toAccount(row, binding) {
    const id = row.querySelector("button[onclick*=\"edit_package\"]")?.getAttribute("onclick")?.match(/api\((\d+),\s*'edit_package'/)?.[1];
    if (!id || binding.id && String(binding.id) !== id) {
      throw Error("classic_wrong_id");
    }
    return {
      id: id,
      serverId: serverId,
      server: binding.server || "",
      username: textOf(row.cells[1]),
      password: textOf(row.cells[2]),
      expiryLabel: textOf(row.cells[3]),
      reseller: textOf(row.cells[4]),
      marker: binding.marker
    };
  }
  function readAccount(binding) {
    return toAccount(findAccountRow(binding), binding);
  }
  const accountFields = binding => {
    const row = findAccountRow(binding);
    return [1, 2, 3, 4, 5, 10, 11].map(index => textOf(row.cells[index]));
  };
  async function searchUser(text) {
    lastInvalidJsonAt = 0;
    const input = await waitFor(() => document.querySelector("#user_search"));
    input.value = text;
    input.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    input.dispatchEvent(new KeyboardEvent("keyup", {
      bubbles: true,
      key: "Enter"
    }));
  }
  async function clearSearch() {
    lastInvalidJsonAt = 0;
    const input = document.querySelector("#user_search,.dataTables_filter input[type=search],input[type=search]");
    if (input?.value) {
      input.value = "";
      input.dispatchEvent(new Event("input", {
        bubbles: true
      }));
      input.dispatchEvent(new KeyboardEvent("keyup", {
        bubbles: true,
        key: "Enter"
      }));
      input.dispatchEvent(new Event("change", {
        bubbles: true
      }));
      await sleep(150);
    }
  }
  const guardTable = value => {
    if (lastInvalidJsonAt) {
      throw Error("classic_table_invalid_json");
    }
    return value;
  };
  async function findAccount(binding) {
    await searchUser(binding.username);
    return waitFor(() => guardTable((() => {
      try {
        return readAccount(binding);
      } catch {
        return null;
      }
    })()));
  }
  async function recoverAccount(binding) {
    if (!isMarker(binding.marker) || binding.serverId && binding.serverId !== serverId) {
      throw Error("classic_binding_missing");
    }
    await clearSearch();
    return waitFor(() => guardTable((() => {
      const rows = userRows().filter(row => textOf(row.cells[10]) === binding.marker);
      if (rows.length > 1) {
        throw Error("classic_account_not_unique");
      }
      if (rows.length === 1) {
        return toAccount(rows[0], binding);
      } else {
        return null;
      }
    })()));
  }
  let inspectState = null;
  let submitted = false;
  let prepared = null;
  // 打开编辑弹窗并读回：账号信息、字段快照、当前勾选。
  // 快照会存起来，apply/save 时用来确认「还是刚才那个窗口、没被别人动过」。
  async function inspectAccount(binding) {
    const account = await findAccount(binding);
    if (document.querySelector("#myModal.show")) {
      throw Error("classic_modal_busy");
    }
    findAccountRow(binding).querySelector("button[onclick*=\"edit_package\"]").click();
    const modal = await waitFor(() => {
      const modal2 = document.querySelector("#myModal.show");
      if (modal2?.querySelector("#id")?.value === account.id && channelCheckboxes(modal2).length) {
        return modal2;
      } else {
        return null;
      }
    });
    inspectState = {
      account: account,
      fields: accountFields(account),
      selected: selectedValues(modal)
    };
    return {
      account: account,
      catalog: readCatalog(modal)
    };
  }
  // 应用勾选：先复核弹窗、账号、字段快照，再逐项点击，最后读回比对。
  async function applySelection(request) {
    const modal = document.querySelector("#myModal.show");
    if (!modal || !inspectState || request.account.marker !== inspectState.account.marker || String(request.account.id) !== inspectState.account.id || modal.querySelector("#id")?.value !== inspectState.account.id || JSON.stringify(accountFields(inspectState.account)) !== JSON.stringify(inspectState.fields)) {
      throw Error("classic_edit_guard");
    }
    const wanted = new Set(request.selected);
    const checkboxes = channelCheckboxes(modal);
    if (!wanted.size || wanted.size !== request.selected.length || request.selected.some(id => !checkboxes.some(checkbox => checkbox.value === id))) {
      throw Error("classic_invalid_selection");
    }
    for (const checkbox of checkboxes) {
      if (checkbox.checked !== wanted.has(checkbox.value)) {
        checkbox.click();
      }
    }
    if (!sameSet(selectedValues(modal), request.selected)) {
      throw Error("classic_apply_failed");
    }
    inspectState.target = [...request.selected];
    return {
      configured: true
    };
  }
  // 保存：同样先复核，然后只点一次确认按钮；成功/失败看 SweetAlert。
  async function saveChanges(request) {
    const modal = document.querySelector("#myModal.show");
    if (submitted || !modal || !inspectState?.target || request.account.marker !== inspectState.account.marker || String(request.account.id) !== inspectState.account.id || modal.querySelector("#id")?.value !== inspectState.account.id || !sameSet(selectedValues(modal), inspectState.target) || JSON.stringify(accountFields(inspectState.account)) !== JSON.stringify(inspectState.fields)) {
      throw Error("classic_save_guard");
    }
    submitted = true;
    modal.querySelector(".modal-footer button.confirm").click();
    await waitFor(() => document.querySelector(".swal2-success") || document.querySelector(".swal2-error"));
    if (document.querySelector(".swal2-error")) {
      throw Error("classic_save_rejected");
    }
    return {
      saved: true
    };
  }
  function readSidebarNumber(label) {
    const labelEl = [...document.querySelectorAll("p")].find(element => textOf(element) === label);
    const valueText = textOf(labelEl?.parentElement?.querySelector("h5"));
    if (/^-?\d+$/.test(valueText)) {
      return Number(valueText);
    } else {
      return null;
    }
  }
  // 开户页预检：必须是 /addnew?t=lines，套餐必须能选到「1 Day」（value=5），
  // 并记下价格、积分、剩余名额、试用券，作为后面发号的依据。
  async function prepare() {
    if (location.pathname !== "/addnew" || new URL(location.href).searchParams.get("t") !== "lines") {
      throw Error("classic_wrong_create_page");
    }
    const planSelect = await waitFor(() => document.querySelector("#add_sub"));
    const option = [...planSelect.options].find(option2 => option2.text.trim() === "1 Day");
    if (!option || option.value !== "5") {
      throw Error("classic_trial_missing");
    }
    planSelect.value = "5";
    planSelect.dispatchEvent(new Event("change", {
      bubbles: true
    }));
    await waitFor(() => textOf(document.querySelector("#costy")) && channelCheckboxes(document).length > 0);
    prepared = {
      summary: {
        origin: location.origin,
        trialLabel: "1 Day",
        price: textOf(document.querySelector("#costy")),
        credits: Number(textOf(document.querySelector(".app-sidebar h2"))),
        remaining: readSidebarNumber("Remaining Demo"),
        ticketsRemaining: readSidebarNumber("Demo Tickets")
      },
      catalog: readCatalog()
    };
    return prepared;
  }
  function reusePrepared(binding) {
    if (!prepared || submitted || location.pathname !== "/addnew" || new URL(location.href).searchParams.get("t") !== "lines" || document.querySelector("#add_sub")?.value !== "5" || document.querySelector("#add_packid")?.value !== (serverId === "DINO" ? "8" : "13") || !isFreeTrialAvailable(binding) || !document.querySelector("#add_mac")?.value || !document.querySelector("#add_comment") || document.querySelector("#add_comment").value.trim() || channelCheckboxes(document).length === 0) {
      throw Error("classic_preflight_stale");
    }
    const snapshot = {
      summary: {
        origin: location.origin,
        trialLabel: "1 Day",
        price: textOf(document.querySelector("#costy")),
        credits: Number(textOf(document.querySelector(".app-sidebar h2"))),
        remaining: readSidebarNumber("Remaining Demo"),
        ticketsRemaining: readSidebarNumber("Demo Tickets")
      },
      catalog: readCatalog()
    };
    if (snapshot.summary.price !== prepared.summary.price || snapshot.summary.credits !== prepared.summary.credits || JSON.stringify(snapshot.catalog) !== JSON.stringify(prepared.catalog)) {
      throw Error("classic_preflight_stale");
    }
    return snapshot;
  }
  // 免费试用的判定：DINO 要求价格是 Free 且还有名额；
  // TREX 额外允许「1 Ticket」，但必须有执行端明确授权，不能自己扣券。
  function isFreeTrialAvailable(binding) {
    const price = textOf(document.querySelector("#costy"));
    if (serverId === "DINO") {
      return price === "Free" && readSidebarNumber("Remaining Demo") > 0;
    } else {
      return serverId === "TREX" && binding.allowAdvisoryTicketBalance === true && ["Free", "1 Ticket"].includes(price);
    }
  }
  async function configure(binding) {
    if (!prepared || !isMarker(binding.marker) || submitted || !isFreeTrialAvailable(binding)) {
      throw Error("classic_free_trial_unavailable");
    }
    const macInput = document.querySelector("#add_mac");
    const commentInput = document.querySelector("#add_comment");
    if (!macInput?.value || !commentInput || commentInput.value.trim()) {
      throw Error("classic_create_form_busy");
    }
    for (const checkbox of channelCheckboxes(document)) {
      if (!checkbox.checked) {
        checkbox.click();
      }
    }
    commentInput.value = binding.marker;
    commentInput.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    prepared.username = macInput.value;
    prepared.marker = binding.marker;
    prepared.reseller = textOf(document.querySelector(".app-sidebar h5"));
    return {
      username: macInput.value,
      marker: binding.marker,
      serverId: serverId,
      selected: selectedValues(document),
      reseller: prepared.reseller
    };
  }
  // 提交开号：点之前把表单再核一遍，点之后把结果分成四类：
  //   accepted  成功
  //   duplicate MAC 已存在
  //   quota     积分/券不够
  //   rejected  面板拒绝
  // 分类结果决定执行端要不要重试，所以不能只回「失败」。
  async function submitCreate(binding) {
    if (submitted || !prepared?.username || !isFreeTrialAvailable(binding) || !isMarker(binding.marker) || prepared.marker !== binding.marker || document.querySelector("#add_mac")?.value !== prepared.username || document.querySelector("#add_comment")?.value !== binding.marker || document.querySelector("#add_sub")?.value !== "5" || document.querySelector("#add_packid")?.value !== (serverId === "DINO" ? "8" : "13") || channelCheckboxes(document).length === 0 || channelCheckboxes(document).some(checkbox => !checkbox.checked)) {
      throw Error("classic_create_guard");
    }
    submitted = true;
    document.querySelector("#addnewButton").click();
    const outcome = await waitFor(() => {
      const isVisible = element => element && element.getClientRects().length;
      if (isVisible(document.querySelector(".swal2-error,.swal-icon--error,.sweet-alert .sa-error"))) {
        const message = textOf(document.querySelector(".swal2-popup,.swal-modal,.sweet-alert"));
        if (/MAC already exist/i.test(message)) {
          return "duplicate";
        } else if (/insufficient|not enough|no credits|no tickets/i.test(message)) {
          return "quota";
        } else {
          return "rejected";
        }
      }
      if (isVisible(document.querySelector(".submitError")) && textOf(document.querySelector(".submitError"))) {
        return "invalid";
      } else if (isVisible(document.querySelector(".swal2-success,.swal-icon--success,.sweet-alert .sa-success"))) {
        return "accepted";
      } else {
        return null;
      }
    });
    if (outcome !== "accepted") {
      throw Error({
        invalid: "classic_create_form_rejected",
        duplicate: "classic_create_duplicate_username",
        quota: "classic_create_quota_rejected"
      }[outcome] || "classic_create_panel_rejected");
    }
    return {
      submitted: true,
      accepted: true
    };
  }
  // 台账核对：开号后在订阅列表里找到这一行，确认扣费 0、类型 Demo、时长 1 Day、线路 M3U。
  async function ledger(binding) {
    if (!binding.username || !binding.reseller) {
      throw Error("classic_binding_missing");
    }
    await clearSearch();
    return waitFor(() => guardTable((() => {
      const rows = anyRows().filter(row2 => textOf(row2.cells[1]) === binding.username && textOf(row2.cells[0]) === binding.reseller);
      if (!rows.length) {
        return null;
      }
      if (rows.length !== 1) {
        throw Error("classic_ledger_not_unique");
      }
      const row = rows[0];
      const creditsText = textOf(row.cells[4]).replace(/[^0-9.-]/g, "");
      const credits = Number(creditsText);
      const type = textOf(row.cells[5]);
      const duration = textOf(row.cells[6]);
      const lineType = textOf(row.cells[7]);
      if (!creditsText || !Number.isFinite(credits) || credits !== 0 || type !== "Demo" || duration !== "1 Day" || lineType !== "M3U") {
        throw Error("classic_ledger_mismatch");
      }
      return {
        username: binding.username,
        reseller: binding.reseller,
        credits: credits,
        after: Number(textOf(document.querySelector(".app-sidebar h2"))),
        type: type,
        duration: duration,
        lineType: lineType
      };
    })()));
  }
  async function stream(binding) {
    const account = await findAccount(binding);
    const row = findAccountRow(binding);
    const link = row.querySelector("a[onclick*=\"openProxy\"]");
    if (!link) {
      throw Error("classic_stream_link_missing");
    }
    link.click();
    const url = await waitFor(() => {
      const value = document.querySelector("#myModal.show #link")?.value;
      if (!value) {
        return null;
      }
      try {
        const parsed = new URL(value);
        if (["http:", "https:"].includes(parsed.protocol) && !parsed.username && !parsed.password && parsed.searchParams.get("username") === account.username && parsed.searchParams.get("password") === account.password) {
          return parsed;
        } else {
          return null;
        }
      } catch {
        return null;
      }
    });
    return {
      ...account,
      server: url.origin
    };
  }
  // 指令分发：动作名 → 函数。classic_ 开头的错误码原样回传，其它统一变成
  // classic_operation_stopped，避免把内部异常细节暴露给客户。
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || message.type !== "iptv-classic-command" || message.server !== serverId) {
      return;
    }
    const handler = {
      ping: () => ({
        version: VERSION,
        server: serverId,
        documentId: documentId
      }),
      prepare: prepare,
      reusePrepared: reusePrepared,
      configure: configure,
      submitCreate: submitCreate,
      find: findAccount,
      recover: recoverAccount,
      inspect: inspectAccount,
      apply: applySelection,
      save: saveChanges,
      ledger: ledger,
      stream: stream
    }[message.action];
    if (handler) {
      Promise.resolve().then(() => handler(message.args || {})).then(result => sendResponse({
        ok: true,
        result: result
      })).catch(error => sendResponse({
        ok: false,
        error: /^classic_[a-z_]+$/.test(error.message) ? error.message : "classic_operation_stopped"
      }));
      return true;
    }
  });
})();