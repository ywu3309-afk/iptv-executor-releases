/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
const SERVERS = {
  DINO: ["https://www.tvpluspanel.ru", "https://tvpluspanel.ru"],
  TREX: ["https://activationpanel.ru"]
};
const CONTENT_VERSION = "0.4.7";
const sleep = ms => new Promise(resolveLater => setTimeout(resolveLater, ms));
const selectedIds = catalog => Object.values(catalog).flat().filter(item => item.selected).map(item => String(item.id)).sort();
const sameSelection = (left, right) => JSON.stringify([...left].sort()) === JSON.stringify([...right].sort());
/*
 * DINO / TREX 标签页操作手（两个站共用）
 *
 * 比另外两个 worker 多一层「断线重连」：
 *   - 读类动作（prepare/inspect/find/recover/ledger/stream）遇到 "message port closed"
 *     会自动等页面重新连上再重试一次；
 *   - 写类动作（configure/submitCreate/apply/save）绝不自动重试，防止重复开号。
 *
 * 开号流程：prepare → configure → submitCreate → 等跳转 → find → ledger（核对 0 扣费）
 *          → stream（抓播放链接）→ inspect（回读频道）
 */
export async function runClassic(tabId, job) {
  const origins = SERVERS[job.server];
  if (!origins || !["prepare", "create", "inspect", "edit", "recover"].includes(job.action)) {
    throw Error("classic_unsupported_action");
  }
  const args = job.args || {};
  if (["inspect", "edit"].includes(job.action) && (!args.account || args.account.serverId !== job.server || !/^\d+$/.test(String(args.account.id)) || !args.account.username || !new RegExp("^IPTVBOT-" + job.server + "-[A-Z0-9-]{8,90}$").test(args.account.marker || "")) || job.action === "recover" && (!/^[A-Za-z0-9-]{8,80}$/.test(args.originalRequestId || "") || !new RegExp("^IPTVBOT-" + job.server + "-[A-Z0-9-]{8,90}$").test(args.marker || ""))) {
    throw Error("classic_binding_missing");
  }
  // 确认标签页还在 DINO/TREX 的域名下，且没被踢到登录页。
  async function getTab() {
    const tab = await chrome.tabs.get(tabId);
    const url = new URL(tab.url);
    if (!origins.includes(url.origin)) {
      throw Error("classic_wrong_origin");
    }
    if (url.pathname === "/login") {
      throw Error("classic_login_required");
    }
    return tab;
  }
  const isPortClosedError = error => /message port closed|message channel closed|receiving end does not exist|frame (?:was )?removed|context invalidated/i.test(error?.message || "");
  // 发指令。读类动作允许重试一次：先等页面 ping 通（版本要一致），再重发。
  async function sendCommand(action, args2 = {}) {
    const isReadAction = ["prepare", "inspect", "find", "recover", "ledger", "stream"].includes(action);
    for (let attempt = 0; attempt < (isReadAction ? 2 : 1); attempt++) {
      await getTab();
      let reply;
      try {
        reply = await chrome.tabs.sendMessage(tabId, {
          type: "iptv-classic-command",
          server: job.server,
          action: action,
          args: args2
        });
      } catch (error) {
        if (!isReadAction) {
          throw error;
        }
        if (!isPortClosedError(error)) {
          throw Error("classic_read_transport_failed");
        }
        if (attempt) {
          throw Error("classic_read_port_closed");
        }
        const deadline = Date.now() + 12000;
        let ready = false;
        while (Date.now() < deadline) {
          await getTab();
          try {
            const pingReply = await chrome.tabs.sendMessage(tabId, {
              type: "iptv-classic-command",
              server: job.server,
              action: "ping",
              args: {}
            });
            if (pingReply?.ok && pingReply.result?.version === CONTENT_VERSION) {
              ready = true;
              break;
            }
          } catch {}
          await sleep(250);
        }
        if (!ready) {
          throw Error("classic_content_not_connected");
        }
        continue;
      }
      if (!reply?.ok) {
        throw Error(reply?.error || "classic_extension_not_ready");
      }
      return reply.result;
    }
  }
  async function sendWithDisconnect(action, args2) {
    try {
      return {
        disconnected: false,
        result: await sendCommand(action, args2)
      };
    } catch (error) {
      if (/^classic_/.test(error.message) || !/message port closed|message channel closed|receiving end does not exist|frame (?:was )?removed|context invalidated/i.test(error.message)) {
        throw error;
      }
      return {
        disconnected: true
      };
    }
  }
  async function waitUsersPage() {
    const deadline = Date.now() + 30000;
    while (Date.now() < deadline) {
      const tab = await getTab();
      if (tab.status === "complete" && new URL(tab.url).pathname === "/users") {
        try {
          if ((await sendCommand("ping")).version === CONTENT_VERSION) {
            return;
          }
        } catch (error) {
          if (/^classic_(?:wrong_origin|login_required)$/.test(error.message)) {
            throw error;
          }
        }
      }
      await sleep(250);
    }
    throw Error("classic_write_requires_review");
  }
  async function navigate(path = "/users?s=lines") {
    const tab = await getTab();
    const origin = new URL(tab.url).origin;
    let previousDocumentId;
    try {
      previousDocumentId = (await sendCommand("ping")).documentId;
    } catch {}
    await chrome.tabs.update(tabId, {
      url: origin + path
    });
    const deadline = Date.now() + 25000;
    let arrived = false;
    while (Date.now() < deadline) {
      const tab2 = await getTab();
      const url = new URL(tab2.url);
      const target = new URL(origin + path);
      if (url.pathname === target.pathname && url.search === target.search) {
        arrived = true;
        try {
          const pingReply = await sendCommand("ping");
          if (pingReply?.version !== CONTENT_VERSION || typeof pingReply.documentId != "string" || !pingReply.documentId.trim()) {
            throw Error("classic_content_version_mismatch");
          }
          if (pingReply.server && pingReply.server !== job.server) {
            throw Error("classic_wrong_server");
          }
          if (!previousDocumentId || pingReply.documentId !== previousDocumentId) {
            return;
          }
        } catch (error) {
          if (["classic_login_required", "classic_wrong_origin", "classic_wrong_server", "classic_content_version_mismatch"].includes(error.message)) {
            throw error;
          }
        }
      }
      await sleep(250);
    }
    throw Error(arrived ? "classic_content_not_connected" : "classic_navigation_timeout");
  }
  async function ensurePage(path) {
    const tab = await getTab();
    const origin = new URL(tab.url).origin;
    const target = new URL(origin + path);
    const url = new URL(tab.url);
    if (url.pathname === target.pathname && url.search === target.search) {
      try {
        const pingReply = await sendCommand("ping");
        if (pingReply?.version === CONTENT_VERSION && typeof pingReply.documentId == "string" && pingReply.documentId.trim() && (!pingReply.server || pingReply.server === job.server)) {
          return;
        }
      } catch (error) {
        if (["classic_login_required", "classic_wrong_origin", "classic_wrong_server", "classic_content_version_mismatch"].includes(error.message)) {
          throw error;
        }
      }
    }
    await navigate(path);
  }
  // 页面刚跳转时 DataTables 可能还没加载完（classic_page_not_ready / table_invalid_json），
  // 这里最多重试 3 次，每次重新打开列表页再读。
  async function retryRead(action, args2, path = "/users?s=lines") {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await sendCommand(action, args2);
      } catch (error) {
        if (!["classic_table_invalid_json", "classic_page_not_ready"].includes(error.message) || attempt === 2) {
          throw error;
        }
        await sleep((attempt + 1) * 1000);
        await navigate(path);
      }
    }
  }
  // 恢复：按 marker 找回已开的号 → 核对台账扣费为 0 → 抓播放链接 → 回读频道。
  // 任何一步对不上就报错，绝不「装作成功」。
  if (job.action === "recover") {
    await ensurePage("/users?s=lines");
    const account = await retryRead("recover", {
      marker: args.marker,
      serverId: job.server
    });
    await navigate("/logs?t=subscriptions");
    const ledger = await retryRead("ledger", account, "/logs?t=subscriptions");
    if (ledger.credits !== 0 || ledger.type !== "Demo" || ledger.duration !== "1 Day" || ledger.lineType !== "M3U" || ledger.username !== account.username || ledger.reseller !== account.reseller || !Number.isFinite(ledger.after)) {
      throw Error("classic_recovery_ledger_mismatch");
    }
    await navigate();
    const streamed = await retryRead("stream", account);
    await navigate();
    const inspected = await retryRead("inspect", streamed);
    const items2 = Object.values(inspected.catalog || {}).flat();
    if (!items2.length || items2.some(item => item.selected !== true)) {
      throw Error("classic_recovery_selection_mismatch");
    }
    return {
      ...inspected,
      account: {
        ...inspected.account,
        package: "1 Day trial",
        template: "All categories"
      },
      charge: ledger,
      recovered: true,
      originalRequestId: args.originalRequestId
    };
  }
  if (job.action === "prepare" || job.action === "create") {
    if (job.action === "create" && (!new RegExp("^IPTVBOT-" + job.server + "-[A-Z0-9-]{8,90}$").test(args.marker || "") || job.server === "TREX" && args.allowAdvisoryTicketBalance !== true)) {
      throw Error("classic_free_trial_unavailable");
    }
    await ensurePage("/addnew?t=lines");
    let prepared;
    if (job.action === "create") {
      try {
        prepared = await sendCommand("reusePrepared", args);
      } catch (error) {
        if (error.message !== "classic_preflight_stale") {
          throw error;
        }
        prepared = await sendCommand("prepare");
      }
    } else {
      prepared = await sendCommand("prepare");
    }
    if (job.action === "prepare") {
      return prepared;
    }
    if (job.server === "DINO" ? prepared.summary.price !== "Free" || !Number.isInteger(prepared.summary.remaining) || prepared.summary.remaining < 1 : !["Free", "1 Ticket"].includes(prepared.summary.price) || args.allowAdvisoryTicketBalance !== true) {
      throw Error("classic_free_trial_unavailable");
    }
    const configured = await sendCommand("configure", args);
    if ((await sendWithDisconnect("submitCreate", args)).result?.accepted === true) {
      await navigate();
    } else {
      await waitUsersPage();
    }
    const found = await retryRead("find", configured);
    await navigate("/logs?t=subscriptions");
    const ledger = await retryRead("ledger", found, "/logs?t=subscriptions");
    ledger.before = prepared.summary.credits;
    if (ledger.credits !== 0 || ledger.type !== "Demo" || ledger.duration !== "1 Day" || ledger.lineType !== "M3U" || ledger.username !== found.username || ledger.reseller !== found.reseller || !Number.isFinite(ledger.before) || !Number.isFinite(ledger.after) || ledger.before !== ledger.after) {
      throw Error("classic_nonzero_charge");
    }
    await navigate();
    const streamed = await retryRead("stream", found);
    await navigate();
    const inspected = await retryRead("inspect", streamed);
    if (!sameSelection(selectedIds(inspected.catalog), configured.selected)) {
      throw Error("classic_created_selection_mismatch");
    }
    return {
      ...inspected,
      account: {
        ...inspected.account,
        package: prepared.summary.price === "Free" ? "1 Day (free demo)" : "1 Day (1 ticket, 0 credits)",
        template: "All categories"
      },
      charge: ledger,
      summary: prepared.summary
    };
  }
  await navigate();
  const current = await sendCommand("inspect", args.account);
  if (job.action === "inspect") {
    return current;
  }
  const items = Object.values(current.catalog).flat();
  const ids = new Set(items.map(item => String(item.id)));
  let nextSelected;
  if (Array.isArray(args.selected)) {
    nextSelected = args.selected.map(String);
  } else {
    if (!Array.isArray(args.channelIds) || !["add", "remove"].includes(args.operation)) {
      throw Error("classic_invalid_operation");
    }
    const next = new Set(selectedIds(current.catalog));
    for (const channelId of args.channelIds) {
      const channelId2 = String(channelId);
      if (!ids.has(channelId2)) {
        throw Error("classic_unknown_channel");
      }
      if (args.operation === "add") {
        next.add(channelId2);
      } else {
        next.delete(channelId2);
      }
    }
    nextSelected = [...next];
  }
  if (!nextSelected.length || new Set(nextSelected).size !== nextSelected.length || nextSelected.some(id => !ids.has(id))) {
    throw Error("classic_invalid_selection");
  }
  if (sameSelection(nextSelected, selectedIds(current.catalog))) {
    return {
      ...current,
      updated: false
    };
  }
  await sendCommand("apply", {
    account: args.account,
    selected: nextSelected
  });
  let disconnected = false;
  try {
    ({
      disconnected: disconnected
    } = await sendWithDisconnect("save", {
      account: args.account
    }));
  } catch (error) {
    if (error.message !== "classic_page_not_ready") {
      throw error;
    }
  }
  if (disconnected) {
    await waitUsersPage();
  } else {
    await navigate();
  }
  const verified = await sendCommand("inspect", args.account);
  if (!sameSelection(selectedIds(verified.catalog), nextSelected)) {
    throw Error("classic_saved_selection_mismatch");
  }
  for (const key of ["id", "username", "password", "marker", "expiryLabel"]) {
    if (verified.account[key] !== current.account[key]) {
      throw Error("classic_account_fields_changed");
    }
  }
  return {
    ...verified,
    updated: true,
    refreshRequired: true
  };
}