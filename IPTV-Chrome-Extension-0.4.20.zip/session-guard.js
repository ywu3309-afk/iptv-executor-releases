/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
/*
 * 面板登录守卫（注入到每个面板页执行）
 *
 * 作用：不动页面业务，只回答一个问题——「这个面板现在还能操作吗？」
 *   active                正常
 *   expired               掉登录（看到登录框 / 被踢到登录页 / 401·419·440）
 *   verification_required 撞到人机验证（403）
 *   unreachable           面板打不开
 *
 * 五种状态里只有 expired 且表单齐全时才会自动重新登录（autoResumeLogin）。
 * 用 globalThis.__iptvSessionGuardInstalled 防止重复注入。
 */
(() => {
  if (globalThis.__iptvSessionGuardInstalled) {
    return;
  }
  globalThis.__iptvSessionGuardInstalled = true;
  const siteConfig = {
    "https://megaott.net": {
      server: "MEGA",
      path: "/subscriptions/lines"
    },
    "https://lion2.bycdn.network": {
      server: "LION",
      path: "/devices/m3u"
    },
    "https://www.tvpluspanel.ru": {
      server: "DINO",
      path: "/users?s=lines"
    },
    "https://tvpluspanel.ru": {
      server: "DINO",
      path: "/users?s=lines"
    },
    "https://activationpanel.ru": {
      server: "TREX",
      path: "/users?s=lines"
    },
    "https://8k.cms-only.ru": {
      server: "STRONG",
      path: "/users?t=lines"
    },
    // STRONG 换的新域名，两个都认
    "https://8k.online-cms.ru": {
      server: "STRONG",
      path: "/users?t=lines"
    }
  }[location.origin];
  if (!siteConfig) {
    return;
  }
  // 当前网站在本站配置里的身份（服务器 ID）和判断「是否已登录」要访问的列表页。
  const isLoginPath = path => /(?:^|\/)(?:login|signin|sign-in|auth)(?:\/|$)/i.test(path || "");
  const findPasswordInput = () => document.querySelector("input[type=\"password\"]");
  const findLoginForm = () => findPasswordInput()?.closest("form") || document.querySelector("form");
  // 把登录相关的 DOM 抓齐：密码框、表单、用户名框、提交按钮、人机验证框。
  function readLoginForm() {
    const passInput = findPasswordInput();
    const form = findLoginForm();
    const userInput = form?.querySelector("input[autocomplete=\"username\"],input[name*=\"user\" i],input[id*=\"user\" i],input[type=\"email\"],input[type=\"text\"]");
    const submitButton = form?.querySelector("button[type=\"submit\"],input[type=\"submit\"],button:not([type])");
    const challengeInput = document.querySelector("input[name=\"cf-turnstile-response\"],textarea[name=\"g-recaptcha-response\"],textarea[name=\"h-captcha-response\"]");
    return {
      pass: passInput,
      form: form,
      user: userInput,
      submit: submitButton,
      challenge: challengeInput
    };
  }
  // 只看当前页面，不发请求：没有密码框、也不在登录路径，就认为还活着。
  function inspectLoginState() {
    const fields = readLoginForm();
    if (!isLoginPath(location.pathname) && !fields.pass) {
      return {
        server: siteConfig.server,
        state: "active",
        canAutoResume: false
      };
    }
    const hasCredentials = !!fields.user?.value && !!fields.pass?.value;
    const challengeSolved = !fields.challenge || !!fields.challenge.value;
    return {
      server: siteConfig.server,
      state: "expired",
      canAutoResume: hasCredentials && challengeSolved && !!fields.submit && !fields.submit.disabled,
      needsVerification: !challengeSolved,
      needsCredentials: !hasCredentials
    };
  }
  // 更可靠的做法：带着 cookie 请求一次列表页，看三件事判断是否掉登录：
  //   1. 被重定向到别的域或登录页；
  //   2. 返回的 HTML 里又出现了登录框；
  //   3. 状态码是 401 / 419 / 440。
  // 403 视为需要人机验证，其余非 2xx 视为面板不可达。
  async function probeSession() {
    const localState = inspectLoginState();
    if (localState.state === "expired") {
      return localState;
    }
    const targetUrl = location.origin + siteConfig.path;
    try {
      const response = await fetch(targetUrl, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        headers: {
          Accept: "text/html,application/xhtml+xml"
        }
      });
      const finalUrl = new URL(response.url || targetUrl);
      const contentType = response.headers?.get?.("content-type") || "";
      let looksLikeLogin = false;
      if (finalUrl.origin === location.origin && /text\/html/i.test(contentType)) {
        const html = (await response.text()).slice(0, 131072);
        looksLikeLogin = /<input[^>]+type=["']?password/i.test(html) && /(?:login|sign[ -]?in|welcome)/i.test(html);
      }
      if (finalUrl.origin !== location.origin || isLoginPath(finalUrl.pathname) || looksLikeLogin || [401, 419, 440].includes(response.status)) {
        return {
          server: siteConfig.server,
          state: "expired",
          canAutoResume: false,
          needsVerification: false,
          needsCredentials: false
        };
      } else if (response.status === 403) {
        return {
          server: siteConfig.server,
          state: "verification_required",
          canAutoResume: false
        };
      } else if (response.ok) {
        return {
          server: siteConfig.server,
          state: "active",
          canAutoResume: false,
          httpStatus: response.status
        };
      } else {
        return {
          server: siteConfig.server,
          state: "unreachable",
          canAutoResume: false,
          httpStatus: response.status
        };
      }
    } catch {
      return {
        server: siteConfig.server,
        state: "unreachable",
        canAutoResume: false
      };
    }
  }
  // 自动重登：只有在「已过期、账号密码已在表单里、没有待过人机验证、提交按钮可点」时才动手。
  // 顺手勾上「记住我」这类复选框，再点提交。
  function autoResumeLogin() {
    const state = inspectLoginState();
    const fields = readLoginForm();
    if (state.state !== "expired" || !state.canAutoResume) {
      return state;
    }
    const rememberBox = [...(fields.form?.querySelectorAll("input[type=\"checkbox\"]") || [])].find(input => /remember|stay|keep/i.test([input.name, input.id, input.getAttribute?.("aria-label"), input.closest?.("label")?.textContent].filter(Boolean).join(" ")));
    if (rememberBox && !rememberBox.checked) {
      rememberBox.checked = true;
      rememberBox.dispatchEvent(new Event("change", {
        bubbles: true
      }));
    }
    setTimeout(() => fields.submit.click(), 100);
    return {
      server: siteConfig.server,
      state: "login_submitted",
      canAutoResume: false
    };
  }
  // 对外只接三种指令：status 查状态、resume 尝试重登、keepAlive 真请求探活。
  // keepAlive 是异步的，return true 保持消息通道不关闭。
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id === chrome.runtime.id && message.type === "iptv-session-guard" && message.server === siteConfig.server) {
      if (message.action === "status") {
        sendResponse({
          ok: true,
          result: inspectLoginState()
        });
        return;
      }
      if (message.action === "resume") {
        sendResponse({
          ok: true,
          result: autoResumeLogin()
        });
        return;
      }
      if (message.action === "keepAlive") {
        probeSession().then(result => sendResponse({
          ok: true,
          result: result
        })).catch(() => sendResponse({
          ok: true,
          result: {
            server: siteConfig.server,
            state: "unreachable",
            canAutoResume: false
          }
        }));
        return true;
      }
    }
  });
})();