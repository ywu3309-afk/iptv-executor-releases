/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
export const sessionNames = Object.freeze(["MEGA", "LION", "DINO", "TREX", "STRONG"]);
export const sessionLabels = Object.freeze({
  active: "在线",
  expired: "登录已过期",
  login_submitted: "正在恢复登录",
  verification_required: "需要验证码",
  unbound: "未绑定",
  tab_closed: "后台标签已关闭",
  wrong_page: "标签页已离开后台",
  helper_unavailable: "页面助手未就绪",
  unreachable: "后台请求失败"
});
export function checkedSessionResult(_p1) {
  if (!_p1?.ok) {
    throw Error(_p1?.error || "扩展后台检查失败，请重新加载扩展后重试。");
  }
  const _v2 = _p1.result;
  if (_v2?.skipped) {
    return {
      health: null,
      message: _v2.reason === "business_task_running" ? "服务器任务正在运行，本次登录检查已自动让路，请任务完成后再检查。" : "登录状态检查正在进行，请稍后再试。"
    };
  }
  const _v3 = _v2?.health;
  if (!_v3 || !sessionNames.every(_p4 => _v3[_p4]?.state)) {
    throw Error("未收到完整的五服务器检查结果，请重新加载扩展后重试。");
  }
  return {
    health: _v3,
    message: "登录状态检查完成。登录页已有保存信息且验证码通过时，系统只尝试恢复一次。"
  };
}