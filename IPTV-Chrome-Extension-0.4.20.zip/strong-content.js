/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
(() => {
  // STRONG 面板换过域名：老站 8k.cms-only.ru、新站 8k.online-cms.ru，两个都认。
  // REPORTED_ORIGIN 是上报给执行端的「身份域名」：执行端 0.3.24 仍按老域名校验 STRONG 来源，
  // 所以这里统一报老域名，等执行端源码放开两个域名后可以删掉这层兼容。
  const STRONG_ORIGINS = ["https://8k.cms-only.ru", "https://8k.online-cms.ru"];
  const REPORTED_ORIGIN = "https://8k.cms-only.ru";
  if (!STRONG_ORIGINS.includes(location.origin) || globalThis.__strongBrowser044) {
    return;
  }
  globalThis.__strongBrowser044 = true;
  const _v1 = _p27 => new Promise(_p28 => setTimeout(_p28, _p27));
  const _v2 = crypto.randomUUID();
  const _v3 = async (_p29, _p30 = "strong_page_not_ready") => {
    const _v31 = Date.now() + 18000;
    while (Date.now() < _v31) {
      const _v32 = _p29();
      if (_v32) {
        return _v32;
      }
      await _v1(150);
    }
    throw Error(_p30);
  };
  const _v4 = _p33 => _p33 && _p33.getClientRects().length;
  const _v5 = _p34 => (_p34?.innerText || "").trim();
  const _v6 = _p35 => /^IPTVBOT-STRONG-[A-Z0-9-]{8,90}$/.test(_p35 || "");
  const _v7 = _p36 => [..._p36.querySelectorAll("input[type=checkbox]")].filter(_p37 => /^(pack|vod)-fill-\d+$/.test(_p37.id));
  function _fn8(_p38 = document) {
    return _v7(_p38).map(_p39 => ({
      id: _p39.value,
      label: _v5(_p38.querySelector("label[for=\"" + _p39.id + "\"]")).replace(/^\d+\s*-\s*(?:Billing\s*-\s*)?/i, ""),
      selected: _p39.checked,
      group: _p39.id.startsWith("vod-") ? "mixed" : "live"
    }));
  }
  const _v9 = _p40 => _fn8(_p40).filter(_p41 => _p41.selected).map(_p42 => _p42.id).sort();
  const _v10 = (_p43, _p44) => JSON.stringify([..._p43].sort()) === JSON.stringify([..._p44].sort());
  function _fn11(_p45) {
    if (!_v6(_p45.marker) || !_p45.username) {
      throw Error("strong_binding_missing");
    }
    const _v46 = [...document.querySelectorAll("#datatable-users tbody tr")].filter(_p47 => _v5(_p47.cells[0]) === _p45.username && _v5(_p47.cells[5]) === _p45.marker && _v5(_p47.cells[6]) === "ych2025iptv");
    if (_v46.length !== 1) {
      throw Error("strong_account_not_unique");
    }
    return _v46[0];
  }
  function _fn12(_p48) {
    const _v49 = _fn11(_p48);
    const _v50 = _v49.querySelector("button[onclick*=\"package\"]");
    const _v51 = _v50?.getAttribute("onclick")?.match(/api\((\d+),\s*'package'/)?.[1];
    if (!_v51 || _p48.id && String(_p48.id) !== _v51) {
      throw Error("strong_wrong_id");
    }
    return {
      server: "STRONG",
      id: _v51,
      username: _v5(_v49.cells[0]),
      password: _v5(_v49.cells[1]),
      marker: _p48.marker,
      expiryLabel: _v5(_v49.cells[3]),
      reseller: _v5(_v49.cells[6]),
      playbackServer: _p48.playbackServer,
      m3uUrl: _p48.m3uUrl,
      linkSource: _p48.linkSource,
      package: "1 Day trial",
      hours: 24
    };
  }
  async function _fn13(_p52) {
    const _v53 = _p52.closest(".modal");
    for (let _v54 = 0; _v54 < 3; _v54++) {
      const _v55 = document.querySelector(".modal.show #link")?.closest(".modal");
      if (!_v55) {
        break;
      }
      if (_v55 !== _v53) {
        throw Error("strong_playback_modal_changed");
      }
      await _v3(() => !(_v55.getAnimations?.({
        subtree: true
      }) || []).some(_p59 => ["running", "pending"].includes(_p59.playState)), "strong_playback_transition_timeout");
      const _v56 = document.querySelector(".modal.show #link")?.closest(".modal");
      if (!_v56) {
        break;
      }
      if (_v56 !== _v53) {
        throw Error("strong_playback_modal_changed");
      }
      const _v57 = _v56.querySelector("button.btn-close[data-bs-dismiss=\"modal\"],button.btn-close");
      if (!_v57 || _v57.disabled) {
        throw Error("strong_playback_close_missing");
      }
      _v57.click();
      const _v58 = Date.now() + 700;
      while (Date.now() < _v58 && document.querySelector(".modal.show #link")?.closest(".modal") === _v53) {
        await _v1(100);
      }
    }
    await _v3(() => !document.querySelector(".modal.show") && !document.querySelector(".modal-backdrop"), "strong_playback_close_timeout");
  }
  async function _fn14(_p60) {
    const _v61 = await _v3(() => document.querySelector("#filter_search"), "strong_search_missing");
    _v61.value = _p60.username;
    _v61.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    _v61.dispatchEvent(new KeyboardEvent("keyup", {
      bubbles: true,
      key: "Enter"
    }));
    const _v62 = await _v3(() => {
      try {
        return _fn12(_p60);
      } catch {
        return null;
      }
    }, "strong_account_read_timeout");
    const _v63 = _fn11(_p60);
    const _v64 = _v63.querySelector("button.dropdown-toggle");
    if (!_v64) {
      throw Error("strong_playback_menu_missing");
    }
    _v64.click();
    const _v65 = [..._v63.cells[2].querySelectorAll("a")].filter(_p70 => _v5(_p70) === "My Cloud");
    if (_v65.length !== 1) {
      throw Error("strong_my_cloud_link_missing");
    }
    _v65[0].click();
    const _v66 = () => _v5(document.querySelector(".modal.show #domain_text")) === "cf.my8kk.com" && document.querySelector(".modal.show #domain_select")?.value === "cf.my8kk.com";
    await _v3(_v66, "strong_my_cloud_domain_timeout");
    const _v67 = await _v3(() => document.querySelector(".modal.show #SelectLine"), "strong_my_cloud_format_missing");
    const _v68 = [..._v67.options].filter(_p71 => _p71.value === "SmartTV / m3u [TS]" && _p71.text.trim() === "SmartTV / m3u [TS]");
    if (_v68.length !== 1) {
      throw Error("strong_my_cloud_format_missing");
    }
    if (_v67.value !== _v68[0].value) {
      _v67.value = _v68[0].value;
      _v67.dispatchEvent(new Event("change", {
        bubbles: true
      }));
    }
    const _v69 = await _v3(() => {
      const _v72 = document.querySelector(".modal.show #link");
      if (!_v72?.value || !_v66() || _v67.value !== "SmartTV / m3u [TS]") {
        return null;
      }
      let _v73;
      try {
        _v73 = new URL(_v72.value);
      } catch {
        return null;
      }
      if (!["http:", "https:"].includes(_v73.protocol) || _v73.username || _v73.password || _v73.hostname !== "cf.my8kk.com" || _v73.pathname !== "/get.php" || _v73.searchParams.get("username") !== _v62.username || _v73.searchParams.get("password") !== _v62.password || _v73.searchParams.get("type") !== "m3u_plus" || _v73.searchParams.get("output") !== "ts" || ["username", "password", "type", "output"].some(_p74 => _v73.searchParams.getAll(_p74).length !== 1)) {
        return null;
      } else {
        return {
          link: _v72,
          url: _v73
        };
      }
    }, "strong_playback_read_timeout");
    _v62.playbackServer = _v69.url.origin;
    _v62.m3uUrl = _v69.link.value.trim();
    _v62.linkSource = "My Cloud";
    await _fn13(_v69.link);
    return _v62;
  }
  async function _fn15(_p75) {
    const _v76 = await _fn14(_p75);
    _p75.playbackServer = _v76.playbackServer;
    _p75.m3uUrl = _v76.m3uUrl;
    _p75.linkSource = _v76.linkSource;
    const _v77 = _fn11(_p75);
    const _v78 = _v77.querySelector("a[data-bs-toggle=\"dropdown\"]");
    if (!_v78) {
      throw Error("strong_edit_menu_missing");
    }
    _v78.click();
    const _v79 = _v77.querySelector("a[onclick*=\"edit_device\"]");
    if (!_v79) {
      throw Error("strong_edit_link_missing");
    }
    _v79.click();
    const _v80 = await _v3(() => document.querySelector(".modal.show #notes")?.closest(".modal"), "strong_edit_modal_timeout");
    await _v3(() => _v80.querySelector("#id")?.value === String(_p75.id), "strong_edit_identity_timeout");
    if (_v80.querySelector("#username")?.value !== _p75.username || _v80.querySelector("#notes")?.value.trim() !== _p75.marker) {
      throw Error("strong_edit_identity");
    }
    _v80.querySelector("a[href=\"#package\"]").click();
    _v80.querySelector(".editpack").click();
    await _v3(() => _v7(_v80).length > 0);
    return _v80;
  }
  function _fn16(_p81) {
    return Object.fromEntries(["id", "username", "password", "expire_date", "notes", "edit_reseller", "force_dns", "activation"].map(_p82 => {
      const _v83 = _p81.querySelector("#" + _p82);
      return [_p82, _v83?.type === "checkbox" ? {
        value: _v83.value,
        checked: _v83.checked
      } : _v83?.value ?? null];
    }).concat([["country", [...(_p81.querySelector("#edit_country")?.selectedOptions || [])].map(_p84 => _p84.value)]]));
  }
  let _v17 = null;
  let _v18 = null;
  let _v19 = false;
  async function _fn20() {
    if (location.pathname !== "/addnew" || new URL(location.href).searchParams.get("t") !== "lines") {
      throw Error("strong_wrong_create_page");
    }
    if (!/\bych2025iptv\b/.test(_v5(document.querySelector("#page-header-user-dropdown")))) {
      throw Error("strong_wrong_reseller");
    }
    const _v85 = await _v3(() => document.querySelector("#sub_list"));
    _v85.closest(".choices").click();
    (await _v3(() => [...document.querySelectorAll(".choices [role=option][data-value]")].find(_p88 => _v4(_p88) && _p88.getAttribute("data-value") === "5" && _v5(_p88) === "1 Day"))).dispatchEvent(new MouseEvent("mousedown", {
      bubbles: true,
      button: 0
    }));
    await _v3(() => _v85.value === "5" && _v5(document.querySelector("#costy")) === "Free" && document.querySelector("#form_packid")?.value === "8");
    const _v86 = [...document.querySelectorAll("p")].find(_p89 => _v5(_p89) === "Remaining Demo");
    const _v87 = Number(_v5(_v86?.parentElement.querySelector("h5")));
    if (!Number.isInteger(_v87) || _v87 < 1) {
      throw Error("strong_no_free_quota");
    }
    await _v3(() => _v7(document).length > 0);
    _v17 = {
      summary: {
        origin: REPORTED_ORIGIN,
        trialLabel: "1 Day",
        price: "Free",
        remaining: _v87
      },
      catalog: _fn8()
    };
    return _v17;
  }
  async function _fn21(_p90) {
    if (!_v17 || !_v6(_p90.marker) || _v19) {
      throw Error("strong_not_prepared");
    }
    for (const _v91 of _v7(document)) {
      if (!_v91.checked) {
        _v91.click();
      }
    }
    document.querySelector("#comment").value = _p90.marker;
    document.querySelector("#comment").dispatchEvent(new Event("input", {
      bubbles: true
    }));
    if (_v7(document).some(_p92 => !_p92.checked)) {
      throw Error("strong_selection_failed");
    }
    _v17.username = document.querySelector("#mac").value;
    return {
      username: _v17.username,
      marker: _p90.marker,
      selected: _v9(document)
    };
  }
  async function _fn22(_p93) {
    if (_v19 || !_v17 || !_v17.username || document.querySelector("#mac").value !== _v17.username || document.querySelector("#comment").value !== _p93.marker || document.querySelector("#sub_list").value !== "5" || document.querySelector("#form_packid").value !== "8" || _v5(document.querySelector("#costy")) !== "Free" || !_v7(document).length || _v7(document).some(_p94 => !_p94.checked)) {
      throw Error("strong_create_guard");
    }
    _v19 = true;
    document.querySelector("#confirm").click();
    return {
      submitted: true
    };
  }
  async function _fn23(_p95) {
    const _v96 = await _fn15(_p95);
    _v18 = {
      account: _p95,
      fields: _fn16(_v96),
      selected: _v9(_v96)
    };
    return {
      account: _fn12(_p95),
      catalog: _fn8(_v96)
    };
  }
  async function _fn24(_p97) {
    const _v98 = document.querySelector(".modal.show");
    if (!_v98 || !_v18 || JSON.stringify(_fn16(_v98)) !== JSON.stringify(_v18.fields) || String(_p97.account.id) !== String(_v18.account.id) || _p97.account.marker !== _v18.account.marker) {
      throw Error("strong_edit_guard");
    }
    const _v99 = new Set(_p97.selected);
    const _v100 = _v7(_v98);
    if (_v99.size < 1 || _v99.size !== _p97.selected.length || _p97.selected.some(_p101 => !_v100.some(_p102 => _p102.value === _p101))) {
      throw Error("strong_invalid_selection");
    }
    for (const _v103 of _v100) {
      if (_v103.checked !== _v99.has(_v103.value)) {
        _v103.click();
      }
    }
    if (!_v10(_v9(_v98), _p97.selected) || JSON.stringify(_fn16(_v98)) !== JSON.stringify(_v18.fields)) {
      throw Error("strong_apply_failed");
    }
    _v18.target = [..._p97.selected];
    return {
      configured: true
    };
  }
  async function _fn25(_p104) {
    const _v105 = document.querySelector(".modal.show");
    if (_v19 || !_v105 || !_v18?.target || _p104.account.marker !== _v18.account.marker || !_v10(_v9(_v105), _v18.target) || JSON.stringify(_fn16(_v105)) !== JSON.stringify(_v18.fields)) {
      throw Error("strong_save_guard");
    }
    _v19 = true;
    _v105.querySelector("#confirm").click();
    await _v3(() => document.querySelector(".swal2-success") || document.querySelector(".swal2-error"));
    if (document.querySelector(".swal2-error")) {
      throw Error("strong_save_rejected");
    }
    return {
      saved: true
    };
  }
  async function _fn26(_p106) {
    const _v107 = await _v3(() => document.querySelector("#filter_search"));
    _v107.value = _p106.username;
    _v107.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    _v107.dispatchEvent(new KeyboardEvent("keyup", {
      bubbles: true,
      key: "Enter"
    }));
    return _v3(() => {
      const _v108 = [...document.querySelectorAll("table tbody tr")].filter(_p112 => _v5(_p112.cells[1]) === _p106.username && _v5(_p112.cells[2]) === "ych2025iptv" && _v5(_p112.cells[5]) === "Demo");
      if (_v108.length !== 1) {
        return null;
      }
      const _v109 = _v108[0];
      const _v110 = Number(_v5(_v109.cells[4]));
      const _v111 = _v5(_v109.cells[0]);
      if (!Number.isFinite(_v110) || !/^#?\d+$/.test(_v111)) {
        return null;
      } else {
        return {
          username: _p106.username,
          credits: _v110,
          type: "Demo",
          ledgerId: _v111.replace(/^#/, "")
        };
      }
    });
  }
  chrome.runtime.onMessage.addListener((_p113, _p114, _p115) => {
    if (_p114.id !== chrome.runtime.id || _p113.type !== "iptv-strong-command") {
      return;
    }
    const _v116 = {
      ping: () => ({
        version: "0.4.5",
        documentToken: _v2
      }),
      prepare: _fn20,
      configure: _fn21,
      submitCreate: _fn22,
      find: _fn14,
      inspect: _fn23,
      apply: _fn24,
      save: _fn25,
      ledger: _fn26
    }[_p113.action];
    if (_v116) {
      Promise.resolve().then(() => _v116(_p113.args || {})).then(_p117 => _p115({
        ok: true,
        result: _p117
      })).catch(_p118 => _p115({
        ok: false,
        error: /^strong_[a-z_]+$/.test(_p118.message) ? _p118.message : "strong_operation_stopped"
      }));
      return true;
    }
  });
})();