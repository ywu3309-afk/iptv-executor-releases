/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
export const servers = Object.freeze([{
  id: "LION",
  rank: 1,
  origin: "https://lion2.bycdn.network",
  createPath: "/devices/m3u/create",
  family: "lion",
  trialLabel: "1 Day (12hours trial) (0 cds)",
  hours: 12
}, {
  id: "MEGA",
  rank: 2,
  origin: "https://megaott.net",
  createPath: "/subscriptions/lines/add",
  family: "mega",
  trialLabel: "24 Hours - 0 Credits",
  hours: 24
}, {
  id: "DINO",
  rank: 3,
  origin: "https://www.tvpluspanel.ru",
  origins: ["https://www.tvpluspanel.ru", "https://tvpluspanel.ru"],
  createPath: "/addnew?t=lines",
  family: "classic",
  trialLabel: "1 Day",
  hours: 24
}, {
  id: "TREX",
  rank: 4,
  origin: "https://activationpanel.ru",
  origins: ["https://activationpanel.ru", "https://activationpanel.net"],
  createPath: "/addnew?t=lines",
  family: "classic",
  trialLabel: "1 Day",
  hours: 24
}, {
  id: "STRONG",
  rank: 5,
  origin: "https://8k.cms-only.ru",
  origins: ["https://8k.cms-only.ru", "https://8k.online-cms.ru"],
  createPath: "/addnew?t=lines",
  family: "strong",
  trialLabel: "1 Day",
  hours: 24
}]);
export const defaultServer = "MEGA";
export const defaultSelection = "all";
export const provisioningPolicy = Object.freeze({
  mode: "browser_with_api_evaluation",
  apiCreateEnabled: false,
  allowCredits: false,
  allowDemoTickets: true
});
export function serverById(_p1) {
  const _v2 = servers.find(_p3 => _p3.id === _p1);
  if (!_v2) {
    throw Error("unknown_server");
  }
  return _v2;
}
export function serverForUrl(_p4) {
  try {
    const _v5 = new URL(_p4);
    return servers.find(_p6 => (_p6.origins || [_p6.origin]).includes(_v5.origin)) || null;
  } catch {
    return null;
  }
}
export function freeTrialCheck(_p7, _p8) {
  const _v9 = serverById(_p7);
  if (!(_v9.origins || [_v9.origin]).includes(_p8.origin) || _p8.trialLabel !== _v9.trialLabel) {
    return {
      ok: false,
      reason: "套餐或后台不匹配"
    };
  } else if (/ticket/i.test(_p8.price || "")) {
    if (!provisioningPolicy.allowDemoTickets || !/^1\s+Ticket$/i.test((_p8.price || "").trim())) {
      return {
        ok: false,
        reason: "试用费用不明确或超过一次一张券"
      };
    } else if (!Number.isInteger(_p8.ticketsRemaining) || _p8.ticketsRemaining < 1) {
      return {
        ok: false,
        reason: "允许消耗试用券；可用券数量尚未确认或不足"
      };
    } else {
      return {
        ok: true,
        reason: "允许消耗 1 张试用券；不得扣积分",
        cost: {
          credits: 0,
          tickets: 1
        }
      };
    }
  } else if (/^(?:Free|0(?:\.0+)?(?:\s*(?:Credits|CDS))?)$/i.test((_p8.price || "").trim())) {
    if (!Number.isInteger(_p8.remaining) || _p8.remaining < 1) {
      return {
        ok: false,
        reason: "免费名额尚未确认或已用完"
      };
    } else {
      return {
        ok: true,
        reason: "免费价格及名额预检通过；仍需模板与发号验收"
      };
    }
  } else {
    return {
      ok: false,
      reason: "未确认零积分价格"
    };
  }
}