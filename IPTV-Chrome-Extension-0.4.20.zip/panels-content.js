/* IPTV browser executor 0.4.20; source maps intentionally omitted. */
(() => {
  if (globalThis.__iptvPanelListener) {
    return;
  }
  globalThis.__iptvPanelListener = true;
  let _v1 = "start";
  const _v2 = {
    "https://lion2.bycdn.network": {
      id: "LION",
      family: "lion",
      path: "/devices/m3u/create",
      trial: "1 Day (12hours trial) (0 cds)"
    },
    "https://www.tvpluspanel.ru": {
      id: "DINO",
      family: "classic",
      path: "/addnew",
      trial: "1 Day"
    },
    "https://tvpluspanel.ru": {
      id: "DINO",
      family: "classic",
      path: "/addnew",
      trial: "1 Day"
    },
    "https://activationpanel.ru": {
      id: "TREX",
      family: "classic",
      path: "/addnew",
      trial: "1 Day"
    },
    "https://8k.cms-only.ru": {
      id: "STRONG",
      family: "strong",
      path: "/addnew",
      trial: "1 Day"
    },
    // STRONG 换的新域名，两个都认
    "https://8k.online-cms.ru": {
      id: "STRONG",
      family: "strong",
      path: "/addnew",
      trial: "1 Day"
    }
  }[location.origin];
  if (!_v2) {
    return;
  }
  const _v3 = _p9 => !!_p9.getClientRects().length;
  const _v4 = async _p10 => {
    const _v11 = Date.now() + 15000;
    while (Date.now() < _v11) {
      const _v12 = _p10();
      if (_v12) {
        return _v12;
      }
      await new Promise(_p13 => setTimeout(_p13, 180));
    }
    throw Error("页面未就绪");
  };
  const _v5 = () => {
    const _v14 = [...document.querySelectorAll("p")].filter(_p17 => _p17.innerText.trim() === "Remaining Demo");
    if (_v14.length !== 1) {
      return null;
    }
    const _v15 = _v14[0].parentElement;
    const _v16 = _v15.querySelector("h5")?.innerText || _v15.parentElement.querySelector("h5")?.innerText || "";
    if (/^\d+$/.test(_v16.trim())) {
      return Number(_v16);
    } else {
      return null;
    }
  };
  const _v6 = () => {
    const _v18 = [...document.querySelectorAll("p")].find(_p20 => _p20.innerText.trim() === "Demo Tickets");
    const _v19 = _v18?.parentElement?.querySelector("h5")?.innerText || _v18?.parentElement?.parentElement?.querySelector("h5")?.innerText || "";
    if (/^-?\d+$/.test(_v19.trim())) {
      return Number(_v19);
    } else {
      return null;
    }
  };
  const _v7 = () => {
    const _v21 = {
      live: [],
      movies: [],
      series: [],
      mixed: []
    };
    for (const _v22 of document.querySelectorAll("input[type=checkbox]")) {
      let _v23 = "";
      let _v24;
      if (_v2.family === "lion") {
        _v23 = _v22.closest("label")?.innerText.trim() || "";
        if (!_v23) {
          continue;
        }
        _v24 = /^SRS\s*[-|]/i.test(_v23) ? "series" : /^VOD\s*[-|]/i.test(_v23) ? "movies" : "live";
      } else {
        if (!/^(?:pack|vod)-fill-\d+$/.test(_v22.id)) {
          continue;
        }
        _v23 = document.querySelector("label[for=\"" + _v22.id + "\"]")?.innerText.trim() || _v22.parentElement.innerText.trim();
        _v23 = _v23.replace(/^\d+\s*-\s*/, "");
        if (_v22.id.startsWith("pack-")) {
          _v24 = "live";
        } else if (/MOVIES\s*&\s*SERIES/i.test(_v23)) {
          _v24 = "mixed";
        } else if (/\b(?:SERIE[S]?|SRS)\b/i.test(_v23)) {
          _v24 = "series";
        } else if (/\b(?:MOVIES|VOD)\b/i.test(_v23)) {
          _v24 = "movies";
        } else {
          _v24 = "mixed";
        }
      }
      _v21[_v24].push({
        id: _v22.value,
        label: _v23,
        selected: _v22.checked
      });
    }
    return _v21;
  };
  async function _fn8() {
    if (location.pathname !== _v2.path) {
      throw Error("不在试用表单");
    }
    let _v25 = "";
    let _v26 = "";
    if (_v2.family === "lion") {
      const _v28 = [...document.querySelectorAll("button[role=combobox]")];
      if (!_v28.length) {
        throw Error("套餐控件缺失");
      }
      _v1 = "lion_open";
      _v28[0].dispatchEvent(new PointerEvent("pointerdown", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      const _v29 = await _v4(() => [...document.querySelectorAll("[role=option]")].find(_p30 => _v3(_p30) && _p30.textContent.replace(/\s+/g, " ").trim() === _v2.trial));
      _v1 = "lion_select";
      _v29.dispatchEvent(new PointerEvent("pointerdown", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      _v29.dispatchEvent(new PointerEvent("pointerup", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      await _v4(() => _v28[0].textContent.replace(/\s+/g, " ").trim() === _v2.trial);
      _v25 = _v2.trial;
      _v26 = [...document.querySelectorAll("div")].find(_p31 => !_p31.childElementCount && _p31.textContent.trim().toLowerCase() === "total credit")?.nextElementSibling?.textContent.trim() || "";
    } else if (_v2.family === "classic") {
      _v1 = "classic_select";
      const _v32 = await _v4(() => document.querySelector("#add_sub"));
      const _v33 = [..._v32.options].find(_p34 => _p34.text.trim() === _v2.trial);
      if (!_v33) {
        throw Error("试用套餐缺失");
      }
      _v32.value = _v33.value;
      _v32.dispatchEvent(new Event("change", {
        bubbles: true
      }));
      _v25 = _v33.text.trim();
      _v26 = await _v4(() => document.querySelector("#costy")?.innerText.trim());
    } else {
      _v1 = "strong_open";
      (await _v4(() => [...document.querySelectorAll("[role=combobox]")].find(_p36 => _p36.classList.contains("choices")))).click();
      const _v35 = await _v4(() => [...document.querySelectorAll("[role=option][data-value]")].find(_p37 => _v3(_p37) && _p37.textContent.trim() === _v2.trial));
      _v1 = "strong_select";
      _v35.dispatchEvent(new MouseEvent("mousedown", {
        bubbles: true,
        button: 0
      }));
      _v25 = _v2.trial;
      _v26 = await _v4(() => document.querySelector("#costy")?.innerText.trim());
    }
    _v1 = "catalog";
    const _v27 = await _v4(() => {
      const _v38 = _v7();
      if (_v38.live.length) {
        return _v38;
      } else {
        return null;
      }
    });
    return {
      summary: {
        origin: location.origin,
        trialLabel: _v25,
        price: _v26,
        remaining: _v5(),
        ticketsRemaining: _v6()
      },
      catalog: _v27
    };
  }
  chrome.runtime.onMessage.addListener((_p39, _p40, _p41) => {
    if (_p40.id === chrome.runtime.id && _p39.type === "iptv-panel-command" && _p39.server === _v2.id) {
      if (_p39.action === "ping") {
        _p41({
          ok: true,
          result: {
            server: _v2.id
          }
        });
        return;
      }
      if (_p39.action !== "prepare") {
        _p41({
          ok: false,
          error: "该适配器尚未完成发号验收"
        });
        return;
      }
      _fn8().then(_p42 => _p41({
        ok: true,
        result: _p42
      })).catch(() => _p41({
        ok: false,
        error: "panel_preflight_" + _v1
      }));
      return true;
    }
  });
})();