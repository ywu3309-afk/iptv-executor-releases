$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$RegistrationPath = Join-Path $env:LOCALAPPDATA 'IPTVExecutor\installation.json'

function Get-NodeRuntime([string]$Root) {
  $portable = Join-Path $Root '.runtime\node\node.exe'
  if (Test-Path -LiteralPath $portable) {
    try { if ((& $portable -p "process.versions.node").Trim() -eq '24.19.0') { return $portable } } catch {}
  }
  $system = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($system) {
    try {
      $version = (& $system.Source -p "process.versions.node").Trim()
      if ($version -eq '24.19.0') { return $system.Source }
    } catch {}
  }
  return $null
}

function Sync-OuterLauncher([string]$Root) {
  if (-not $Root -or ([System.IO.Path]::GetFileName($Root.TrimEnd('\')) -ne 'System Files')) { return }
  $source = Join-Path $Root 'IPTV Automation.exe'
  $destination = Join-Path (Split-Path -Parent $Root) 'IPTV Automation.exe'
  if (-not (Test-Path -LiteralPath $source) -or -not (Test-Path -LiteralPath $destination)) { return }
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $sourceHash = [Convert]::ToBase64String($sha.ComputeHash([System.IO.File]::ReadAllBytes($source)))
    $destinationHash = [Convert]::ToBase64String($sha.ComputeHash([System.IO.File]::ReadAllBytes($destination)))
  } finally { $sha.Dispose() }
  if ($sourceHash -eq $destinationHash) { return }

  try {
    Copy-Item -LiteralPath $source -Destination $destination -Force
    Write-Host 'Launcher synchronized with the installed executor.'
    return
  } catch {}

  $helper = Join-Path $env:TEMP ('iptv-launcher-sync-' + [guid]::NewGuid().ToString('N') + '.ps1')
  $source64 = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($source))
  $destination64 = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($destination))
  @'
param([string]$Source64,[string]$Destination64)
$ErrorActionPreference = 'Stop'
$source = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($Source64))
$destination = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($Destination64))
$copied = $false
for ($attempt = 0; $attempt -lt 600; $attempt++) {
  try {
    Copy-Item -LiteralPath $source -Destination $destination -Force
    $copied = $true
    break
  } catch {}
  Start-Sleep -Milliseconds 200
}
if (-not $copied) { exit 1 }
Start-Process -FilePath $destination
Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
'@ | Set-Content -LiteralPath $helper -Encoding UTF8
  $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $helper + '" -Source64 ' + $source64 + ' -Destination64 ' + $destination64
  Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden
  Write-Host 'Launcher update staged. Close this window once; the current launcher will reopen automatically.'
}

try {
  $TargetRoot = $ProjectRoot
  if (Test-Path -LiteralPath $RegistrationPath) {
    # Windows PowerShell 5.1 treats UTF-8 files without a BOM as the active
    # ANSI code page.  A Chinese installation path can then corrupt a JSON
    # backslash before ConvertFrom-Json sees it.  Node writes this file as
    # UTF-8, so decode it explicitly on every supported Windows version.
    $registrationJson = [System.IO.File]::ReadAllText($RegistrationPath, [System.Text.Encoding]::UTF8)
    $registration = $registrationJson | ConvertFrom-Json
    if (-not $registration.root -or -not (Test-Path -LiteralPath (Join-Path $registration.root 'scripts\executor-wizard.mjs'))) {
      Write-Host 'The existing installation needs repair. Customer data will be preserved automatically.' -ForegroundColor Yellow
      & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File (Join-Path $ProjectRoot 'scripts\install-windows-executor.ps1') -RecoverAndStart
      exit $LASTEXITCODE
    }
    $TargetRoot = [string]$registration.root
  }

  $runtime = Get-NodeRuntime $TargetRoot
  $dependenciesReady = Test-Path -LiteralPath (Join-Path $TargetRoot 'node_modules\whatsapp-web.js\package.json')
  $dataReady = Test-Path -LiteralPath (Join-Path $TargetRoot 'data\automation-config.json')
  if ($runtime -and $dependenciesReady -and $dataReady) {
    & $runtime (Join-Path $TargetRoot 'scripts\launch-executor-wizard.mjs')
    $exitCode = $LASTEXITCODE
    if ($exitCode -eq 0) {
      try { Sync-OuterLauncher $TargetRoot } catch { Write-Host ('Launcher synchronization will retry on the next start: ' + $_.Exception.Message) -ForegroundColor Yellow }
    }
    exit $exitCode
  }

  Write-Host 'First start: preparing the executor automatically. Please keep this window open.'
  & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File (Join-Path $TargetRoot 'scripts\install-windows-executor.ps1')
  $exitCode = $LASTEXITCODE
  if ($exitCode -eq 0) {
    try { Sync-OuterLauncher $TargetRoot } catch { Write-Host ('Launcher synchronization will retry on the next start: ' + $_.Exception.Message) -ForegroundColor Yellow }
  }
  exit $exitCode
} catch {
  Write-Host ''
  Write-Host ('One-click start did not complete: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host 'Keep the original executor folder and contact your administrator with this message.'
  exit 1
}
