param([switch]$DryRun,[switch]$Upgrade,[switch]$StopExecutor,[switch]$RegisterExisting,[switch]$RepairAndStart,[switch]$RecoverAndStart,[switch]$FreshInstall,[string]$ExistingInstallation = '')
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$RuntimeRoot = Join-Path $ProjectRoot '.runtime'
$PortableNode = Join-Path $RuntimeRoot 'node\node.exe'
$PortableNpm = Join-Path $RuntimeRoot 'node\npm.cmd'
$RequiredNodeVersion = '24.19.0'
$RequiredNodeArchiveHash = '57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73'

function Get-UsableRuntime {
  $candidates = @()
  if (Test-Path -LiteralPath $PortableNode) { $candidates += $PortableNode }
  if ($ExistingInstallation) {
    $legacyNode = Join-Path $ExistingInstallation '.runtime\node\node.exe'
    if (Test-Path -LiteralPath $legacyNode) { $candidates += $legacyNode }
  }
  $registrationPath = Join-Path $env:LOCALAPPDATA 'IPTVExecutor\installation.json'
  if (Test-Path -LiteralPath $registrationPath) {
    try {
      # registration.json is written by Node as UTF-8 without a BOM.  Decode
      # it explicitly because Windows PowerShell 5.1 otherwise uses the
      # current ANSI code page and may corrupt Chinese folder names.
      $registrationJson = [System.IO.File]::ReadAllText($registrationPath, [System.Text.Encoding]::UTF8)
      $registration = $registrationJson | ConvertFrom-Json
      $registeredNode = Join-Path $registration.root '.runtime\node\node.exe'
      if (Test-Path -LiteralPath $registeredNode) { $candidates += $registeredNode }
    } catch { Write-Host 'The saved installation registration needs repair. The original customer data will not be replaced.' -ForegroundColor Yellow }
  }
  $systemNode = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($systemNode) { $candidates += $systemNode.Source }
  foreach ($candidate in $candidates | Select-Object -Unique) {
    try {
      $version = (& $candidate -p "process.versions.node").Trim()
      $nearbyNpm = Join-Path (Split-Path -Parent $candidate) 'npm.cmd'
      $npm = if (Test-Path -LiteralPath $nearbyNpm) { $nearbyNpm } else { (Get-Command npm.cmd -ErrorAction SilentlyContinue).Source }
      if ($version -eq $RequiredNodeVersion -and $npm) { return @{ Node = $candidate; Npm = $npm; Version = $version } }
    } catch {}
  }
  return $null
}

function Install-PortableNode([string]$DestinationRuntimeRoot = $RuntimeRoot) {
  if (-not [Environment]::Is64BitOperatingSystem) { throw 'This package currently requires 64-bit Windows 10 or Windows 11.' }
  $destinationNode = Join-Path $DestinationRuntimeRoot 'node\node.exe'
  $destinationNpm = Join-Path $DestinationRuntimeRoot 'node\npm.cmd'
  New-Item -ItemType Directory -Force -Path $DestinationRuntimeRoot | Out-Null
  $release = 'v' + $RequiredNodeVersion
  $filename = "node-$release-win-x64.zip"
  $base = "https://nodejs.org/dist/$release"
  $zip = Join-Path $DestinationRuntimeRoot $filename
  $checksums = Join-Path $DestinationRuntimeRoot 'SHASUMS256.txt'
  Write-Host "Downloading pinned official Node.js $RequiredNodeVersion..."
  Invoke-WebRequest -Uri "$base/$filename" -OutFile $zip -UseBasicParsing
  Invoke-WebRequest -Uri "$base/SHASUMS256.txt" -OutFile $checksums -UseBasicParsing
  $expectedLine = Get-Content -LiteralPath $checksums | Where-Object { $_ -match "\s$([regex]::Escape($filename))$" } | Select-Object -First 1
  if (-not $expectedLine) { throw 'Official Node.js checksum was not found.' }
  $expected = ($expectedLine -split '\s+')[0].ToLowerInvariant()
  if ($expected -ne $RequiredNodeArchiveHash) { throw 'The official checksum does not match this verified executor release.' }
  $actual = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw 'Node.js checksum verification failed.' }
  $stage = Join-Path $DestinationRuntimeRoot 'extracting'
  if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
  Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force
  $expanded = Get-ChildItem -LiteralPath $stage -Directory | Select-Object -First 1
  if (-not $expanded) { throw 'Node.js archive did not contain the expected folder.' }
  $nodeFolder = Join-Path $DestinationRuntimeRoot 'node'
  if (Test-Path -LiteralPath $nodeFolder) { Remove-Item -LiteralPath $nodeFolder -Recurse -Force }
  Move-Item -LiteralPath $expanded.FullName -Destination $nodeFolder
  Remove-Item -LiteralPath $stage -Recurse -Force
  Remove-Item -LiteralPath $zip,$checksums -Force
  if (-not (Test-Path -LiteralPath $destinationNode) -or -not (Test-Path -LiteralPath $destinationNpm)) { throw 'The portable Node.js runtime was not installed completely.' }
}

function Request-OriginalInstallationPath {
  Write-Host ''
  Write-Host 'The original IPTV Automation folder was moved or its saved path is no longer valid.' -ForegroundColor Yellow
  Write-Host 'Select the ORIGINAL folder that contains the existing customer data. Do not select this newly downloaded package.'
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select the original IPTV Automation folder that contains your existing customer data.'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dialog.SelectedPath }
  } catch {}
  return (Read-Host 'Original IPTV Automation folder (Enter to cancel)').Trim().Trim('"')
}

Set-Location -LiteralPath $ProjectRoot
$maintenanceMode = $RegisterExisting -or $Upgrade -or $StopExecutor -or $RepairAndStart -or $RecoverAndStart
$needsLegacyRegistration = $false
if (-not $DryRun -and $maintenanceMode) {
  $registrationPath = Join-Path $env:LOCALAPPDATA 'IPTVExecutor\installation.json'
  $needsLegacyRegistration = $RegisterExisting -or -not (Test-Path -LiteralPath $registrationPath)
  if ($needsLegacyRegistration -and -not $ExistingInstallation) {
    Write-Host 'First upgrade from an older version: select the ORIGINAL executor folder that contains your existing data.'
    Write-Host 'Paste its full folder path below. Do not select this newly downloaded package or the data subfolder.'
    $ExistingInstallation = Request-OriginalInstallationPath
    if (-not $ExistingInstallation) { Write-Host 'Cancelled. No data or registration was changed.'; exit 1 }
  }
}
$runtime = Get-UsableRuntime
if ($DryRun) {
  $result = [ordered]@{
    packageRoot = $ProjectRoot
    packageJson = Test-Path -LiteralPath (Join-Path $ProjectRoot 'package.json')
    packageLock = Test-Path -LiteralPath (Join-Path $ProjectRoot 'package-lock.json')
    sbom = Test-Path -LiteralPath (Join-Path $ProjectRoot 'sbom.cdx.json')
    initializer = Test-Path -LiteralPath (Join-Path $ProjectRoot 'scripts\initialize-executor.mjs')
    launcher = Test-Path -LiteralPath (Join-Path $ProjectRoot 'scripts\launch-executor-wizard.mjs')
    runtimeReady = [bool]$runtime
    safeDataIncluded = Test-Path -LiteralPath (Join-Path $ProjectRoot 'data')
  }
  $result | ConvertTo-Json -Compress
  exit 0
}

try {
  if ($FreshInstall -and $maintenanceMode) { throw 'Fresh installation cannot be combined with repair, recovery, update, or stop.' }
  if (-not $runtime) {
    Install-PortableNode
    $runtime = Get-UsableRuntime
  }
  if (-not $runtime) { throw 'The verified Node.js 24.19.0 runtime could not be prepared.' }
  $env:PATH = (Split-Path -Parent $runtime.Node) + ';' + $env:PATH
  $registrationPath = Join-Path $env:LOCALAPPDATA 'IPTVExecutor\installation.json'
  if ($FreshInstall) {
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --reset-unavailable
    if ($LASTEXITCODE -ne 0) { throw 'A new installation was not started. Existing customer data may still be recoverable; locate the original folder instead.' }
    Write-Host 'The unavailable installation registration was archived. A new empty installation will now be created.' -ForegroundColor Yellow
  }
  if ($maintenanceMode -and -not $needsLegacyRegistration -and (Test-Path -LiteralPath $registrationPath)) {
    $previousErrorAction = $ErrorActionPreference
    try {
      $ErrorActionPreference = 'Continue'
      & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --maintenance-check *> $null
      $maintenanceCheckExit = $LASTEXITCODE
    } finally { $ErrorActionPreference = $previousErrorAction }
    if ($maintenanceCheckExit -ne 0) {
      if (-not $ExistingInstallation) { $ExistingInstallation = Request-OriginalInstallationPath }
      if (-not $ExistingInstallation) { throw 'Registration repair was cancelled. No data or registration was changed.' }
      & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --repair $ExistingInstallation
      if ($LASTEXITCODE -ne 0) { throw 'The saved installation could not be repaired. Select the original folder that still contains your existing customer data.' }
      Write-Host 'The saved installation location was repaired. Existing customer data remains unchanged.' -ForegroundColor Green
    }
  }
  $unlockMode = if ($maintenanceMode) { '--assert-maintenance-unlocked' } else { '--assert-unlocked' }
  & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') $unlockMode
  if ($LASTEXITCODE -ne 0) { throw 'An executor upgrade lock is present. Wait for it to finish; after interruption, contact support before proceeding.' }
  if ($needsLegacyRegistration) {
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --adopt $ExistingInstallation
    if ($LASTEXITCODE -ne 0) { throw 'The original installation could not be registered. No existing data was initialized, copied, or replaced.' }
    Write-Host 'Original data location registered. Future upgrades will keep this location.' -ForegroundColor Green
    if ($RegisterExisting -and -not $Upgrade -and -not $StopExecutor) { exit 0 }
  }
  if ($RepairAndStart) {
    $registrationJson = [System.IO.File]::ReadAllText($registrationPath, [System.Text.Encoding]::UTF8)
    $registration = $registrationJson | ConvertFrom-Json
    & $runtime.Node (Join-Path ([string]$registration.root) 'scripts\launch-executor-wizard.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'The repaired executor did not start.' }
    exit 0
  }
  if ($RecoverAndStart) {
    Write-Host 'Recovering the existing installation while preserving customer data.' -ForegroundColor Yellow
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\stop-executor.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'The existing executor could not be stopped safely. No program files were changed.' }
    Write-Host 'Existing executor processes stopped for safe recovery.' -ForegroundColor Green
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\upgrade-executor.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'Automatic recovery did not complete. The verified backup and original customer data were preserved.' }
    $registrationJson = [System.IO.File]::ReadAllText($registrationPath, [System.Text.Encoding]::UTF8)
    $registration = $registrationJson | ConvertFrom-Json
    $targetRoot = [string]$registration.root
    $targetNode = Join-Path $targetRoot '.runtime\node\node.exe'
    $targetNpm = Join-Path $targetRoot '.runtime\node\npm.cmd'
    if (-not (Test-Path -LiteralPath $targetNode) -or -not (Test-Path -LiteralPath $targetNpm)) {
      $sourceNodeFolder = Join-Path $ProjectRoot '.runtime\node'
      $targetNodeFolder = Join-Path $targetRoot '.runtime\node'
      if ((Test-Path -LiteralPath (Join-Path $sourceNodeFolder 'node.exe')) -and (Test-Path -LiteralPath (Join-Path $sourceNodeFolder 'npm.cmd'))) {
        if (Test-Path -LiteralPath $targetNodeFolder) { Remove-Item -LiteralPath $targetNodeFolder -Recurse -Force }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $targetNodeFolder) | Out-Null
        Copy-Item -LiteralPath $sourceNodeFolder -Destination $targetNodeFolder -Recurse -Force
      } else {
        Install-PortableNode (Join-Path $targetRoot '.runtime')
      }
    }
    if (-not (Test-Path -LiteralPath (Join-Path $targetRoot 'node_modules\whatsapp-web.js\package.json'))) {
      Write-Host 'Restoring required runtime components...'
      Push-Location -LiteralPath $targetRoot
      try { & $targetNpm ci --omit=dev --no-audit --no-fund --ignore-scripts } finally { Pop-Location }
      if ($LASTEXITCODE -ne 0) { throw 'Required runtime components could not be restored. Customer data remains unchanged.' }
    }
    Write-Host 'Existing customer data and settings were preserved.' -ForegroundColor Green
    Write-Host 'Recovery completed. Starting IPTV Automation.' -ForegroundColor Green
    & $targetNode (Join-Path $targetRoot 'scripts\launch-executor-wizard.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'The recovered executor did not start.' }
    exit 0
  }
  if ($StopExecutor) {
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\stop-executor.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'The executor could not be safely stopped. Review the message above.' }
    exit 0
  }
  if ($Upgrade) {
    & $runtime.Node (Join-Path $ProjectRoot 'scripts\upgrade-executor.mjs')
    if ($LASTEXITCODE -ne 0) { throw 'Safe upgrade did not complete. Review the message above. Your original data has not been replaced.' }
    Write-Host 'Upgrade completed. Open IPTV Automation.exe to start the service.' -ForegroundColor Green
    exit 0
  }
  & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --check
  if ($LASTEXITCODE -ne 0) { throw 'Another executor installation is already registered. Use the safe upgrade entry in this new package. Do not initialize another data directory.' }
  Write-Host 'Installing the executor runtime dependencies. This does not require administrator rights...'
  & $runtime.Npm ci --omit=dev --no-audit --no-fund --ignore-scripts
  if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
  & $runtime.Node (Join-Path $ProjectRoot 'scripts\initialize-executor.mjs')
  if ($LASTEXITCODE -ne 0) { throw 'Safe first-run initialization failed.' }
  & $runtime.Node (Join-Path $ProjectRoot 'scripts\installation-state.mjs') --register
  if ($LASTEXITCODE -ne 0) { throw 'Installation directory could not be registered safely.' }
  Write-Host 'Installation completed. Automatic reception and browser changes remain disabled until configured.' -ForegroundColor Green
  & $runtime.Node (Join-Path $ProjectRoot 'scripts\launch-executor-wizard.mjs')
  if ($LASTEXITCODE -ne 0) { throw 'The local connection wizard did not start.' }
} catch {
  Write-Host ''
  Write-Host ('Installation did not complete: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host 'Keep this window open and send the message above to your administrator. Do not send keys or the data folder.'
  exit 1
}
