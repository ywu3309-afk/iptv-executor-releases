@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\one-click-executor.ps1"
set "executorExit=%errorlevel%"
if not "%executorExit%"=="0" pause
exit /b %executorExit%
endlocal
