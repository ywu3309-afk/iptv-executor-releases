@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-windows-executor.ps1" -StopExecutor
set "executorExit=%errorlevel%"
pause
exit /b %executorExit%
