/* IPTV protected browser asset 0.3.24; source maps intentionally omitted. */
(() => {
  if (window.IPTV_SERVICE_PERMISSIONS?.aiReception === false) {
    document.getElementById("ai")?.setAttribute("hidden", "");
    return;
  }
  const fn = arg => document.getElementById(arg);
  const options = {
    en: "English",
    de: "Deutsch",
    fr: "Français",
    es: "Español",
    pt: "Português",
    ar: "العربية",
    zh: "中文",
    it: "Italiano",
    sv: "Svenska"
  };
  const options2 = {
    welcome: "问候",
    trial: "试用意向",
    edit: "频道修改",
    accept: "同意",
    decline: "拒绝",
    support: "支持",
    clarify: "需澄清",
    pricing: "价格",
    payment: "付款"
  };
  const options3 = {
    ollama: {
      engine: "embedded",
      name: "IPTV 本地智能体",
      url: "http://127.0.0.1:8787/v1",
      model: "deepseek-v4.1-flash",
      dailyLimit: 10000,
      maxTokens: 0
    },
    langbot: {
      engine: "langbot",
      name: "LangBot RAG",
      url: "",
      model: "",
      dailyLimit: 1000,
      maxTokens: 500
    },
    deepseek: {
      engine: "embedded",
      name: "DeepSeek IPTV 智能体",
      url: "https://api.deepseek.com",
      model: "deepseek-chat"
    },
    qwen: {
      engine: "embedded",
      name: "通义千问 IPTV 智能体",
      url: "https://dashscope.aliyuncs.com/compatible-mode/v1",
      model: "qwen-plus"
    },
    glm: {
      engine: "embedded",
      name: "智谱 GLM IPTV 智能体",
      url: "https://open.bigmodel.cn/api/paas/v4",
      model: ""
    },
    doubao: {
      engine: "embedded",
      name: "豆包 IPTV 智能体",
      url: "https://ark.cn-beijing.volces.com/api/v3",
      model: ""
    },
    moonshot: {
      engine: "embedded",
      name: "Kimi IPTV 智能体",
      url: "https://api.moonshot.cn/v1",
      model: ""
    }
  };
  let list = [];
  let value = false;
  let value2 = false;
  function fn2(arg, arg2 = false) {
    const value3 = ["embedded", "openai", "langbot"].includes(arg) ? arg : "embedded";
    const value4 = value3 === "langbot";
    const value5 = value3 === "embedded";
    fn("ai-engine").value = value3;
    fn("ai-url-label").textContent = value4 ? "LangBot 服务地址" : "模型地址";
    fn("ai-model-label").textContent = value4 ? "LangBot Bot UUID" : "模型名称 / 接入点 ID";
    fn("ai-key-label").textContent = value4 ? "LangBot HMAC Secret" : "API Key（本机网关建议填写）";
    fn("ai-url").placeholder = value4 ? "https://your-langbot.example" : "https://api.deepseek.com";
    fn("ai-model").placeholder = value4 ? "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" : "以服务商控制台提供的名称为准";
    fn("ai-tokens").closest("label").hidden = value4;
    fn("ai-hint").textContent = value4 ? "高级选项：连接单独部署的 LangBot。它只负责知识检索、意图理解和回复草稿，不获得服务器操作权限。" : value5 ? arg2 ? "内置 IPTV 知识库在本电脑检索，消息由本机网关生成；无需另外安装 LangBot、Python 或 Docker。" : "内置 IPTV 知识库先在本电脑检索，再把脱敏文字和命中的客户资料交给所选模型生成回复。无需另外部署 LangBot。" : arg2 ? "基础模式只调用本机模型，不使用内置 IPTV 知识检索。" : "基础模式只调用兼容模型 API，不使用内置 IPTV 知识检索。";
  }
  function fn3(aiConfig = {
    engine: "embedded"
  }) {
    const value3 = ["embedded", "openai", "langbot"].includes(aiConfig.engine) ? aiConfig.engine : "openai";
    const value4 = value3 !== "langbot" && (aiConfig.local || /^http:\/\/(?:127\.0\.0\.1|localhost):\d+\/v1\/?$/.test(aiConfig.baseUrl || ""));
    fn("ai-name").value = aiConfig.name || "";
    fn("ai-url").value = aiConfig.baseUrl || "";
    fn("ai-model").value = aiConfig.model || "";
    fn("ai-key").value = "";
    fn("ai-key").placeholder = value3 === "langbot" ? aiConfig.hasKey ? "已保存 HMAC Secret；留空保留" : "填写 HTTP Bot 的 Inbound Signing Secret" : value4 ? "本机网关的 key（也可留空）" : aiConfig.hasKey ? "已保存密钥；留空保留，填写则替换" : "填写此服务商的 API Key";
    fn("ai-clear-key").checked = false;
    fn("ai-limit").value = aiConfig.dailyLimit || 100;
    fn("ai-tokens").value = aiConfig.maxTokens ?? 500;
    fn("ai-enabled").checked = !!aiConfig.enabled;
    fn2(value3, value4);
  }
  function fn4(arg) {
    if (arg) {
      fn("ai-usage").textContent = "今日已调用 " + arg.today.calls + " 次 · 服务商返回 tokens " + arg.today.tokens + (arg.last ? " · 最近结果：" + (arg.last.ok ? "成功" : arg.last.code) : "");
    }
  }
  async function fn5() {
    if (!value) {
      value = true;
      try {
        const result = await fetch("/api/ai");
        if (!result.ok) {
          throw Error();
        }
        const result2 = await result.json();
        list = result2.profiles;
        fn("ai-profile").replaceChildren(new Option("＋ 新增配置", ""), ...result2.profiles.map(arg => new Option(arg.name, arg.id)));
        fn("ai-profile").value = result2.activeId || "";
        const value3 = result2.profiles.find(arg => arg.id === result2.activeId) || result2.current;
        const aiConfig = options3.ollama;
        const value4 = !value3.configured && !result2.profiles.length ? {
          ...value3,
          engine: aiConfig.engine,
          name: aiConfig.name,
          baseUrl: aiConfig.url,
          model: aiConfig.model,
          dailyLimit: aiConfig.dailyLimit,
          maxTokens: aiConfig.maxTokens,
          local: true
        } : value3;
        fn3(value4);
        fn("ai-current").textContent = result2.runtimeReady ? result2.current.enabled ? result2.current.engine === "langbot" ? "LangBot RAG · " + result2.current.model : result2.current.engine === "embedded" ? "内置知识库 · " + result2.current.model : result2.current.local ? "本地 " + result2.current.model + " · 无外部 API 费用" : "基础模型 · " + result2.current.model : "AI 未启用 · 本地规则" : "接待服务待重启 · 可配置和测试";
        fn4(result2.usage);
        value2 = true;
      } catch {
        fn("ai-current").textContent = "AI 配置正在重试";
      } finally {
        value = false;
      }
    }
  }
  fn("ai-profile").onchange = () => {
    const value3 = list.find(arg => arg.id === fn("ai-profile").value);
    if (value3) {
      fn3(value3);
      fn("ai-provider").value = value3.engine === "langbot" ? "langbot" : "custom";
    } else {
      const aiConfig = options3.ollama;
      fn3({
        engine: aiConfig.engine,
        name: aiConfig.name,
        baseUrl: aiConfig.url,
        model: aiConfig.model,
        dailyLimit: aiConfig.dailyLimit,
        maxTokens: aiConfig.maxTokens,
        local: true
      });
      fn("ai-provider").value = "ollama";
    }
  };
  fn("ai-provider").onchange = () => {
    const aiConfig = options3[fn("ai-provider").value];
    if (aiConfig) {
      fn("ai-profile").value = "";
      fn3({
        engine: aiConfig.engine,
        name: aiConfig.name,
        baseUrl: aiConfig.url,
        model: aiConfig.model,
        dailyLimit: aiConfig.dailyLimit,
        maxTokens: aiConfig.maxTokens,
        local: fn("ai-provider").value === "ollama"
      });
    }
  };
  fn("ai-engine").onchange = () => {
    const value3 = fn("ai-engine").value;
    fn2(value3, value3 !== "langbot" && /^http:\/\/(?:127\.0\.0\.1|localhost):\d+\/v1\/?$/.test(fn("ai-url").value));
    if (value3 === "langbot") {
      fn("ai-provider").value = "langbot";
    } else if (fn("ai-provider").value === "langbot") {
      fn("ai-provider").value = "custom";
    }
  };
  fn("ai-form").onsubmit = async arg => {
    arg.preventDefault();
    fn("ai-save").disabled = true;
    try {
      await post("/api/ai/save", {
        id: fn("ai-profile").value,
        engine: fn("ai-engine").value,
        name: fn("ai-name").value,
        baseUrl: fn("ai-url").value,
        model: fn("ai-model").value,
        apiKey: fn("ai-key").value,
        clearKey: fn("ai-clear-key").checked,
        enabled: fn("ai-enabled").checked,
        dailyLimit: Number(fn("ai-limit").value),
        maxTokens: Number(fn("ai-tokens").value)
      });
      await fn5();
      notice("配置已保存并设为当前。保存本身不调用 AI；只有启用后的客户消息或手动测试才会调用。");
    } catch (conversation) {
      notice(conversation.message);
    } finally {
      fn("ai-save").disabled = false;
    }
  };
  fn("ai-test").onclick = async () => {
    fn("ai-test").disabled = true;
    fn("ai-test-result").textContent = "正在调用已保存的当前引擎…";
    try {
      const result = await post("/api/ai/test", {
        text: fn("ai-test-text").value
      });
      fn("ai-test-result").textContent = "语言：" + (options[result.result.language] || result.result.language) + "\n意图：" + (options2[result.result.kind] || result.result.kind) + "\n\n" + result.result.reply + (result.result.operations.length ? "\n\n" + result.result.operations.map(arg => arg.op + " " + arg.target).join("\n") : "");
      fn4(result.usage);
    } catch (conversation) {
      fn("ai-test-result").textContent = conversation.message;
    } finally {
      fn("ai-test").disabled = false;
    }
  };
  fn5();
  setInterval(() => {
    if (!document.hidden && !value2) {
      fn5();
    }
  }, 15000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && !value2) {
      fn5();
    }
  });
})();