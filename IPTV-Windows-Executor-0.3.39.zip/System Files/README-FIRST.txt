IPTV Automation 0.3.24

Double-click IPTV Automation.exe in the parent folder to start, stop and securely update the service. Customer data, AI keys, WhatsApp sessions, panel sessions, business media and payment evidence are never included in a fresh package.
