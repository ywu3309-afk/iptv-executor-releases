/*
 * 执行端在线更新（online-update-executor）
 *
 * 从 0.3.24 发布包还原。流程：拉 release-manifest.json -> 验签 -> 比版本 ->
 * 下载 zip -> 校验大小和 SHA-256 -> 备份 -> 解压替换。
 *
 * 本版修改：内置的发布公钥换成本地签名密钥对应的公钥（原官方私钥不在手上，
 * 无法用官方密钥签名；换钥后由我们自己签发的 release-manifest.sig 才能通过校验）。
 */

import { createHash as _0x430f4d, createPublicKey as _0x23696e, verify as _0x1f32b9 } from "node:crypto";
import { existsSync as _0x5f1b05, mkdtempSync as _0x129693, mkdirSync as _0x3a0bb0, readFileSync as _0xd69ab3, rmSync as _0x529d0f, writeFileSync as _0x40742c } from "node:fs";
import { tmpdir as _0x2787be } from "node:os";
import { join as _0x5b1bfa, resolve as _0x1760dc } from "node:path";
import { execFileSync as _0x165c79 } from "node:child_process";
import { fileURLToPath as _0x219c5d } from "node:url";
import { existsSync as _0x505fd0, mkdirSync as _0x28f577, readFileSync as _0x303438, writeFileSync as _0x23d6a5, renameSync as _0x15da4f, realpathSync as _0x1f92a1, readdirSync as _0x521dd8, statSync as _0x29d715, unlinkSync as _0x12c1f6 } from "node:fs";
import { randomUUID as _0x979f50 } from "node:crypto";
import { resolve as _0x149643, join as _0xe97c99, dirname as _0x412c26 } from "node:path";
import { homedir as _0x39885b } from "node:os";
import { fileURLToPath as _0x251ec3 } from "node:url";
var R = () => _0xe97c99(process.env.LOCALAPPDATA || _0xe97c99(_0x39885b(), "AppData", "Local"), "IPTVExecutor", "installation.json");
function m(_0x4cb727) {
  let _0x43e4c4 = _0x149643(_0x4cb727);
  if (_0x505fd0(_0x43e4c4)) {
    return _0x1f92a1(_0x43e4c4);
  } else {
    return _0x43e4c4;
  }
}
function b(_0x49391d, _0x289ee4) {
  let _0x1c5470 = m(_0x49391d);
  let _0x50663a = m(_0x289ee4);
  if (process.platform === "win32") {
    return _0x1c5470.toLowerCase() === _0x50663a.toLowerCase();
  } else {
    return _0x1c5470 === _0x50663a;
  }
}
var ge = _0x316021 => _0xe97c99(m(_0x316021), ".executor-upgrade.lock");
function we(_0x39e862) {
  if (!_0x505fd0(_0x39e862)) {
    return null;
  }
  try {
    let _0x53cf4f = JSON.parse(_0x303438(_0x39e862, "utf8"));
    if (_0x53cf4f.schema !== 1 || typeof _0x53cf4f.root != "string" || !_0x53cf4f.root.trim()) {
      throw Error();
    }
    return _0x53cf4f;
  } catch {
    throw Error("installation_registration_invalid: Existing registration must be repaired; do not create empty replacement data.");
  }
}
function K(_0x574276) {
  let _0x192d38 = _0xe97c99(_0x574276, "data");
  if (!_0x505fd0(_0x192d38) || !_0x29d715(_0x192d38).isDirectory()) {
    return false;
  } else {
    return _0x521dd8(_0x192d38, {
      withFileTypes: true
    }).some(_0xda4c91 => _0xda4c91.isFile() && (/\.sqlite(?:3)?$/i.test(_0xda4c91.name) || /(?:config|state)\.json$/i.test(_0xda4c91.name)) && _0x29d715(_0xe97c99(_0x192d38, _0xda4c91.name)).size > 0);
  }
}
function fe(_0x1876ec) {
  return _0x505fd0(_0x1876ec) && _0x29d715(_0x1876ec).isDirectory() && _0x521dd8(_0x1876ec).length > 0;
}
function J(_0x2f48c3) {
  let _0xa59992 = _0xe97c99(_0x2f48c3, "package.json");
  if (!_0x505fd0(_0xa59992)) {
    return false;
  }
  try {
    return ["iptv-windows-executor", "iptv-trial-assistant"].includes(JSON.parse(_0x303438(_0xa59992, "utf8")).name);
  } catch {
    return false;
  }
}
function Q(_0x238b92) {
  return _0x505fd0(_0xe97c99(_0x238b92, "scripts", "executor-wizard.mjs"));
}
function De(_0x25d219) {
  return J(_0x25d219) && _0x505fd0(_0xe97c99(_0x25d219, "scripts", "executor-wizard.mjs")) && _0x505fd0(_0xe97c99(_0x25d219, "scripts", "launch-executor-wizard.mjs")) && K(_0x25d219);
}
function Ue(_0xdfc0bd) {
  return Q(_0xdfc0bd) || J(_0xdfc0bd) && K(_0xdfc0bd);
}
function ye(_0x162356) {
  if (typeof _0x162356 != "string" || !_0x162356.trim()) {
    throw Error("legacy_installation_path_required");
  }
  let _0x2ed8e8 = m(_0x162356.trim());
  let _0x4ce2fc = [_0x2ed8e8, _0xe97c99(_0x2ed8e8, "System Files"), _0xe97c99(_0x2ed8e8, "系统文件")];
  if (_0x505fd0(_0x2ed8e8) && _0x29d715(_0x2ed8e8).isDirectory()) {
    for (let _0x37d650 of _0x521dd8(_0x2ed8e8, {
      withFileTypes: true
    })) {
      if (_0x37d650.isDirectory()) {
        _0x4ce2fc.push(_0xe97c99(_0x2ed8e8, _0x37d650.name));
      }
    }
  }
  let _0x279067 = [...new Set(_0x4ce2fc.map(m))];
  let _0x3915f4 = _0x279067.find(De);
  if (_0x3915f4) {
    return _0x3915f4;
  }
  let _0x27060e = _0x279067.find(_0x2a0a0d => J(_0x2a0a0d) && _0x505fd0(_0xe97c99(_0x2a0a0d, "scripts", "executor-wizard.mjs")) && _0x505fd0(_0xe97c99(_0x2a0a0d, "scripts", "launch-executor-wizard.mjs")));
  throw _0x27060e && !_0x505fd0(_0xe97c99(_0x27060e, "data")) ? Error("legacy_installation_data_missing: No data was created. Select the original installed executor folder.") : _0x27060e && !K(_0x27060e) ? Error("legacy_installation_data_empty: No existing executor configuration or database was found.") : Error("legacy_installation_invalid: Select the original IPTV Automation folder that contains the existing customer data.");
}
function k({
  root: _0x5bdba9
} = {}) {
  if (_0x505fd0(ge(_0x5bdba9))) {
    throw Error("executor_upgrade_locked: An upgrade is running or was interrupted. Wait for completion. If interrupted, contact support to verify the backup and recover before removing the lock. Do not start reception.");
  }
}
function _e({
  root: _0x157980
} = {}) {
  let _0x231a2d = ge(_0x157980);
  let _0x46872e = _0x979f50();
  try {
    _0x23d6a5(_0x231a2d, JSON.stringify({
      schema: 1,
      id: _0x46872e,
      pid: process.pid,
      startedAt: new Date().toISOString()
    }, null, 2) + "\n", {
      flag: "wx",
      mode: 384
    });
  } catch (_0x507bc8) {
    if (_0x507bc8.code === "EEXIST") {
      k({
        root: _0x157980
      });
    }
    throw _0x507bc8;
  }
  return {
    path: _0x231a2d,
    release() {
      if (JSON.parse(_0x303438(_0x231a2d, "utf8")).id !== _0x46872e) {
        throw Error("executor_upgrade_lock_ownership_changed");
      }
      _0x12c1f6(_0x231a2d);
    }
  };
}
function _({
  stateFile: _0x1a12b6 = R(),
  maintenance: _0x3cd495 = false
} = {}) {
  let _0x28b87a = we(_0x1a12b6);
  if (!_0x28b87a) {
    return null;
  }
  if (!(_0x3cd495 ? Ue(_0x28b87a.root) : Q(_0x28b87a.root))) {
    throw Error("installation_registration_invalid: Existing registration must be repaired; do not create empty replacement data.");
  }
  return _0x28b87a;
}
function xe({
  root: _0x374dd9,
  stateFile: _0x17f0bc = R(),
  replace: _0x3844ca = false
} = {}) {
  _0x374dd9 = m(_0x374dd9);
  if (!_0x505fd0(_0xe97c99(_0x374dd9, "scripts", "executor-wizard.mjs"))) {
    throw Error("installation_root_invalid");
  }
  let _0x311de9 = _({
    stateFile: _0x17f0bc
  });
  if (_0x311de9 && !b(_0x311de9.root, _0x374dd9) && !_0x3844ca) {
    throw Error("installation_already_registered: " + _0x311de9.root);
  }
  let _0xa8bfe1 = {
    schema: 1,
    root: _0x374dd9,
    dataDirectory: _0xe97c99(_0x374dd9, "data"),
    registeredAt: _0x311de9?.registeredAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  _0x28f577(_0x412c26(_0x17f0bc), {
    recursive: true
  });
  let _0x1b9934 = _0x17f0bc + "." + process.pid + ".tmp";
  _0x23d6a5(_0x1b9934, JSON.stringify(_0xa8bfe1, null, 2) + "\n", {
    mode: 384
  });
  _0x15da4f(_0x1b9934, _0x17f0bc);
  return _0xa8bfe1;
}
function Y({
  root: _0x5897a9,
  stateFile: _0x1e6943 = R(),
  maintenance: _0x71b8df = false
} = {}) {
  return _({
    stateFile: _0x1e6943,
    maintenance: _0x71b8df
  })?.root || m(_0x5897a9);
}
function Le({
  root: _0x4704ed,
  stateFile: _0x4b2336 = R()
} = {}) {
  let _0x3f6763 = _({
    stateFile: _0x4b2336
  });
  let _0x40f90 = m(_0x4704ed);
  if (_0x3f6763 && !b(_0x3f6763.root, _0x40f90) && !b(_0x3f6763.root, _0xe97c99(_0x40f90, "System Files")) && !b(_0x3f6763.root, _0xe97c99(_0x40f90, "系统文件"))) {
    throw Error("installation_already_registered: " + _0x3f6763.root);
  }
  _0x4704ed = ye(_0x4704ed);
  k({
    root: _0x4704ed
  });
  return xe({
    root: _0x4704ed,
    stateFile: _0x4b2336
  });
}
function $e({
  root: _0x26ae41,
  stateFile: _0x12770d = R()
} = {}) {
  let _0x495d94 = we(_0x12770d);
  if (!_0x495d94) {
    throw Error("installation_registration_missing");
  }
  try {
    _({
      stateFile: _0x12770d
    });
    throw Error("installation_registration_already_valid");
  } catch (_0x14f22a) {
    if (_0x14f22a.message === "installation_registration_already_valid" || !_0x14f22a.message.startsWith("installation_registration_invalid:")) {
      throw _0x14f22a;
    }
  }
  _0x26ae41 = ye(_0x26ae41);
  k({
    root: _0x26ae41
  });
  let _0x46eef7 = {
    schema: 1,
    root: _0x26ae41,
    dataDirectory: _0xe97c99(_0x26ae41, "data"),
    registeredAt: typeof _0x495d94.registeredAt == "string" ? _0x495d94.registeredAt : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  _0x28f577(_0x412c26(_0x12770d), {
    recursive: true
  });
  let _0x2b2421 = _0x12770d + "." + process.pid + ".tmp";
  _0x23d6a5(_0x2b2421, JSON.stringify(_0x46eef7, null, 2) + "\n", {
    mode: 384
  });
  _0x15da4f(_0x2b2421, _0x12770d);
  return _0x46eef7;
}
function Ve({
  root: _0x498954,
  stateFile: _0x16a76f = R()
} = {}) {
  if (!_0x505fd0(_0x16a76f)) {
    throw Error("installation_registration_missing");
  }
  let _0x28273d = _0x303438(_0x16a76f, "utf8");
  let _0x5176e4 = null;
  try {
    let _0x406dcd = JSON.parse(_0x28273d);
    if (_0x406dcd?.schema === 1 && typeof _0x406dcd.root == "string" && _0x406dcd.root.trim()) {
      _0x5176e4 = _0x406dcd;
    }
  } catch {}
  let _0x4bba7a = [_0x5176e4?.dataDirectory, _0x5176e4?.root && _0xe97c99(_0x5176e4.root, "data")].filter(Boolean).map(m);
  if ([...new Set(_0x4bba7a)].some(fe)) {
    throw Error("installation_data_still_available: Locate the original installation instead of starting fresh.");
  }
  _0x498954 = m(_0x498954);
  if (!J(_0x498954) || !Q(_0x498954) || !_0x505fd0(_0xe97c99(_0x498954, "scripts", "launch-executor-wizard.mjs"))) {
    throw Error("fresh_installation_package_invalid");
  }
  if (fe(_0xe97c99(_0x498954, "data"))) {
    throw Error("fresh_installation_target_not_empty");
  }
  _0x28f577(_0x412c26(_0x16a76f), {
    recursive: true
  });
  let _0x20a87a = _0xe97c99(_0x412c26(_0x16a76f), "installation-unavailable-" + new Date().toISOString().replace(/[:.]/g, "-") + "-" + _0x979f50() + ".json");
  _0x15da4f(_0x16a76f, _0x20a87a);
  return {
    reset: true,
    previousRoot: _0x5176e4?.root || null,
    registrationBackup: _0x20a87a,
    newRoot: _0x498954
  };
}
if (process.env.IPTV_RUNTIME_ENTRY === "installation-state.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && _0x149643(process.argv[1]) === _0x251ec3(import.meta.url)) {
  let e = _0x251ec3(new URL("../", import.meta.url));
  try {
    if (process.argv.includes("--reset-unavailable")) {
      console.log(JSON.stringify(Ve({
        root: e
      })));
    } else if (process.argv.includes("--repair")) {
      let r = process.argv.indexOf("--repair");
      console.log(JSON.stringify($e({
        root: process.argv[r + 1]
      })));
    } else if (process.argv.includes("--adopt")) {
      let r = process.argv.indexOf("--adopt");
      console.log(JSON.stringify(Le({
        root: process.argv[r + 1]
      })));
    } else if (process.argv.includes("--maintenance-check")) {
      console.log(JSON.stringify(_({
        maintenance: true
      })));
    } else if (process.argv.includes("--assert-maintenance-unlocked")) {
      k({
        root: Y({
          root: e,
          maintenance: true
        })
      });
      console.log("Installation is not locked by an upgrade.");
    } else if (process.argv.includes("--assert-unlocked")) {
      k({
        root: Y({
          root: e
        })
      });
      console.log("Installation is not locked by an upgrade.");
    } else if (process.argv.includes("--register")) {
      k({
        root: e
      });
      console.log(JSON.stringify(xe({
        root: e
      })));
    } else {
      let r = Y({
        root: e
      });
      k({
        root: r
      });
      if (!b(e, r)) {
        throw Error("Existing executor: " + r + "\nUse the safe upgrade entry in this new package. Your existing data must remain in its original folder.");
      }
      console.log("Installation directory verified.");
    }
  } catch (_0xbd3bea) {
    console.error(_0xbd3bea.message);
    process.exitCode = 1;
  }
}
import { execFileSync as _0x2051bf } from "node:child_process";
import { resolve as _0x4fe26f } from "node:path";
import { fileURLToPath as _0x44c8fe } from "node:url";
var Je = _0x378f6a => _0x378f6a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var Be = "(?:executor-wizard|connect-portal-worker|test-bridge|chrome-bridge|admin|panel-bridge|whatsapp|pair)\\.mjs";
function Z() {
  if (process.platform !== "win32") {
    throw Error("executor_process_control_requires_windows");
  }
  let _0x54bce1 = _0x2051bf("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "Get-CimInstance Win32_Process | Where-Object { $_.Name -match \"^(node|chrome|chromium|msedge|crashpad_handler)(\\.exe)?$\" } | Select-Object ProcessId,ParentProcessId,Name,CommandLine,@{Name=\"Created\";Expression={if ($_.CreationDate) { $_.CreationDate.ToUniversalTime().Ticks.ToString() } else { \"\" }}} | ConvertTo-Json -Compress"], {
    encoding: "utf8",
    windowsHide: true
  });
  let _0x1f39c2 = _0x54bce1.trim() ? JSON.parse(_0x54bce1) : [];
  if (Array.isArray(_0x1f39c2)) {
    return _0x1f39c2;
  } else {
    return [_0x1f39c2];
  }
}
function X({
  target: _0x28f878,
  processes: _0x2098f7,
  self: _0x4838de = process.pid
}) {
  let _0x6a5d6a = _0x4fe26f(_0x28f878).replaceAll("\\", "/").replace(/\/$/, "");
  let _0xecfe6e = new RegExp("^(?:\"[^\"\\r\\n]*node(?:\\.exe)?\"|[^\\s\"]*node(?:\\.exe)?)\\s+\"?" + Je(_0x6a5d6a) + "/(?:scripts|src)/" + Be + "(?:\"|\\s|$)", "i");
  let _0x1263be = _0x2098f7.filter(_0x1d7382 => _0x1d7382.ProcessId !== _0x4838de && /^node(?:\.exe)?$/i.test(_0x1d7382.Name || "") && _0xecfe6e.test(String(_0x1d7382.CommandLine || "").replaceAll("\\", "/")));
  let _0xc94983 = new Map(_0x1263be.map(_0x2b647c => [_0x2b647c.ProcessId, _0x2b647c]));
  let _0x4c0bdc = true;
  while (_0x4c0bdc) {
    _0x4c0bdc = false;
    for (let _0x4aebf3 of _0x2098f7) {
      if (_0x4aebf3.ProcessId !== _0x4838de && !_0xc94983.has(_0x4aebf3.ProcessId) && _0xc94983.has(_0x4aebf3.ParentProcessId) && /^(?:node|chrome|chromium|msedge|crashpad_handler)(?:\.exe)?$/i.test(_0x4aebf3.Name || "")) {
        _0xc94983.set(_0x4aebf3.ProcessId, _0x4aebf3);
        _0x4c0bdc = true;
      }
    }
  }
  return [..._0xc94983.values()];
}
function ee({
  target: _0x41973f,
  processes: _0x5f164a = Z(),
  terminate: _0x40200e
} = {}) {
  let _0x4133f9 = X({
    target: _0x41973f,
    processes: _0x5f164a
  });
  let _0xbb2947 = _0x40200e || (_0x4f0161 => {
    if (!/^\d+$/.test(String(_0x4f0161.Created))) {
      throw Error("executor_process_identity_missing");
    }
    let _0x38565e = "$p = Get-CimInstance Win32_Process -Filter \"ProcessId = " + Number(_0x4f0161.ProcessId) + "\"; if ($p -and $p.CreationDate.ToUniversalTime().Ticks.ToString() -eq \"" + _0x4f0161.Created + "\") { Stop-Process -Id " + Number(_0x4f0161.ProcessId) + " -Force -ErrorAction Stop }";
    _0x2051bf("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", _0x38565e], {
      encoding: "utf8",
      windowsHide: true
    });
  });
  for (let _0x3c41a9 of _0x4133f9) {
    _0xbb2947(_0x3c41a9);
  }
  return {
    stopped: _0x4133f9.length,
    pids: _0x4133f9.map(_0x5318f1 => _0x5318f1.ProcessId),
    target: _0x41973f
  };
}
if (process.env.IPTV_RUNTIME_ENTRY === "stop-executor.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && _0x4fe26f(process.argv[1]) === _0x44c8fe(import.meta.url)) {
  try {
    let e = _({
      maintenance: true
    });
    if (!e) {
      throw Error("No executor installation is registered.");
    }
    console.log(JSON.stringify(ee({
      target: e.root
    }), null, 2));
  } catch (_0x1d92a2) {
    console.error(_0x1d92a2.message);
    process.exitCode = 1;
  }
}
import { existsSync as _0x40ee15, readFileSync as _0x429368, writeFileSync as _0x36d8e1, mkdirSync as _0x86c6b6, copyFileSync as _0x4b31f2, readdirSync as _0x3fc880, lstatSync as _0x46b586, rmSync as _0x521ac9, renameSync as _0x1cde8a, openSync as _0x3d27b0, readSync as _0x2c075b, closeSync as _0x468975 } from "node:fs";
import { join as _0x25e45a, resolve as _0xcb5899, dirname as _0x1a0751, relative as _0x21c5f5, isAbsolute as _0x2f0e1e } from "node:path";
import { fileURLToPath as _0x56d02c } from "node:url";
import { createHash as _0x3e5c66, randomUUID as _0x19f844 } from "node:crypto";
import { DatabaseSync as _0x1c6de5, backup as _0x1aea81 } from "node:sqlite";
var se = _0xbe0225 => _0x3e5c66("sha256").update(_0xbe0225).digest("hex");
var er = new Set(["stop-executor.mjs", "installation-state.mjs", "upgrade-executor.mjs", "online-update-executor.mjs", "login-and-pair.mjs", "install-windows-executor.ps1", "initialize-executor.mjs", "launch-executor-wizard.mjs", "executor-wizard.mjs", "connect-portal-worker.mjs", "one-click-executor.ps1"]);
var rr = new Set(["package.json", "package-lock.json", "sbom.cdx.json", "README-FIRST.txt", "IPTV Automation.exe", "Start IPTV Automation.cmd", "Update IPTV Automation.cmd", "Stop IPTV Automation.cmd", "Customer Business Profile Template.json", "User Guide.txt", "启动IPTV自动化.cmd", "更新IPTV自动化.cmd", "停止IPTV自动化.cmd", "客户业务资料模板.json", "使用说明.txt", "安装执行端.cmd", "连接执行端.cmd", "修复或更新执行端.cmd", "安全升级执行端.cmd", "在线安全更新执行端.cmd", "停止执行端.cmd", "执行端卸载说明.txt"]);
function tr(_0x23ce80) {
  let _0x16d318 = _0x23ce80.split("/");
  if (_0x16d318.length === 1) {
    return rr.has(_0x23ce80);
  } else if (_0x16d318[0] === "scripts") {
    return _0x16d318.length === 2 && er.has(_0x16d318[1]);
  } else if (_0x16d318[0] === "runtime") {
    return /^runtime\/rapidocr\/(?:models\/)?[^/]+\.(?:txt|onnx|exe)$/i.test(_0x23ce80);
  } else {
    return ["src", "runtime-app", "admin-public", "executor-public", "knowledge", "assets", "downloads"].includes(_0x16d318[0]) && /\.(?:mjs|js|html|css|json|png|jpg|zip)$/.test(_0x23ce80);
  }
}
var or = new Set(["启动IPTV自动化.cmd", "更新IPTV自动化.cmd", "停止IPTV自动化.cmd", "客户业务资料模板.json", "使用说明.txt", "一键启动执行端.cmd", "安装执行端.cmd", "连接执行端.cmd", "修复或更新执行端.cmd", "安全升级执行端.cmd", "在线安全更新执行端.cmd", "停止执行端.cmd", "执行端卸载说明.txt", "README-FIRST.txt"]);
var sr = _0x1bbd49 => /^src\/[a-z0-9-]+\.mjs$/i.test(_0x1bbd49) || or.has(_0x1bbd49);
function x(_0x28e3eb, _0x1c534f) {
  if (typeof _0x1c534f != "string" || _0x1c534f.includes("\\") || _0x1c534f.includes(":") || _0x1c534f.includes("\0") || _0x2f0e1e(_0x1c534f) || _0x1c534f.split("/").some(_0x584de0 => !_0x584de0 || _0x584de0 === "." || _0x584de0 === "..")) {
    throw Error("upgrade_invalid_path");
  }
  let _0x534dd8 = _0xcb5899(_0x28e3eb, _0x1c534f);
  if (_0x21c5f5(_0x28e3eb, _0x534dd8).startsWith("..")) {
    throw Error("upgrade_path_escape");
  }
  let _0x22361b = _0x28e3eb;
  for (let _0x589c40 of _0x1c534f.split("/")) {
    _0x22361b = _0x25e45a(_0x22361b, _0x589c40);
    if (_0x40ee15(_0x22361b) && _0x46b586(_0x22361b).isSymbolicLink()) {
      throw Error("upgrade_symlink_forbidden");
    }
  }
  return _0x534dd8;
}
function ne(_0x33b27c) {
  if (_0x40ee15(_0x33b27c)) {
    return _0x3fc880(_0x33b27c, {
      withFileTypes: true
    }).flatMap(_0x44e904 => {
      let _0x176815 = _0x25e45a(_0x33b27c, _0x44e904.name);
      if (_0x44e904.isSymbolicLink()) {
        throw Error("upgrade_symlink_forbidden");
      }
      if (_0x44e904.isDirectory()) {
        return ne(_0x176815);
      } else {
        return [_0x176815];
      }
    });
  } else {
    return [];
  }
}
function nr(_0x2a6375) {
  _0x2a6375 = m(_0x2a6375);
  let _0x42b276 = JSON.parse(_0x429368(_0x25e45a(_0x2a6375, "executor-manifest.json"), "utf8"));
  if (_0x42b276.name !== "IPTV Windows Executor" || _0x42b276.containsCustomerData !== false || !Array.isArray(_0x42b276.files) || !_0x42b276.files.length) {
    throw Error("upgrade_manifest_invalid");
  }
  let _0x353466 = new Set();
  for (let _0x1f4800 of _0x42b276.files) {
    let _0x966127 = x(_0x2a6375, _0x1f4800.path);
    if (!tr(_0x1f4800.path) || _0x353466.has(_0x1f4800.path.toLowerCase())) {
      throw Error("upgrade_file_not_allowed");
    }
    _0x353466.add(_0x1f4800.path.toLowerCase());
    let _0x564efe = _0x429368(_0x966127);
    if (_0x564efe.length !== _0x1f4800.bytes || se(_0x564efe) !== _0x1f4800.sha256) {
      throw Error("upgrade_hash_mismatch: " + _0x1f4800.path);
    }
  }
  let _0x2c3c8c = new Set();
  for (let _0xcb598e of _0x42b276.retiredFiles || []) {
    x(_0x2a6375, _0xcb598e);
    if (!sr(_0xcb598e) || _0x353466.has(_0xcb598e.toLowerCase()) || _0x2c3c8c.has(_0xcb598e.toLowerCase())) {
      throw Error("upgrade_retired_file_not_allowed");
    }
    _0x2c3c8c.add(_0xcb598e.toLowerCase());
  }
  for (let _0x2b41b7 of ["package.json", "scripts/executor-wizard.mjs", "scripts/installation-state.mjs", "scripts/upgrade-executor.mjs"]) {
    if (!_0x353466.has(_0x2b41b7)) {
      throw Error("upgrade_manifest_incomplete");
    }
  }
  return _0x42b276;
}
function ir({
  target: _0x453d4c,
  processes: _0x5f2457 = Z()
}) {
  if (X({
    target: _0x453d4c,
    processes: _0x5f2457
  }).length) {
    throw Error("upgrade_executor_running: Run the Stop Executor entry first, then run Safe Upgrade again. Closing the browser page alone does not stop background services.");
  }
  if (_0x5f2457.some(_0x4ea632 => _0x4ea632.ProcessId !== process.pid && /^node(?:\.exe)?$/i.test(_0x4ea632.Name || "") && /\s"?(?:\.\/|\.\\)?(?:src|scripts)[\\/](?:executor-wizard|connect-portal-worker|test-bridge|chrome-bridge|admin|panel-bridge|whatsapp|pair)\.mjs(?:"|\s|$)/i.test(_0x4ea632.CommandLine || ""))) {
    throw Error("upgrade_relative_process_path: A Node executor process uses a relative entry path; its installation cannot be proven. Stop that process manually before upgrade.");
  }
}
async function ie({
  source: _0x2bf728,
  target: _0x5508a3,
  stateFile: _0x3a580d,
  dryRun: _0x2b0b7c = false,
  assertStopped: _0x3fbb28 = ir,
  beforeApply: _0x161bc9,
  afterApply: _0x434b74
} = {}) {
  _0x2bf728 = m(_0x2bf728);
  let _0x2dcfad = _({
    stateFile: _0x3a580d,
    maintenance: true
  });
  if (!_0x2dcfad) {
    throw Error("upgrade_no_registered_installation: Start your existing executor first.");
  }
  _0x5508a3 = m(_0x5508a3 || _0x2dcfad.root);
  if (!b(_0x5508a3, _0x2dcfad.root)) {
    throw Error("upgrade_target_not_registered");
  }
  if (b(_0x2bf728, _0x5508a3)) {
    throw Error("upgrade_source_is_target: Extract the new package into a separate folder.");
  }
  let _0x594859 = nr(_0x2bf728);
  let _0x19a1fc = JSON.parse(_0x429368(_0x25e45a(_0x2bf728, "package.json"), "utf8"));
  let _0x578ca4 = JSON.parse(_0x429368(_0x25e45a(_0x5508a3, "package.json"), "utf8"));
  for (let [_0xc93ac4, _0x183596] of Object.entries(_0x19a1fc.dependencies || {})) {
    if (_0x578ca4.dependencies?.[_0xc93ac4] !== _0x183596) {
      throw Error("upgrade_dependency_change_requires_maintenance: " + _0xc93ac4);
    }
  }
  let _0x578c8b = _0x594859.files.filter(_0xd3012b => /^(?:knowledge|assets)\//.test(_0xd3012b.path) && _0x40ee15(x(_0x5508a3, _0xd3012b.path))).map(_0x2c8c8b => _0x2c8c8b.path);
  // 原版保留 package.json，导致升级后版本号不变；这里改成随包更新（依赖变化前面已校验）。
  let _0x59164c = _0x594859.files.filter(_0x330b53 => !_0x578c8b.includes(_0x330b53.path));
  let _0x1ff0d5 = (_0x594859.retiredFiles || []).filter(_0x48a9f5 => _0x40ee15(x(_0x5508a3, _0x48a9f5)));
  for (let _0xe34afc of _0x59164c) {
    x(_0x5508a3, _0xe34afc.path);
  }
  let _0x579849 = {
    version: _0x594859.version,
    source: _0x2bf728,
    target: _0x5508a3,
    dataDirectory: _0x25e45a(_0x5508a3, "data"),
    changedFiles: _0x59164c.length,
    retiredPlaintextFiles: _0x1ff0d5.length,
    preservedFiles: _0x578c8b,
    dryRun: _0x2b0b7c
  };
  if (_0x2b0b7c) {
    return _0x579849;
  }
  let _0x757691 = _e({
    root: _0x5508a3
  });
  try {
    await _0x3fbb28({
      target: _0x5508a3
    });
    let _0x1f7d35 = _0x25e45a(_0x1a0751(_0x5508a3), "IPTVExecutor-backups", new Date().toISOString().replace(/[:.]/g, "-") + "-" + _0x19f844().slice(0, 8));
    _0x86c6b6(_0x1f7d35, {
      recursive: true
    });
    let _0x9f569 = (_0x2e0c3c, _0x6b5737) => {
      _0x86c6b6(_0x1a0751(_0x6b5737), {
        recursive: true
      });
      _0x4b31f2(_0x2e0c3c, _0x6b5737);
    };
    for (let _0x193170 of ["data", "knowledge", "assets"]) {
      for (let _0xdb049d of ne(_0x25e45a(_0x5508a3, _0x193170))) {
        _0x9f569(_0xdb049d, _0x25e45a(_0x1f7d35, "state", _0x21c5f5(_0x5508a3, _0xdb049d)));
      }
    }
    for (let _0x3c8616 of ne(_0x25e45a(_0x5508a3, "data"))) {
      let _0x31d363 = _0x3d27b0(_0x3c8616, "r");
      let _0x3db20e = Buffer.alloc(16);
      try {
        _0x2c075b(_0x31d363, _0x3db20e, 0, 16, 0);
      } finally {
        _0x468975(_0x31d363);
      }
      if (_0x3db20e.toString() !== "SQLite format 3\0") {
        continue;
      }
      let _0x59cb4c = new _0x1c6de5(_0x3c8616, {
        readOnly: true
      });
      try {
        let _0x259641 = _0x25e45a(_0x1f7d35, "state", _0x21c5f5(_0x5508a3, _0x3c8616));
        _0x521ac9(_0x259641, {
          force: true
        });
        await _0x1aea81(_0x59cb4c, _0x259641);
        let _0xdf678e = new _0x1c6de5(_0x259641, {
          readOnly: true
        });
        try {
          if (_0xdf678e.prepare("PRAGMA integrity_check").get().integrity_check !== "ok") {
            throw Error("upgrade_sqlite_backup_invalid");
          }
        } finally {
          _0xdf678e.close();
        }
        _0x521ac9(_0x259641 + "-wal", {
          force: true
        });
        _0x521ac9(_0x259641 + "-shm", {
          force: true
        });
      } finally {
        _0x59cb4c.close();
      }
    }
    let _0x5e5fe9 = [..._0x59164c.map(_0x481e2f => _0x481e2f.path), ..._0x1ff0d5, "executor-manifest.json"];
    let _0x37c3c7 = new Set();
    for (let _0xc8b7fb of _0x5e5fe9) {
      let _0x29503a = x(_0x5508a3, _0xc8b7fb);
      if (_0x40ee15(_0x29503a)) {
        _0x37c3c7.add(_0xc8b7fb);
        _0x9f569(_0x29503a, _0x25e45a(_0x1f7d35, "code", _0xc8b7fb));
      }
    }
    _0x36d8e1(_0x25e45a(_0x1f7d35, "upgrade-plan.json"), JSON.stringify({
      ..._0x579849,
      backupRoot: _0x1f7d35,
      originals: [..._0x37c3c7]
    }, null, 2));
    await _0x3fbb28({
      target: _0x5508a3
    });
    let _0x2b388d = [];
    try {
      for (let _0x1e7fd5 of _0x59164c) {
        if (_0x161bc9) {
          await _0x161bc9(_0x1e7fd5.path);
        }
        let _0x4ddb8a = _0x429368(x(_0x2bf728, _0x1e7fd5.path));
        if (se(_0x4ddb8a) !== _0x1e7fd5.sha256) {
          throw Error("upgrade_source_changed");
        }
        let _0x282eb6 = x(_0x5508a3, _0x1e7fd5.path);
        let _0x5becc1 = _0x282eb6 + ".upgrade-" + process.pid;
        _0x86c6b6(_0x1a0751(_0x282eb6), {
          recursive: true
        });
        _0x36d8e1(_0x5becc1, _0x4ddb8a);
        try {
          _0x1cde8a(_0x5becc1, _0x282eb6);
        } finally {
          _0x521ac9(_0x5becc1, {
            force: true
          });
        }
        _0x2b388d.push(_0x1e7fd5.path);
      }
      for (let _0x119f55 of _0x1ff0d5) {
        _0x521ac9(x(_0x5508a3, _0x119f55), {
          force: true
        });
        _0x2b388d.push(_0x119f55);
      }
      if (_0x434b74) {
        await _0x434b74({
          changes: _0x59164c.map(_0x512147 => _0x512147.path),
          retired: [..._0x1ff0d5]
        });
      }
      let _0x1e80ee = {
        ..._0x594859,
        upgrade: {
          sourceVersion: _0x594859.version,
          upgradedAt: new Date().toISOString(),
          preservedFiles: _0x578c8b,
          backupRoot: _0x1f7d35
        },
        files: _0x594859.files.map(_0x5b52fa => {
          let _0x5a82a2 = _0x429368(x(_0x5508a3, _0x5b52fa.path));
          return {
            ..._0x5b52fa,
            bytes: _0x5a82a2.length,
            sha256: se(_0x5a82a2)
          };
        })
      };
      _0x36d8e1(_0x25e45a(_0x5508a3, "executor-manifest.json"), JSON.stringify(_0x1e80ee, null, 2) + "\n");
      _0x36d8e1(_0x25e45a(_0x1f7d35, "COMPLETE.txt"), "Code upgraded. Original data location preserved.\n");
      return {
        ..._0x579849,
        backupRoot: _0x1f7d35,
        completed: true
      };
    } catch (_0x51ac03) {
      for (let _0x5cedbe of [...new Set([..._0x2b388d, "executor-manifest.json"])].reverse()) {
        let _0x2d32fb = x(_0x5508a3, _0x5cedbe);
        if (_0x37c3c7.has(_0x5cedbe)) {
          _0x9f569(_0x25e45a(_0x1f7d35, "code", _0x5cedbe), _0x2d32fb);
        } else {
          _0x521ac9(_0x2d32fb, {
            force: true
          });
        }
      }
      _0x36d8e1(_0x25e45a(_0x1f7d35, "ROLLED-BACK.txt"), "Code restored after failed upgrade. Original data was not modified.\n");
      throw _0x51ac03;
    }
  } finally {
    _0x757691.release();
  }
}
if (process.env.IPTV_RUNTIME_ENTRY === "upgrade-executor.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && _0xcb5899(process.argv[1]) === _0x56d02c(import.meta.url)) {
  try {
    console.log(JSON.stringify(await ie({
      source: _0x56d02c(new URL("../", import.meta.url)),
      dryRun: process.argv.includes("--dry-run")
    }), null, 2));
  } catch (_0x3bd9c0) {
    console.error(_0x3bd9c0.message);
    process.exitCode = 1;
  }
}
var Pe = "ywu3309-afk/iptv-executor-releases";
var ke = "https://raw.githubusercontent.com/" + Pe + "/main/release-manifest.json";
var Te = "https://raw.githubusercontent.com/" + Pe + "/main/release-manifest.sig";
var ae = "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEA3gQiNSlNuJMQ0g1xdZ2Z0UICBCe+O9hMic2kj8KRYOU=\n-----END PUBLIC KEY-----\n";
var gr = new Set(["raw.githubusercontent.com", "github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com"]);
var wr = _0x38279b => _0x430f4d("sha256").update(_0x38279b).digest("hex");
var B = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
function de(_0x373031) {
  let _0x3d12bb;
  try {
    _0x3d12bb = new URL(_0x373031);
  } catch {
    throw Error("release_url_invalid");
  }
  if (_0x3d12bb.protocol !== "https:" || _0x3d12bb.username || _0x3d12bb.password || _0x3d12bb.port || !gr.has(_0x3d12bb.hostname) || _0x3d12bb.hash) {
    throw Error("release_url_forbidden");
  }
  return _0x3d12bb;
}
function yr(_0x349c7b, _0x3a5b98) {
  let _0x15e429 = B.exec(_0x349c7b);
  let _0x246d46 = B.exec(_0x3a5b98);
  if (!_0x15e429 || !_0x246d46) {
    throw Error("release_version_invalid");
  }
  for (let _0x45fa0c = 1; _0x45fa0c <= 3; _0x45fa0c++) {
    let _0x9b2089 = Number(_0x15e429[_0x45fa0c]) - Number(_0x246d46[_0x45fa0c]);
    if (_0x9b2089) {
      return Math.sign(_0x9b2089);
    }
  }
  return 0;
}
async function ce(_0x35e282, {
  transport: _0x589806 = fetch,
  maxBytes: _0x2a8d40 = 104857600,
  maxRedirects: _0x1f4c90 = 4
} = {}) {
  let _0x2c300d = de(_0x35e282);
  for (let _0x5bb13c = 0; _0x5bb13c <= _0x1f4c90; _0x5bb13c++) {
    let _0x5d6b00 = await _0x589806(_0x2c300d.href, {
      method: "GET",
      redirect: "manual",
      headers: {
        Accept: "application/octet-stream"
      },
      signal: AbortSignal.timeout(120000)
    });
    if ([301, 302, 303, 307, 308].includes(_0x5d6b00.status)) {
      if (_0x5bb13c === _0x1f4c90) {
        throw Error("release_redirect_limit");
      }
      let _0x396a41 = _0x5d6b00.headers.get("location");
      if (!_0x396a41) {
        throw Error("release_redirect_invalid");
      }
      _0x2c300d = de(new URL(_0x396a41, _0x2c300d).href);
      continue;
    }
    if (_0x5d6b00.status !== 200 || !_0x5d6b00.body) {
      throw Error("release_download_failed");
    }
    let _0x38a791 = Number(_0x5d6b00.headers.get("content-length"));
    if (Number.isFinite(_0x38a791) && _0x38a791 > _0x2a8d40) {
      throw Error("release_download_too_large");
    }
    let _0x274993 = [];
    let _0x47f70a = 0;
    for await (let _0x6eb889 of _0x5d6b00.body) {
      _0x47f70a += _0x6eb889.length;
      if (_0x47f70a > _0x2a8d40) {
        throw Error("release_download_too_large");
      }
      _0x274993.push(Buffer.from(_0x6eb889));
    }
    return {
      bytes: Buffer.concat(_0x274993),
      finalUrl: _0x2c300d.href
    };
  }
  throw Error("release_redirect_limit");
}
function _r(_0x282662, _0x19178d, {
  publicKey: _0x4a9620 = ae
} = {}) {
  if (!Buffer.isBuffer(_0x282662) || _0x282662.length < 20 || _0x282662.length > 262144) {
    throw Error("release_manifest_invalid");
  }
  if (typeof _0x19178d != "string" || !/^[A-Za-z0-9_-]{80,100}$/.test(_0x19178d.trim())) {
    throw Error("release_signature_invalid");
  }
  if (!_0x1f32b9(null, _0x282662, _0x23696e(_0x4a9620), Buffer.from(_0x19178d.trim(), "base64url"))) {
    throw Error("release_signature_untrusted");
  }
  let _0x3b150d;
  try {
    _0x3b150d = JSON.parse(_0x282662.toString("utf8"));
  } catch {
    throw Error("release_manifest_invalid");
  }
  if (_0x3b150d.schema !== 1 || _0x3b150d.product !== "IPTV Windows Executor" || _0x3b150d.channel !== "stable" || !B.test(_0x3b150d.version || "") || !Array.isArray(_0x3b150d.assets)) {
    throw Error("release_manifest_invalid");
  }
  let _0x40eb6d = _0x3b150d.assets.find(_0x376296 => _0x376296?.kind === "windows-executor");
  if (!_0x40eb6d || _0x40eb6d.name !== "IPTV-Windows-Executor-" + _0x3b150d.version + ".zip" || !Number.isSafeInteger(_0x40eb6d.bytes) || _0x40eb6d.bytes < 1024 || _0x40eb6d.bytes > 104857600 || !/[a-f0-9]{64}/.test(_0x40eb6d.sha256 || "")) {
    throw Error("release_asset_invalid");
  }
  de(_0x40eb6d.url);
  return {
    manifest: _0x3b150d,
    asset: _0x40eb6d
  };
}
function xr(_0x16c0ea) {
  for (let _0x584e62 of ["executor-manifest.json", "package.json"]) {
    try {
      let _0x1b8b4a = JSON.parse(_0xd69ab3(_0x5b1bfa(_0x16c0ea, _0x584e62), "utf8"));
      if (B.test(_0x1b8b4a.version || "")) {
        return _0x1b8b4a.version;
      }
    } catch {}
  }
  throw Error("installed_version_unknown");
}
function vr(_0x50fb7a, _0x1f9b11) {
  _0x3a0bb0(_0x1f9b11, {
    recursive: true
  });
  let _0x1448cf = _0x5b1bfa(_0x1f9b11, "extract-release.ps1");
  _0x40742c(_0x1448cf, "param([string]$Archive,[string]$Destination)\n$ErrorActionPreference='Stop'\nExpand-Archive -LiteralPath $Archive -DestinationPath $Destination -Force\n", "utf8");
  let _0x5e02c5 = _0x5b1bfa(_0x1f9b11, "package");
  _0x3a0bb0(_0x5e02c5);
  _0x165c79("powershell.exe", ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", _0x1448cf, _0x50fb7a, _0x5e02c5], {
    windowsHide: true,
    stdio: "pipe"
  });
  _0x529d0f(_0x1448cf, {
    force: true
  });
  return _0x5e02c5;
}
function Sr(_0x717ae1) {
  for (let _0x5572fd of [_0x717ae1, _0x5b1bfa(_0x717ae1, "System Files"), _0x5b1bfa(_0x717ae1, "IPTV Automation"), _0x5b1bfa(_0x717ae1, "IPTV Automation", "System Files")]) {
    if (_0x5f1b05(_0x5b1bfa(_0x5572fd, "executor-manifest.json"))) {
      return _0x5572fd;
    }
  }
  throw Error("release_package_layout_invalid");
}
async function Er({
  transport: _0x46541b = fetch,
  manifestUrl: _0x1bd9ab = ke,
  signatureUrl: _0x2493a5 = Te,
  publicKey: _0x365d98 = ae,
  target: _0x53f6ff,
  stateFile: _0x4b3217,
  dryRun: _0x13e343 = false,
  stop: _0x4e9c77 = ee,
  extract: _0x3fc36b = vr,
  upgrade: _0x338ed5 = ie
} = {}) {
  let _0x391540 = _({
    stateFile: _0x4b3217
  });
  _0x53f6ff = _0x1760dc(_0x53f6ff || _0x391540?.root || "");
  if (!_0x391540 || _0x1760dc(_0x391540.root) !== _0x53f6ff) {
    throw Error("online_update_installation_not_registered");
  }
  let _0x2755ea = xr(_0x53f6ff);
  let _0x450067 = await ce(_0x1bd9ab, {
    transport: _0x46541b,
    maxBytes: 262144
  });
  let _0x3679c3 = await ce(_0x2493a5, {
    transport: _0x46541b,
    maxBytes: 1024
  });
  let _0x37342e = _r(_0x450067.bytes, _0x3679c3.bytes.toString("ascii"), {
    publicKey: _0x365d98
  });
  if (yr(_0x37342e.manifest.version, _0x2755ea) <= 0) {
    return {
      updated: false,
      current: _0x2755ea,
      available: _0x37342e.manifest.version
    };
  }
  if (_0x13e343) {
    return {
      updated: false,
      dryRun: true,
      current: _0x2755ea,
      available: _0x37342e.manifest.version,
      asset: _0x37342e.asset.name
    };
  }
  let _0x266983 = _0x129693(_0x5b1bfa(_0x2787be(), "iptv-signed-update-"));
  try {
    let _0x2e6ab0 = await ce(_0x37342e.asset.url, {
      transport: _0x46541b,
      maxBytes: 104857600
    });
    if (_0x2e6ab0.bytes.length !== _0x37342e.asset.bytes || wr(_0x2e6ab0.bytes) !== _0x37342e.asset.sha256) {
      throw Error("release_asset_hash_mismatch");
    }
    let _0x420dec = _0x5b1bfa(_0x266983, _0x37342e.asset.name);
    _0x40742c(_0x420dec, _0x2e6ab0.bytes);
    let _0x5c3977 = Sr(_0x3fc36b(_0x420dec, _0x5b1bfa(_0x266983, "expanded")));
    _0x4e9c77({
      target: _0x53f6ff
    });
    let _0x8cedf8 = await _0x338ed5({
      source: _0x5c3977,
      target: _0x53f6ff,
      stateFile: _0x4b3217
    });
    return {
      updated: true,
      from: _0x2755ea,
      to: _0x37342e.manifest.version,
      backupRoot: _0x8cedf8.backupRoot
    };
  } finally {
    _0x529d0f(_0x266983, {
      recursive: true,
      force: true
    });
  }
}
if (process.env.IPTV_RUNTIME_ENTRY === "online-update-executor.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && _0x1760dc(process.argv[1]) === _0x219c5d(import.meta.url)) {
  try {
    let e = await Er({
      dryRun: process.argv.includes("--dry-run")
    });
    console.log(e.updated ? "Secure update completed: " + e.from + " -> " + e.to : e.dryRun ? "Secure update available: " + e.current + " -> " + e.available : "Executor is current: " + e.current);
    if (e.updated) {
      console.log("Backup: " + e.backupRoot);
    }
  } catch (_0x2adcd0) {
    console.error("Secure online update failed: " + _0x2adcd0.message);
    process.exitCode = 1;
  }
}
export { ce as boundedDownload, yr as compareVersions, Er as runOnlineUpdate, _r as verifyReleaseManifest };