/*
 * 升级（upgrade-executor）
 *
 * 校验升级包（executor-manifest 里每个文件的大小和 SHA-256）→ 停进程 → 备份数据 →
 * 替换代码 → 失败回滚。在线更新最后调用的就是这里。
 */
import { existsSync as fn, readFileSync as fn2, writeFileSync as fn3, mkdirSync as fn4, copyFileSync as fn5, readdirSync as fn6, lstatSync as fn7, rmSync as fn8, renameSync as fn9, openSync as fn10, readSync as fn11, closeSync as fn12 } from "node:fs";
import { join as fn13, resolve as fn14, dirname as fn15, relative as fn16, isAbsolute as fn17 } from "node:path";
import { fileURLToPath as fn18 } from "node:url";
import { createHash as fn19, randomUUID as fn20 } from "node:crypto";
import { DatabaseSync as value, backup as fn21 } from "node:sqlite";
import { existsSync as fn22, mkdirSync as fn23, readFileSync as fn24, writeFileSync as fn25, renameSync as fn26, realpathSync as fn27, readdirSync as fn28, statSync as fn29, unlinkSync as fn30 } from "node:fs";
import { randomUUID as fn31 } from "node:crypto";
import { resolve as fn32, join as fn33, dirname as fn34 } from "node:path";
import { homedir as fn35 } from "node:os";
import { fileURLToPath as fn36 } from "node:url";
var I = () => fn33(process.env.LOCALAPPDATA || fn33(fn35(), "AppData", "Local"), "IPTVExecutor", "installation.json");
function m(arg) {
  let value2 = fn32(arg);
  if (fn22(value2)) {
    return fn27(value2);
  } else {
    return value2;
  }
}
function _(arg2, arg3) {
  let value3 = m(arg2);
  let value4 = m(arg3);
  if (process.platform === "win32") {
    return value3.toLowerCase() === value4.toLowerCase();
  } else {
    return value3 === value4;
  }
}
var ne = arg4 => fn33(m(arg4), ".executor-upgrade.lock");
function se(arg5) {
  if (!fn22(arg5)) {
    return null;
  }
  try {
    let installation = JSON.parse(fn24(arg5, "utf8"));
    if (installation.schema !== 1 || typeof installation.root != "string" || !installation.root.trim()) {
      throw Error();
    }
    return installation;
  } catch {
    throw Error("installation_registration_invalid: Existing registration must be repaired; do not create empty replacement data.");
  }
}
function F(arg6) {
  let value5 = fn33(arg6, "data");
  if (!fn22(value5) || !fn29(value5).isDirectory()) {
    return false;
  } else {
    return fn28(value5, {
      withFileTypes: true
    }).some(arg7 => arg7.isFile() && (/\.sqlite(?:3)?$/i.test(arg7.name) || /(?:config|state)\.json$/i.test(arg7.name)) && fn29(fn33(value5, arg7.name)).size > 0);
  }
}
function te(arg8) {
  return fn22(arg8) && fn29(arg8).isDirectory() && fn28(arg8).length > 0;
}
function A(arg9) {
  let value6 = fn33(arg9, "package.json");
  if (!fn22(value6)) {
    return false;
  }
  try {
    return ["iptv-windows-executor", "iptv-trial-assistant"].includes(JSON.parse(fn24(value6, "utf8")).name);
  } catch {
    return false;
  }
}
function W(arg10) {
  return fn22(fn33(arg10, "scripts", "executor-wizard.mjs"));
}
function Se(arg11) {
  return A(arg11) && fn22(fn33(arg11, "scripts", "executor-wizard.mjs")) && fn22(fn33(arg11, "scripts", "launch-executor-wizard.mjs")) && F(arg11);
}
function ve(arg12) {
  return W(arg12) || A(arg12) && F(arg12);
}
function ie(arg13) {
  if (typeof arg13 != "string" || !arg13.trim()) {
    throw Error("legacy_installation_path_required");
  }
  let value7 = m(arg13.trim());
  let list = [value7, fn33(value7, "System Files"), fn33(value7, "系统文件")];
  if (fn22(value7) && fn29(value7).isDirectory()) {
    for (let value10 of fn28(value7, {
      withFileTypes: true
    })) {
      if (value10.isDirectory()) {
        list.push(fn33(value7, value10.name));
      }
    }
  }
  let list2 = [...new Set(list.map(m))];
  let value8 = list2.find(Se);
  if (value8) {
    return value8;
  }
  let value9 = list2.find(arg14 => A(arg14) && fn22(fn33(arg14, "scripts", "executor-wizard.mjs")) && fn22(fn33(arg14, "scripts", "launch-executor-wizard.mjs")));
  throw value9 && !fn22(fn33(value9, "data")) ? Error("legacy_installation_data_missing: No data was created. Select the original installed executor folder.") : value9 && !F(value9) ? Error("legacy_installation_data_empty: No existing executor configuration or database was found.") : Error("legacy_installation_invalid: Select the original IPTV Automation folder that contains the existing customer data.");
}
function S({
  root: arg15
} = {}) {
  if (fn22(ne(arg15))) {
    throw Error("executor_upgrade_locked: An upgrade is running or was interrupted. Wait for completion. If interrupted, contact support to verify the backup and recover before removing the lock. Do not start reception.");
  }
}
function ae({
  root: arg16
} = {}) {
  let value11 = ne(arg16);
  let value12 = fn31();
  try {
    fn25(value11, JSON.stringify({
      schema: 1,
      id: value12,
      pid: process.pid,
      startedAt: new Date().toISOString()
    }, null, 2) + "\n", {
      flag: "wx",
      mode: 384
    });
  } catch (value13) {
    if (value13.code === "EEXIST") {
      S({
        root: arg16
      });
    }
    throw value13;
  }
  return {
    path: value11,
    release() {
      if (JSON.parse(fn24(value11, "utf8")).id !== value12) {
        throw Error("executor_upgrade_lock_ownership_changed");
      }
      fn30(value11);
    }
  };
}
function y({
  stateFile: arg17 = I(),
  maintenance: arg18 = false
} = {}) {
  let installation2 = se(arg17);
  if (!installation2) {
    return null;
  }
  if (!(arg18 ? ve(installation2.root) : W(installation2.root))) {
    throw Error("installation_registration_invalid: Existing registration must be repaired; do not create empty replacement data.");
  }
  return installation2;
}
function ce({
  root: arg19,
  stateFile: arg20 = I(),
  replace: arg21 = false
} = {}) {
  arg19 = m(arg19);
  if (!fn22(fn33(arg19, "scripts", "executor-wizard.mjs"))) {
    throw Error("installation_root_invalid");
  }
  let installation3 = y({
    stateFile: arg20
  });
  if (installation3 && !_(installation3.root, arg19) && !arg21) {
    throw Error("installation_already_registered: " + installation3.root);
  }
  let options = {
    schema: 1,
    root: arg19,
    dataDirectory: fn33(arg19, "data"),
    registeredAt: installation3?.registeredAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  fn23(fn34(arg20), {
    recursive: true
  });
  let value14 = arg20 + "." + process.pid + ".tmp";
  fn25(value14, JSON.stringify(options, null, 2) + "\n", {
    mode: 384
  });
  fn26(value14, arg20);
  return options;
}
function V({
  root: arg22,
  stateFile: arg23 = I(),
  maintenance: arg24 = false
} = {}) {
  return y({
    stateFile: arg23,
    maintenance: arg24
  })?.root || m(arg22);
}
function Ie({
  root: arg25,
  stateFile: arg26 = I()
} = {}) {
  let installation4 = y({
    stateFile: arg26
  });
  let value15 = m(arg25);
  if (installation4 && !_(installation4.root, value15) && !_(installation4.root, fn33(value15, "System Files")) && !_(installation4.root, fn33(value15, "系统文件"))) {
    throw Error("installation_already_registered: " + installation4.root);
  }
  arg25 = ie(arg25);
  S({
    root: arg25
  });
  return ce({
    root: arg25,
    stateFile: arg26
  });
}
function Ee({
  root: arg27,
  stateFile: arg28 = I()
} = {}) {
  let value16 = se(arg28);
  if (!value16) {
    throw Error("installation_registration_missing");
  }
  try {
    y({
      stateFile: arg28
    });
    throw Error("installation_registration_already_valid");
  } catch (conversation) {
    if (conversation.message === "installation_registration_already_valid" || !conversation.message.startsWith("installation_registration_invalid:")) {
      throw conversation;
    }
  }
  arg27 = ie(arg27);
  S({
    root: arg27
  });
  let options2 = {
    schema: 1,
    root: arg27,
    dataDirectory: fn33(arg27, "data"),
    registeredAt: typeof value16.registeredAt == "string" ? value16.registeredAt : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  fn23(fn34(arg28), {
    recursive: true
  });
  let value17 = arg28 + "." + process.pid + ".tmp";
  fn25(value17, JSON.stringify(options2, null, 2) + "\n", {
    mode: 384
  });
  fn26(value17, arg28);
  return options2;
}
function ke({
  root: arg29,
  stateFile: arg30 = I()
} = {}) {
  if (!fn22(arg30)) {
    throw Error("installation_registration_missing");
  }
  let value18 = fn24(arg30, "utf8");
  let installation5 = null;
  try {
    let installation6 = JSON.parse(value18);
    if (installation6?.schema === 1 && typeof installation6.root == "string" && installation6.root.trim()) {
      installation5 = installation6;
    }
  } catch {}
  let value19 = [installation5?.dataDirectory, installation5?.root && fn33(installation5.root, "data")].filter(Boolean).map(m);
  if ([...new Set(value19)].some(te)) {
    throw Error("installation_data_still_available: Locate the original installation instead of starting fresh.");
  }
  arg29 = m(arg29);
  if (!A(arg29) || !W(arg29) || !fn22(fn33(arg29, "scripts", "launch-executor-wizard.mjs"))) {
    throw Error("fresh_installation_package_invalid");
  }
  if (te(fn33(arg29, "data"))) {
    throw Error("fresh_installation_target_not_empty");
  }
  fn23(fn34(arg30), {
    recursive: true
  });
  let value20 = fn33(fn34(arg30), "installation-unavailable-" + new Date().toISOString().replace(/[:.]/g, "-") + "-" + fn31() + ".json");
  fn26(arg30, value20);
  return {
    reset: true,
    previousRoot: installation5?.root || null,
    registrationBackup: value20,
    newRoot: arg29
  };
}
if (process.env.IPTV_RUNTIME_ENTRY === "installation-state.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && fn32(process.argv[1]) === fn36(import.meta.url)) {
  let t = fn36(new URL("../", import.meta.url));
  try {
    if (process.argv.includes("--reset-unavailable")) {
      console.log(JSON.stringify(ke({
        root: t
      })));
    } else if (process.argv.includes("--repair")) {
      let e = process.argv.indexOf("--repair");
      console.log(JSON.stringify(Ee({
        root: process.argv[e + 1]
      })));
    } else if (process.argv.includes("--adopt")) {
      let e = process.argv.indexOf("--adopt");
      console.log(JSON.stringify(Ie({
        root: process.argv[e + 1]
      })));
    } else if (process.argv.includes("--maintenance-check")) {
      console.log(JSON.stringify(y({
        maintenance: true
      })));
    } else if (process.argv.includes("--assert-maintenance-unlocked")) {
      S({
        root: V({
          root: t,
          maintenance: true
        })
      });
      console.log("Installation is not locked by an upgrade.");
    } else if (process.argv.includes("--assert-unlocked")) {
      S({
        root: V({
          root: t
        })
      });
      console.log("Installation is not locked by an upgrade.");
    } else if (process.argv.includes("--register")) {
      S({
        root: t
      });
      console.log(JSON.stringify(ce({
        root: t
      })));
    } else {
      let e = V({
        root: t
      });
      S({
        root: e
      });
      if (!_(t, e)) {
        throw Error("Existing executor: " + e + "\nUse the safe upgrade entry in this new package. Your existing data must remain in its original folder.");
      }
      console.log("Installation directory verified.");
    }
  } catch (conversation2) {
    console.error(conversation2.message);
    process.exitCode = 1;
  }
}
import { execFileSync as fn37 } from "node:child_process";
import { resolve as fn38 } from "node:path";
import { fileURLToPath as fn39 } from "node:url";
var je = arg31 => arg31.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var Te = "(?:executor-wizard|connect-portal-worker|test-bridge|chrome-bridge|admin|panel-bridge|whatsapp|pair)\\.mjs";
function Y() {
  if (process.platform !== "win32") {
    throw Error("executor_process_control_requires_windows");
  }
  let value21 = fn37("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "Get-CimInstance Win32_Process | Where-Object { $_.Name -match \"^(node|chrome|chromium|msedge|crashpad_handler)(\\.exe)?$\" } | Select-Object ProcessId,ParentProcessId,Name,CommandLine,@{Name=\"Created\";Expression={if ($_.CreationDate) { $_.CreationDate.ToUniversalTime().Ticks.ToString() } else { \"\" }}} | ConvertTo-Json -Compress"], {
    encoding: "utf8",
    windowsHide: true
  });
  let value22 = value21.trim() ? JSON.parse(value21) : [];
  if (Array.isArray(value22)) {
    return value22;
  } else {
    return [value22];
  }
}
function B({
  target: arg32,
  processes: arg33,
  self: arg34 = process.pid
}) {
  let value23 = fn38(arg32).replaceAll("\\", "/").replace(/\/$/, "");
  let value24 = new RegExp("^(?:\"[^\"\\r\\n]*node(?:\\.exe)?\"|[^\\s\"]*node(?:\\.exe)?)\\s+\"?" + je(value23) + "/(?:scripts|src)/" + Te + "(?:\"|\\s|$)", "i");
  let value25 = arg33.filter(arg35 => arg35.ProcessId !== arg34 && /^node(?:\.exe)?$/i.test(arg35.Name || "") && value24.test(String(arg35.CommandLine || "").replaceAll("\\", "/")));
  let map = new Map(value25.map(arg36 => [arg36.ProcessId, arg36]));
  let value26 = true;
  while (value26) {
    value26 = false;
    for (let value27 of arg33) {
      if (value27.ProcessId !== arg34 && !map.has(value27.ProcessId) && map.has(value27.ParentProcessId) && /^(?:node|chrome|chromium|msedge|crashpad_handler)(?:\.exe)?$/i.test(value27.Name || "")) {
        map.set(value27.ProcessId, value27);
        value26 = true;
      }
    }
  }
  return [...map.values()];
}
function be({
  target: arg37,
  processes: arg39 = Y(),
  terminate: arg38
} = {}) {
  let value28 = B({
    target: arg37,
    processes: arg39
  });
  let fn40 = arg38 || (arg40 => {
    if (!/^\d+$/.test(String(arg40.Created))) {
      throw Error("executor_process_identity_missing");
    }
    let value29 = "$p = Get-CimInstance Win32_Process -Filter \"ProcessId = " + Number(arg40.ProcessId) + "\"; if ($p -and $p.CreationDate.ToUniversalTime().Ticks.ToString() -eq \"" + arg40.Created + "\") { Stop-Process -Id " + Number(arg40.ProcessId) + " -Force -ErrorAction Stop }";
    fn37("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", value29], {
      encoding: "utf8",
      windowsHide: true
    });
  });
  for (let value30 of value28) {
    fn40(value30);
  }
  return {
    stopped: value28.length,
    pids: value28.map(arg41 => arg41.ProcessId),
    target: arg37
  };
}
if (process.env.IPTV_RUNTIME_ENTRY === "stop-executor.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && fn38(process.argv[1]) === fn39(import.meta.url)) {
  try {
    let t = y({
      maintenance: true
    });
    if (!t) {
      throw Error("No executor installation is registered.");
    }
    console.log(JSON.stringify(be({
      target: t.root
    }), null, 2));
  } catch (conversation3) {
    console.error(conversation3.message);
    process.exitCode = 1;
  }
}
var Q = arg42 => fn19("sha256").update(arg42).digest("hex");
var ze = new Set(["stop-executor.mjs", "installation-state.mjs", "upgrade-executor.mjs", "online-update-executor.mjs", "login-and-pair.mjs", "install-windows-executor.ps1", "initialize-executor.mjs", "launch-executor-wizard.mjs", "executor-wizard.mjs", "connect-portal-worker.mjs", "one-click-executor.ps1"]);
var Me = new Set(["package.json", "package-lock.json", "sbom.cdx.json", "README-FIRST.txt", "IPTV Automation.exe", "Start IPTV Automation.cmd", "Update IPTV Automation.cmd", "Stop IPTV Automation.cmd", "Customer Business Profile Template.json", "User Guide.txt", "启动IPTV自动化.cmd", "更新IPTV自动化.cmd", "停止IPTV自动化.cmd", "客户业务资料模板.json", "使用说明.txt", "安装执行端.cmd", "连接执行端.cmd", "修复或更新执行端.cmd", "安全升级执行端.cmd", "在线安全更新执行端.cmd", "停止执行端.cmd", "执行端卸载说明.txt"]);
function qe(arg43) {
  let value31 = arg43.split("/");
  if (value31.length === 1) {
    return Me.has(arg43);
  } else if (value31[0] === "scripts") {
    return value31.length === 2 && ze.has(value31[1]);
  } else if (value31[0] === "runtime") {
    return /^runtime\/rapidocr\/(?:models\/)?[^/]+\.(?:txt|onnx|exe)$/i.test(arg43);
  } else {
    return ["src", "runtime-app", "admin-public", "executor-public", "knowledge", "assets", "downloads"].includes(value31[0]) && /\.(?:mjs|js|html|css|json|png|jpg|zip)$/.test(arg43);
  }
}
var Fe = new Set(["启动IPTV自动化.cmd", "更新IPTV自动化.cmd", "停止IPTV自动化.cmd", "客户业务资料模板.json", "使用说明.txt", "一键启动执行端.cmd", "安装执行端.cmd", "连接执行端.cmd", "修复或更新执行端.cmd", "安全升级执行端.cmd", "在线安全更新执行端.cmd", "停止执行端.cmd", "执行端卸载说明.txt", "README-FIRST.txt"]);
var We = arg44 => /^src\/[a-z0-9-]+\.mjs$/i.test(arg44) || Fe.has(arg44);
function h(arg45, arg46) {
  if (typeof arg46 != "string" || arg46.includes("\\") || arg46.includes(":") || arg46.includes("\0") || fn17(arg46) || arg46.split("/").some(arg47 => !arg47 || arg47 === "." || arg47 === "..")) {
    throw Error("upgrade_invalid_path");
  }
  let value32 = fn14(arg45, arg46);
  if (fn16(arg45, value32).startsWith("..")) {
    throw Error("upgrade_path_escape");
  }
  let value33 = arg45;
  for (let value34 of arg46.split("/")) {
    value33 = fn13(value33, value34);
    if (fn(value33) && fn7(value33).isSymbolicLink()) {
      throw Error("upgrade_symlink_forbidden");
    }
  }
  return value32;
}
function X(arg48) {
  if (fn(arg48)) {
    return fn6(arg48, {
      withFileTypes: true
    }).flatMap(arg49 => {
      let value35 = fn13(arg48, arg49.name);
      if (arg49.isSymbolicLink()) {
        throw Error("upgrade_symlink_forbidden");
      }
      if (arg49.isDirectory()) {
        return X(value35);
      } else {
        return [value35];
      }
    });
  } else {
    return [];
  }
}
function Ye(arg50) {
  arg50 = m(arg50);
  let value36 = JSON.parse(fn2(fn13(arg50, "executor-manifest.json"), "utf8"));
  if (value36.name !== "IPTV Windows Executor" || value36.containsCustomerData !== false || !Array.isArray(value36.files) || !value36.files.length) {
    throw Error("upgrade_manifest_invalid");
  }
  let set = new Set();
  for (let value37 of value36.files) {
    let value38 = h(arg50, value37.path);
    if (!qe(value37.path) || set.has(value37.path.toLowerCase())) {
      throw Error("upgrade_file_not_allowed");
    }
    set.add(value37.path.toLowerCase());
    let value39 = fn2(value38);
    if (value39.length !== value37.bytes || Q(value39) !== value37.sha256) {
      throw Error("upgrade_hash_mismatch: " + value37.path);
    }
  }
  let set2 = new Set();
  for (let value40 of value36.retiredFiles || []) {
    h(arg50, value40);
    if (!We(value40) || set.has(value40.toLowerCase()) || set2.has(value40.toLowerCase())) {
      throw Error("upgrade_retired_file_not_allowed");
    }
    set2.add(value40.toLowerCase());
  }
  for (let value41 of ["package.json", "scripts/executor-wizard.mjs", "scripts/installation-state.mjs", "scripts/upgrade-executor.mjs"]) {
    if (!set.has(value41)) {
      throw Error("upgrade_manifest_incomplete");
    }
  }
  return value36;
}
function Be({
  target: arg51,
  processes: arg52 = Y()
}) {
  if (B({
    target: arg51,
    processes: arg52
  }).length) {
    throw Error("upgrade_executor_running: Run the Stop Executor entry first, then run Safe Upgrade again. Closing the browser page alone does not stop background services.");
  }
  if (arg52.some(arg53 => arg53.ProcessId !== process.pid && /^node(?:\.exe)?$/i.test(arg53.Name || "") && /\s"?(?:\.\/|\.\\)?(?:src|scripts)[\\/](?:executor-wizard|connect-portal-worker|test-bridge|chrome-bridge|admin|panel-bridge|whatsapp|pair)\.mjs(?:"|\s|$)/i.test(arg53.CommandLine || ""))) {
    throw Error("upgrade_relative_process_path: A Node executor process uses a relative entry path; its installation cannot be proven. Stop that process manually before upgrade.");
  }
}
async function Ge({
  source: arg54,
  target: arg55,
  stateFile: arg56,
  dryRun: arg57 = false,
  assertStopped: fn43 = Be,
  beforeApply: fn41,
  afterApply: fn42
} = {}) {
  arg54 = m(arg54);
  let installation7 = y({
    stateFile: arg56,
    maintenance: true
  });
  if (!installation7) {
    throw Error("upgrade_no_registered_installation: Start your existing executor first.");
  }
  arg55 = m(arg55 || installation7.root);
  if (!_(arg55, installation7.root)) {
    throw Error("upgrade_target_not_registered");
  }
  if (_(arg54, arg55)) {
    throw Error("upgrade_source_is_target: Extract the new package into a separate folder.");
  }
  let value42 = Ye(arg54);
  let value43 = JSON.parse(fn2(fn13(arg54, "package.json"), "utf8"));
  let value44 = JSON.parse(fn2(fn13(arg55, "package.json"), "utf8"));
  for (let [value49, value50] of Object.entries(value43.dependencies || {})) {
    if (value44.dependencies?.[value49] !== value50) {
      throw Error("upgrade_dependency_change_requires_maintenance: " + value49);
    }
  }
  let value45 = value42.files.filter(arg58 => /^(?:knowledge|assets)\//.test(arg58.path) && fn(h(arg55, arg58.path))).map(arg59 => arg59.path);
  // 原版会把 package.json 也放进保留清单，导致升级后版本号不变、启动器一直提示有更新。
  // 依赖是否变化上面已经校验过，这里改成随包一起更新。
  let value46 = value42.files.filter(arg60 => !value45.includes(arg60.path));
  let value47 = (value42.retiredFiles || []).filter(arg61 => fn(h(arg55, arg61)));
  for (let value51 of value46) {
    h(arg55, value51.path);
  }
  let options3 = {
    version: value42.version,
    source: arg54,
    target: arg55,
    dataDirectory: fn13(arg55, "data"),
    changedFiles: value46.length,
    retiredPlaintextFiles: value47.length,
    preservedFiles: value45,
    dryRun: arg57
  };
  if (arg57) {
    return options3;
  }
  let value48 = ae({
    root: arg55
  });
  try {
    await fn43({
      target: arg55
    });
    let value52 = fn13(fn15(arg55), "IPTVExecutor-backups", new Date().toISOString().replace(/[:.]/g, "-") + "-" + fn20().slice(0, 8));
    fn4(value52, {
      recursive: true
    });
    let fn44 = (arg62, arg63) => {
      fn4(fn15(arg63), {
        recursive: true
      });
      fn5(arg62, arg63);
    };
    for (let value53 of ["data", "knowledge", "assets"]) {
      for (let value54 of X(fn13(arg55, value53))) {
        fn44(value54, fn13(value52, "state", fn16(arg55, value54)));
      }
    }
    for (let value55 of X(fn13(arg55, "data"))) {
      let value56 = fn10(value55, "r");
      let value57 = Buffer.alloc(16);
      try {
        fn11(value56, value57, 0, 16, 0);
      } finally {
        fn12(value56);
      }
      if (value57.toString() !== "SQLite format 3\0") {
        continue;
      }
      let value58 = new value(value55, {
        readOnly: true
      });
      try {
        let value59 = fn13(value52, "state", fn16(arg55, value55));
        fn8(value59, {
          force: true
        });
        await fn21(value58, value59);
        let database = new value(value59, {
          readOnly: true
        });
        try {
          if (database.prepare("PRAGMA integrity_check").get().integrity_check !== "ok") {
            throw Error("upgrade_sqlite_backup_invalid");
          }
        } finally {
          database.close();
        }
        fn8(value59 + "-wal", {
          force: true
        });
        fn8(value59 + "-shm", {
          force: true
        });
      } finally {
        value58.close();
      }
    }
    let list3 = [...value46.map(arg64 => arg64.path), ...value47, "executor-manifest.json"];
    let set3 = new Set();
    for (let value60 of list3) {
      let value61 = h(arg55, value60);
      if (fn(value61)) {
        set3.add(value60);
        fn44(value61, fn13(value52, "code", value60));
      }
    }
    fn3(fn13(value52, "upgrade-plan.json"), JSON.stringify({
      ...options3,
      backupRoot: value52,
      originals: [...set3]
    }, null, 2));
    await fn43({
      target: arg55
    });
    let list4 = [];
    try {
      for (let value62 of value46) {
        if (fn41) {
          await fn41(value62.path);
        }
        let value63 = fn2(h(arg54, value62.path));
        if (Q(value63) !== value62.sha256) {
          throw Error("upgrade_source_changed");
        }
        let value64 = h(arg55, value62.path);
        let value65 = value64 + ".upgrade-" + process.pid;
        fn4(fn15(value64), {
          recursive: true
        });
        fn3(value65, value63);
        try {
          fn9(value65, value64);
        } finally {
          fn8(value65, {
            force: true
          });
        }
        list4.push(value62.path);
      }
      for (let value66 of value47) {
        fn8(h(arg55, value66), {
          force: true
        });
        list4.push(value66);
      }
      if (fn42) {
        await fn42({
          changes: value46.map(arg65 => arg65.path),
          retired: [...value47]
        });
      }
      let options4 = {
        ...value42,
        upgrade: {
          sourceVersion: value42.version,
          upgradedAt: new Date().toISOString(),
          preservedFiles: value45,
          backupRoot: value52
        },
        files: value42.files.map(arg66 => {
          let value67 = fn2(h(arg55, arg66.path));
          return {
            ...arg66,
            bytes: value67.length,
            sha256: Q(value67)
          };
        })
      };
      fn3(fn13(arg55, "executor-manifest.json"), JSON.stringify(options4, null, 2) + "\n");
      fn3(fn13(value52, "COMPLETE.txt"), "Code upgraded. Original data location preserved.\n");
      return {
        ...options3,
        backupRoot: value52,
        completed: true
      };
    } catch (value68) {
      for (let value69 of [...new Set([...list4, "executor-manifest.json"])].reverse()) {
        let value70 = h(arg55, value69);
        if (set3.has(value69)) {
          fn44(fn13(value52, "code", value69), value70);
        } else {
          fn8(value70, {
            force: true
          });
        }
      }
      fn3(fn13(value52, "ROLLED-BACK.txt"), "Code restored after failed upgrade. Original data was not modified.\n");
      throw value68;
    }
  } finally {
    value48.release();
  }
}
if (process.env.IPTV_RUNTIME_ENTRY === "upgrade-executor.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && fn14(process.argv[1]) === fn18(import.meta.url)) {
  try {
    console.log(JSON.stringify(await Ge({
      source: fn18(new URL("../", import.meta.url)),
      dryRun: process.argv.includes("--dry-run")
    }), null, 2));
  } catch (conversation4) {
    console.error(conversation4.message);
    process.exitCode = 1;
  }
}
export { Be as assertExecutorStopped, Ge as upgradeExecutor, Ye as verifyUpgradeSource };