/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
/*
 * MEGA（megaott.net）线路页助手
 *
 * 负责在「新增订阅 / 编辑订阅」页面里：
 *   prepare   读套餐、读三个分类（直播/电影/电视剧）当前勾了什么
 *   configure 套模板、按计划勾选、填账号和备注
 *   submit    点「Create Subscription」/「Save Update」
 *   find/inspect 按备注+账号找记录、读回详情
 *   verify/expiry 校验勾选结果、抓到期时间
 *
 * 页面是组件化的，没有稳定 id，所以大量依赖「文字相等」和角色选择器。
 */
(() => {
  const SCOPES = ["live", "movies", "series"];
  const sectionTitleRules = {
    live: /^Bouquets\s+Live$/i,
    movies: /^Bouquets\s+Movies$/i,
    series: /^Bouquets\s+Series$/i
  };
  const TEMPLATE_NAME = "test-huberyliu";
  const isVisible = node => !!node?.getClientRects().length;
  const textOf = node => node?.innerText?.trim() || "";
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const waitFor = async (probe, timeoutMs = 18000) => {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const value = probe();
      if (value) {
        return value;
      }
      await sleep(200);
    }
    throw Error("页面状态等待超时，停止重复操作");
  };
  // 按可见文字找唯一按钮；找到 0 个或多个都报错，宁可停也不点错。
  const findButtonByText = label => {
    const buttons = [...document.querySelectorAll("button,[role=\"button\"]")].filter(button => isVisible(button) && textOf(button) === label);
    if (buttons.length !== 1) {
      throw Error("按钮不唯一：" + label + "（匹配 " + buttons.length + " 个）");
    }
    return buttons[0];
  };
  function describeControl(control) {
    const labelEl = control.id ? [...document.querySelectorAll("label[for]")].find(labelElement => labelElement.htmlFor === control.id) : null;
    return [control.getAttribute("aria-label"), labelEl && textOf(labelEl), control.closest("label") && textOf(control.closest("label"))].filter(Boolean).join(" ");
  }
  function findSelectControls() {
    const selects = [...document.querySelectorAll("select[multiple]")].filter(select => select.options.length > 0);
    if (selects.length === 3) {
      return selects;
    }
    const found = {};
    for (const select of selects) {
      const hint = [select.name, select.id, describeControl(select), select.closest("section,fieldset,[class*=\"card\" i]")?.innerText?.slice(0, 200)].filter(Boolean).join(" ");
      if (/Bouquets?\s*Live|\blive\b/i.test(hint)) {
        found.live = select;
      }
      if (/Bouquets?\s*Movies|\bmovies?\b|\bfilms?\b/i.test(hint)) {
        found.movies = select;
      }
      if (/Bouquets?\s*Series|\bseries\b/i.test(hint)) {
        found.series = select;
      }
    }
    if (SCOPES.every(scope => found[scope])) {
      return SCOPES.map(scope => found[scope]);
    } else {
      return null;
    }
  }
  function findSectionTitle(scope) {
    return [...document.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,label,div,span,p")].find(element => isVisible(element) && sectionTitleRules[scope].test(textOf(element)));
  }
  function findSectionContainer(scope) {
    const title = findSectionTitle(scope);
    if (!title) {
      return null;
    }
    for (let container = title.parentElement; container && container !== document.body; container = container.parentElement) {
      const checkboxes = [...container.querySelectorAll("input[type=\"checkbox\"],[role=\"checkbox\"]")];
      const titles = [...container.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,label,div,span,p")].filter(element => isVisible(element) && Object.values(sectionTitleRules).some(rule => rule.test(textOf(element))));
      if (checkboxes.length && titles.length === 1) {
        return container;
      }
    }
    return null;
  }
  function readCheckboxOption(input) {
    const id = String(input.value || input.dataset.value || input.dataset.id || input.getAttribute("data-key") || input.id || "").trim();
    const container = input.closest("label,[role=\"option\"],li,tr,[class*=\"item\" i]");
    const label = String(input.getAttribute("aria-label") || textOf(container) || describeControl(input) || "").replace(/\s+/g, " ").trim();
    if (!id || !label) {
      return null;
    } else {
      return {
        id: id,
        label: label,
        selected: input.checked === true || input.getAttribute("aria-checked") === "true" || input.classList.contains("selected"),
        element: input
      };
    }
  }
  // 读三类频道控件。两种形态都支持：
  //   a) 三个多选 <select>（老版）
  //   b) 一堆 checkbox（新版组件）
  function readChannelControls() {
    const selects = findSelectControls();
    if (selects) {
      return Object.fromEntries(SCOPES.map((scope, index) => [scope, {
        kind: "select",
        element: selects[index],
        items: [...selects[index].options].map(option => ({
          id: option.value,
          label: option.text.trim(),
          selected: option.selected,
          element: option
        }))
      }]));
    }
    const controls = {};
    for (const scope of SCOPES) {
      const container = findSectionContainer(scope);
      const items = container ? [...container.querySelectorAll("input[type=\"checkbox\"],[role=\"checkbox\"]")].map(readCheckboxOption).filter(Boolean) : [];
      if (!items.length) {
        throw Error("频道控件结构变化：" + scope);
      }
      controls[scope] = {
        kind: "checkbox",
        element: container,
        items: items
      };
    }
    return controls;
  }
  const snapshotCatalog = () => Object.fromEntries(Object.entries(readChannelControls()).map(([scope, control]) => [scope, control.items.map(({
    id: id,
    label: label,
    selected: selected
  }) => ({
    id: id,
    label: label,
    selected: selected
  }))]));
  const allScopesHaveSelection = () => {
    try {
      return Object.values(readChannelControls()).every(control => control.items.length > 0 && control.items.some(item => item.selected));
    } catch {
      return false;
    }
  };
  // 按候选选择器依次找，必须唯一命中；多个命中说明页面结构变了，直接报错。
  function findUniqueInput(selectors, ambiguousMessage) {
    for (const selector of selectors) {
      const matches = [...document.querySelectorAll(selector)].filter(element => isVisible(element) && !element.disabled && element.type !== "hidden");
      if (matches.length === 1) {
        return matches[0];
      }
      if (matches.length > 1) {
        throw Error(ambiguousMessage);
      }
    }
    return null;
  }
  const getNoteInput = () => findUniqueInput(["textarea[name=\"note\" i]", "textarea[id=\"note\" i]", "textarea[name*=\"note\" i]", "textarea[id*=\"note\" i]", "textarea[placeholder*=\"notes\" i]"], "备注控件不唯一");
  const getUsernameInput = () => findUniqueInput(["input[name=\"username\" i]", "input[id=\"username\" i]", "input[name*=\"username\" i]", "input[id*=\"username\" i]", "input[autocomplete=\"username\"]", "input[type=\"text\"][placeholder=\"\"]"], "用户名控件不唯一");
  // React 受控组件不认直接赋值，要走原生 setter 再补发 input/change 事件。
  const setNativeValue = (input, value) => {
    if (!input) {
      throw Error("输入框缺失");
    }
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(input, value);
    input.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    input.dispatchEvent(new Event("change", {
      bubbles: true
    }));
  };
  const settleDelay = () => sleep(2500);
  function isTemplateApplied() {
    if ([...document.querySelectorAll("select,input,[role=\"combobox\"]")].some(element => (element instanceof HTMLSelectElement ? [...element.selectedOptions].map(option => option.text.trim()) : [element.value, element.getAttribute("aria-valuetext"), textOf(element)]).some(text => String(text || "").trim() === TEMPLATE_NAME))) {
      return true;
    } else {
      return [...document.querySelectorAll("div,span,p")].some(element => isVisible(element) && textOf(element) === TEMPLATE_NAME);
    }
  }
  // 面板改版后没有可用模板时，直接把三个频道列表全选
  function selectAllChannels() {
    for (const select of document.querySelectorAll("select[multiple]")) {
      let changed = false;
      for (const option of select.options) {
        if (!option.selected) {
          option.selected = true;
          changed = true;
        }
      }
      if (changed) {
        select.dispatchEvent(new Event("input", {
          bubbles: true
        }));
        select.dispatchEvent(new Event("change", {
          bubbles: true
        }));
      }
    }
  }
  // 选模板：面板改版后模板名可能不存在（现在只有 Default / 国家模板），
  // 所以这里做成「尽力而为」——找不到就跳过，由 configure 直接勾选频道。
  async function applyTemplate() {
    if (isTemplateApplied()) {
      try {
        await waitFor(allScopesHaveSelection, 6000);
      } catch {}
      return;
    }
    try {
      findButtonByText("Select Template").click();
    } catch {
      return;
    }
    let item = null;
    try {
      item = await waitFor(() => {
        const nodes = [...document.querySelectorAll("button,[role=\"button\"],[role=\"menuitem\"],[role=\"option\"]")].filter(isVisible);
        return nodes.find(node => textOf(node).split("\n").filter(Boolean)[0] === TEMPLATE_NAME) || null;
      }, 4000);
    } catch {}
    if (!item) {
      // 模板不存在或改版了：直接全选三个频道列表，等价于原来的「全频道模板」
      document.body.click();
      selectAllChannels();
      try {
        await waitFor(allScopesHaveSelection, 6000);
      } catch {}
      return;
    }
    item.click();
    try {
      await waitFor(() => isTemplateApplied() && allScopesHaveSelection(), 8000);
    } catch {}
  }
  // 开号前的硬门槛：必须确认「24 小时 0 积分」套餐、免费名额 ≥ 1、积分余额 = 0。
  // 任何一项不满足就停止，避免扣到客户积分。
  function readDemoAllowance() {
    const option = [...document.querySelectorAll("select")].find(select => [...select.options].some(option2 => option2.text.trim() === "24 Hours - 0 Credits"))?.selectedOptions[0];
    const comboboxShowsTrial = [...document.querySelectorAll("button,[role=\"combobox\"],div,span,input")].some(element => isVisible(element) && String(element.value || textOf(element)).trim() === "24 Hours - 0 Credits");
    const bodyText = document.body.innerText;
    const remainingMatch = bodyText.match(/Remaining Free Demo\s+(\d+)/i);
    const creditMatch = bodyText.match(/Package credit\s+([\d.]+)/i);
    if (!(option ? option.text.trim() === "24 Hours - 0 Credits" && String(option.value) === "1" : comboboxShowsTrial) || !remainingMatch || Number(remainingMatch[1]) < 1 || !creditMatch || Number(creditMatch[1]) !== 0) {
      throw Error("无法确认免费名额和零积分，停止开户");
    }
    return {
      credit: 0,
      remaining: Number(remainingMatch[1])
    };
  }
  // 按计划勾选：select 形态直接改 selected 再派发事件；checkbox 形态模拟点击。
  function applySelection(plan) {
    const controls = readChannelControls();
    for (const scope of plan.changed) {
      if (!SCOPES.includes(scope)) {
        throw Error("invalid_scope");
      }
      const control = controls[scope];
      const wanted = new Set(plan.selected[scope]);
      if ([...wanted].some(id => !control.items.some(item => item.id === id))) {
        throw Error("分类已变化");
      }
      if (control.kind === "select") {
        for (const item of control.items) {
          item.element.selected = wanted.has(item.id);
        }
        control.element.dispatchEvent(new Event("input", {
          bubbles: true
        }));
        control.element.dispatchEvent(new Event("change", {
          bubbles: true
        }));
      } else {
        for (const item of control.items) {
          if (item.selected !== wanted.has(item.id)) {
            item.element.click();
          }
        }
      }
    }
  }
  // 勾完再读一遍，和计划比对；不一致就报错，绝不带着错误配置提交。
  function verifySelection(plan) {
    const snapshot = snapshotCatalog();
    for (const scope of plan.changed) {
      if (JSON.stringify(snapshot[scope].filter(item => item.selected).map(item => item.id).sort()) !== JSON.stringify([...plan.selected[scope]].sort())) {
        throw Error("分类选择核验失败");
      }
    }
  }
  let configuredBinding = null;
  let submitted = false;
  // 指令入口：submit 单独处理（防重复提交），其余动作走同一个异步分支。
  // submit 会先把「已提交」标志置位再点按钮，避免网络慢的时候被点两次。
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id === chrome.runtime.id && message.type === "iptv-command" && location.origin === "https://megaott.net") {
      if (message.action === "submit") {
        try {
          if (submitted) {
            throw Error("本页面已经提交，禁止重复");
          }
          const args = message.args;
          if (args.mode === "create") {
            readDemoAllowance();
            if (!configuredBinding || configuredBinding.username !== args.username || configuredBinding.marker !== args.marker || getUsernameInput()?.value !== args.username || getNoteInput()?.value !== args.marker) {
              throw Error("开户绑定不符或输入尚未同步");
            }
          } else if (args.mode === "edit") {
            if (!location.pathname.endsWith("/" + args.id + "/edit") || getUsernameInput()?.value !== args.username || getNoteInput()?.value !== args.marker) {
              throw Error("编辑绑定不符");
            }
          } else {
            throw Error("invalid_mode");
          }
          const submitButton = findButtonByText(args.mode === "create" ? "Create Subscription" : "Save Update");
          submitted = true;
          sendResponse({
            ok: true,
            result: {
              dispatched: true
            }
          });
          setTimeout(() => submitButton.click(), 50);
        } catch (error) {
          sendResponse({
            ok: false,
            error: error.message
          });
        }
        return;
      }
      (async () => {
        const args = message.args || {};
        if (message.action === "ping") {
          return {
            url: location.href
          };
        }
        if (message.action === "prepare") {
          if (!location.pathname.endsWith("/add")) {
            throw Error("不在开户页");
          }
          await applyTemplate();
          return {
            catalog: snapshotCatalog(),
            summary: readDemoAllowance()
          };
        }
        if (message.action === "configure") {
          configuredBinding = null;
          applySelection(args.plan);
          await settleDelay();
          verifySelection(args.plan);
          setNativeValue(getUsernameInput(), args.username);
          setNativeValue(getNoteInput(), args.marker);
          await settleDelay();
          if (getUsernameInput()?.value !== args.username || getNoteInput()?.value !== args.marker) {
            throw Error("开户资料同步后绑定不一致");
          }
          verifySelection(args.plan);
          const summary = readDemoAllowance();
          configuredBinding = {
            username: args.username,
            marker: args.marker
          };
          return summary;
        }
        if (message.action === "find") {
          const rowId = (await waitFor(() => {
            const rows = [...document.querySelectorAll("tr")].filter(row => row.innerText.includes(args.marker) && row.innerText.includes(args.username));
            if (rows.length > 1) {
              throw Error("账号搜索结果不唯一");
            }
            if (rows.length === 1) {
              return rows[0];
            } else {
              return null;
            }
          })).querySelector("input[type=\"checkbox\"]")?.id?.match(/^bulk-cb-row-(\d+)$/)?.[1];
          if (!rowId) {
            throw Error("账号 ID 不可核验");
          }
          return {
            id: rowId
          };
        }
        if (message.action === "inspect") {
          if (!location.pathname.endsWith("/" + args.id + "/edit")) {
            throw Error("编辑地址不匹配");
          }
          await waitFor(() => getNoteInput() && getUsernameInput());
          return {
            note: getNoteInput().value,
            username: getUsernameInput().value,
            catalog: snapshotCatalog()
          };
        }
        if (message.action === "apply") {
          if (getUsernameInput()?.value !== args.username || getNoteInput()?.value !== args.marker) {
            throw Error("账号归属核验失败");
          }
          applySelection(args.plan);
          verifySelection(args.plan);
          return {
            prepared: true
          };
        }
        if (message.action === "verify") {
          verifySelection(args.plan);
          return {
            verified: true
          };
        }
        if (message.action === "expiry") {
          return {
            expiryLabel: document.body.innerText.match(/Expiry Date:\s*([^\n]+)/)?.[1]?.trim() || null
          };
        }
        throw Error("unsupported_command");
      })().then(result => sendResponse({
        ok: true,
        result: result
      }), error => sendResponse({
        ok: false,
        error: error.message
      }));
      return true;
    }
  });
})();