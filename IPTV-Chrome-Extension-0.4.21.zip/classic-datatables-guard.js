/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
(() => {
  if (globalThis.__iptvClassicDataTablesGuard) {
    return;
  }
  globalThis.__iptvClassicDataTablesGuard = true;
  const _v1 = globalThis.alert.bind(globalThis);
  globalThis.alert = function (_p2) {
    const _v3 = String(_p2 ?? "");
    if (/^DataTables warning:\s*table id=datatable-users\s*-\s*Invalid JSON response\./i.test(_v3)) {
      window.postMessage({
        source: "iptv-classic-datatables",
        type: "invalid-json"
      }, location.origin);
      return;
    }
    return _v1(_p2);
  };
})();