/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
// STRONG 面板换过域名：老站 8k.cms-only.ru，新站 8k.online-cms.ru。
// 两个都要认，跳转时用「当前标签页所在的域名」，不要写死。
const STRONG_ORIGINS = ["https://8k.cms-only.ru", "https://8k.online-cms.ru"];
const sleep = ms => new Promise(resolveLater => setTimeout(resolveLater, ms));
/*
 * STRONG 标签页操作手
 *
 * 和 LION/classic 同一套路：确认页面 → 发指令 → 回读核对。
 * 特别注意：STRONG 的开号必须先在台账里确认 credits === 0，
 * 否则直接报 strong_nonzero_charge 并停止。
 */
export async function runStrong(tabId, job) {
  async function getTab() {
    const tab = await chrome.tabs.get(tabId);
    const url = new URL(tab.url);
    if (!STRONG_ORIGINS.includes(url.origin)) {
      throw Error("strong_wrong_origin");
    }
    if (["/login", "/login.php"].includes(url.pathname)) {
      throw Error("strong_login_required");
    }
    return tab;
  }
  async function sendCommand(action, args2 = {}) {
    await getTab();
    const reply = await chrome.tabs.sendMessage(tabId, {
      type: "iptv-strong-command",
      action: action,
      args: args2
    });
    if (!reply?.ok) {
      throw Error(reply?.error || "strong_extension_not_ready");
    }
    return reply.result;
  }
  async function tryCommand(action, args2) {
    try {
      return await sendCommand(action, args2);
    } catch (error) {
      if (/^strong_/.test(error.message)) {
        throw error;
      }
      return null;
    }
  }
  // 跳转并等待：URL 一致 + ping 版本一致 + documentToken 变了（说明是新页面）。
  async function navigate(path) {
    await getTab();
    let previousToken;
    try {
      const pingReply = await sendCommand("ping");
      if (typeof pingReply.documentToken == "string") {
        previousToken = pingReply.documentToken;
      }
    } catch (error) {
      if (/^strong_/.test(error.message) && error.message !== "strong_extension_not_ready") {
        throw error;
      }
    }
    const targetUrl = new URL(new URL((await getTab()).url).origin + path);
    await chrome.tabs.update(tabId, {
      url: targetUrl.href
    });
    const deadline = Date.now() + 25000;
    while (Date.now() < deadline) {
      const tab = await getTab();
      const url = new URL(tab.url);
      if (url.pathname === targetUrl.pathname && url.search === targetUrl.search) {
        try {
          const reply = await sendCommand("ping");
          if (reply.version !== "0.4.5") {
            throw Error("strong_extension_version_mismatch");
          }
          if (typeof reply.documentToken != "string" || !/^[A-Za-z0-9-]{8,100}$/.test(reply.documentToken)) {
            throw Error("strong_document_token_missing");
          }
          if (reply.documentToken !== previousToken) {
            return;
          }
        } catch (error) {
          if (/^strong_/.test(error.message) && error.message !== "strong_extension_not_ready") {
            throw error;
          }
        }
      }
      await sleep(250);
    }
    throw Error("strong_navigation_timeout");
  }
  async function ensurePage(path) {
    const tab = await getTab();
    const target = new URL(new URL(tab.url).origin + path);
    const url = new URL(tab.url);
    if (url.pathname === target.pathname && url.search === target.search) {
      try {
        const reply = await sendCommand("ping");
        if (reply.version === "0.4.5" && typeof reply.documentToken == "string" && /^[A-Za-z0-9-]{8,100}$/.test(reply.documentToken)) {
          return;
        }
      } catch (error) {
        if (/^strong_/.test(error.message) && error.message !== "strong_extension_not_ready") {
          throw error;
        }
      }
    }
    await navigate(path);
  }
  const args = job.args;
  if (job.action === "prepare") {
    await ensurePage("/addnew?t=lines");
    return sendCommand("prepare");
  }
  if (job.action === "recover") {
    if (!args.originalRequestId || !args.account?.id || !args.account?.username || args.account.marker !== "IPTVBOT-STRONG-" + args.originalRequestId.toUpperCase()) {
      throw Error("strong_recovery_binding_invalid");
    }
    await navigate("/users?t=lines");
    const found = await sendCommand("find", args.account);
    if (found.id !== args.account.id || found.username !== args.account.username || found.marker !== args.account.marker) {
      throw Error("strong_recovery_identity_mismatch");
    }
    await navigate("/logs?t=subs");
    const ledger = await sendCommand("ledger", found);
    if (ledger.credits !== 0 || ledger.type !== "Demo" || ledger.username !== found.username || !/^\d+$/.test(String(ledger.ledgerId || ""))) {
      throw Error("strong_recovery_charge_unverified");
    }
    await navigate("/users?t=lines");
    const inspected = await sendCommand("inspect", found);
    if (!inspected.catalog.length || inspected.catalog.some(item => !item.selected)) {
      throw Error("strong_recovery_selection_mismatch");
    }
    if (inspected.account.id !== found.id || inspected.account.username !== found.username || inspected.account.password !== found.password || inspected.account.marker !== found.marker) {
      throw Error("strong_recovery_identity_mismatch");
    }
    return {
      ...inspected,
      charge: ledger,
      recovered: true
    };
  }
  // 开号：prepare → configure → submitCreate → 等跳到 /users → find → 台账核对 → 回读频道比对。
  // 提交那一步用 tryCommand 包着：即使页面报错也继续往下核，避免「其实开了但没记账」。
  if (job.action === "create") {
    await ensurePage("/addnew?t=lines");
    const prepared = await sendCommand("prepare");
    const configured = await sendCommand("configure", args);
    await tryCommand("submitCreate", args);
    const deadline = Date.now() + 30000;
    let arrived = false;
    while (Date.now() < deadline) {
      const tab = await getTab();
      if (tab.status === "complete" && new URL(tab.url).pathname === "/users") {
        arrived = true;
        break;
      }
      await sleep(250);
    }
    if (!arrived) {
      throw Error("strong_creation_requires_review");
    }
    const found = await sendCommand("find", configured);
    await navigate("/logs?t=subs");
    const ledger = await sendCommand("ledger", found);
    if (ledger.credits !== 0) {
      throw Error("strong_nonzero_charge");
    }
    await navigate("/users?t=lines");
    const inspected = await sendCommand("inspect", found);
    if (JSON.stringify(inspected.catalog.filter(item => item.selected).map(item => item.id).sort()) !== JSON.stringify([...configured.selected].sort())) {
      throw Error("strong_created_selection_mismatch");
    }
    return {
      ...inspected,
      charge: ledger,
      summary: prepared.summary
    };
  }
  await navigate("/users?t=lines");
  const current = await sendCommand("inspect", args.account);
  if (job.action === "inspect") {
    return current;
  }
  if (job.action !== "edit") {
    throw Error("strong_unsupported_action");
  }
  const selected = new Set(current.catalog.filter(item => item.selected).map(item => item.id));
  const requested = new Set(args.channelIds || []);
  if ([...requested].some(id => !current.catalog.some(item => item.id === id))) {
    throw Error("strong_unknown_channel");
  }
  for (const channelId of requested) {
    if (args.operation === "remove") {
      selected.delete(channelId);
    } else if (args.operation === "add") {
      selected.add(channelId);
    } else {
      throw Error("strong_invalid_operation");
    }
  }
  const sorted = args.selected ? [...args.selected].sort() : [...selected].sort();
  if (sorted.some(id => !current.catalog.some(item => item.id === id))) {
    throw Error("strong_unknown_channel");
  }
  if (sorted.length === 0) {
    throw Error("strong_empty_content");
  }
  if (JSON.stringify(sorted) === JSON.stringify(current.catalog.filter(item => item.selected).map(item => item.id).sort())) {
    return {
      ...current,
      updated: false
    };
  }
  await sendCommand("apply", {
    account: args.account,
    selected: sorted
  });
  await tryCommand("save", {
    account: args.account
  });
  await navigate("/users?t=lines");
  const verified = await sendCommand("inspect", args.account);
  if (JSON.stringify(verified.catalog.filter(item => item.selected).map(item => item.id).sort()) !== JSON.stringify(sorted)) {
    throw Error("strong_saved_selection_mismatch");
  }
  if (["username", "password", "expiryLabel", "playbackServer", "m3uUrl", "linkSource"].some(key => verified.account[key] !== current.account[key])) {
    throw Error("strong_account_fields_changed");
  }
  return {
    ...verified,
    updated: true,
    refreshRequired: true
  };
}