/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
(() => {
  if (location.origin !== "https://lion2.bycdn.network" || globalThis.__iptvLionListener) {
    return;
  }
  globalThis.__iptvLionListener = true;
  const _v1 = "0.4.5";
  const _v2 = "1 Day (12hours trial) (0 cds)";
  const _v3 = crypto.randomUUID();
  let _v4 = "start";
  const _v5 = _p26 => new Promise(_p27 => setTimeout(_p27, _p26));
  const _v6 = _p28 => !!_p28?.getClientRects().length;
  const _v7 = _p29 => (_p29?.textContent || "").replace(/\s+/g, " ").trim();
  async function _fn8(_p30, _p31 = 20000) {
    const _v32 = Date.now() + _p31;
    while (Date.now() < _v32) {
      const _v33 = _p30();
      if (_v33) {
        return _v33;
      }
      await _v5(120);
    }
    throw Error("lion_wait_" + _v4);
  }
  const _v9 = _p34 => [...document.querySelectorAll("[role=dialog]")].find(_p35 => _v6(_p35) && _v7(_p35.querySelector("h2")) === _p34);
  function _fn10(_p36, _p37) {
    const _v38 = [..._p36.querySelectorAll("button")].filter(_p39 => _v6(_p39) && _v7(_p39) === _p37);
    if (_v38.length !== 1) {
      throw Error("lion_button_ambiguous");
    }
    return _v38[0];
  }
  function _fn11(_p40) {
    const _v41 = [..._p40.querySelectorAll("button")].filter(_p43 => _v6(_p43) && _v7(_p43) === "Save");
    const _v42 = _v41[0]?.form;
    if (!_v41.length || !_v42 || _v41.some(_p44 => _p44.form !== _v42 || _p44.type !== "submit" || _p44.disabled || _p44.name || _p44.value || _p44.hasAttribute("formaction") || _p44.hasAttribute("formmethod") || _p44.hasAttribute("formtarget") || _p44.hasAttribute("formenctype") || _p44.hasAttribute("formnovalidate"))) {
      throw Error("lion_save_button_ambiguous");
    }
    return _v41[0];
  }
  function _fn12() {
    const _v45 = [...document.querySelectorAll("button")].filter(_p46 => /Credits:\s*[0-9]+(?:\.[0-9]+)?\s*$/i.test(_v7(_p46)));
    if (_v45.length !== 1) {
      throw Error("lion_balance_unknown");
    }
    return Number(_v7(_v45[0]).match(/Credits:\s*([0-9]+(?:\.[0-9]+)?)\s*$/i)[1]);
  }
  function _fn13() {
    const _v47 = [...document.querySelectorAll("button")].find(_p49 => /Credits:/i.test(_v7(_p49)))?.innerText?.split(/\n/).map(_p50 => _p50.trim()).filter(Boolean) || [];
    const _v48 = _v47.findIndex(_p51 => /^Credits:/i.test(_p51));
    if (_v48 < 1 || !/^[\w.-]{2,80}$/.test(_v47[_v48 - 1])) {
      throw Error("lion_owner_unknown");
    }
    return _v47[_v48 - 1];
  }
  function _fn14(_p52 = document) {
    // 新版 LION 的频道列表里混进了“全选”之类的复选框（没有数字编号或没有文字），
    // 这些不是频道，直接忽略；只保留“数字编号 + 有名字”的真实频道。
    const _v53 = [..._p52.querySelectorAll("input[type=checkbox]")].map(_p54 => {
      const _v55 = _v7(_p54.closest("label")) || _v7(_p54.parentElement);
      return {
        id: _p54.value,
        label: _v55,
        selected: _p54.checked,
        group: /^SRS\s*[-|]/i.test(_v55) ? "series" : /^VOD\s*[-|]/i.test(_v55) ? "movies" : "live"
      };
    }).filter(_p54 => /^\d+$/.test(_p54.id) && _p54.label);
    if (!_v53.length || new Set(_v53.map(_p57 => _p57.id)).size !== _v53.length) {
      throw Error("lion_catalog_invalid");
    }
    return _v53;
  }
  function _fn15(_p58, _p59) {
    if (!_p58) {
      throw Error("lion_input_missing");
    }
    Object.getOwnPropertyDescriptor(_p58.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, "value").set.call(_p58, _p59);
    _p58.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    _p58.dispatchEvent(new Event("change", {
      bubbles: true
    }));
  }
  async function _fn16() {
    if (location.pathname !== "/devices/m3u/create") {
      throw Error("lion_create_page_required");
    }
    const _v60 = await _fn8(() => document.querySelector("#package button[role=combobox]"));
    if (_v7(_v60) !== _v2) {
      _v60.dispatchEvent(new PointerEvent("pointerdown", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      const _v62 = await _fn8(() => [...document.querySelectorAll("[role=option]")].find(_p63 => _v6(_p63) && _v7(_p63) === _v2));
      _v62.dispatchEvent(new PointerEvent("pointerdown", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      _v62.dispatchEvent(new PointerEvent("pointerup", {
        bubbles: true,
        button: 0,
        pointerType: "mouse",
        isPrimary: true
      }));
      await _fn8(() => _v7(_v60) === _v2);
    }
    // 切换套餐后频道列表是异步加载的，这里最多等 25 秒，避免读到空列表就报错。
    let _v61 = null;
    const _vCatalogDeadline = Date.now() + 25000;
    while (!_v61) {
      try {
        _v61 = _fn14();
      } catch (_catalogError) {
        if (Date.now() > _vCatalogDeadline) {
          throw _catalogError;
        }
        await _v5(700);
      }
    }
    return {
      summary: _fn17(),
      catalog: _v61
    };
  }
  function _fn17() {
    if (_v7(document.querySelector("#package button[role=combobox]")) !== _v2) {
      throw Error("lion_nonfree_package");
    }
    const _v64 = [...document.querySelectorAll("div")].find(_p66 => _p66.childElementCount === 0 && _v7(_p66).toLowerCase() === "total credit");
    if (!_v64) {
      throw Error("lion_total_missing");
    }
    const _v65 = _v7(_v64.nextElementSibling);
    if (_v65 !== "" && !/^0(?:\.0+)?$/.test(_v65)) {
      throw Error("lion_nonzero_cost");
    }
    return {
      origin: location.origin,
      trialLabel: _v2,
      credits: 0,
      totalCredit: _v65,
      balance: _fn12(),
      reseller: _fn13(),
      hours: 12
    };
  }
  async function _fn18(_p67) {
    if (!/^IPTVBOT-LION-[A-F0-9]{20}$/.test(_p67.marker) || !/^ib[a-f0-9]{20}$/.test(_p67.username)) {
      throw Error("lion_identity_invalid");
    }
    if ((await _fn16()).summary.reseller !== _p67.reseller) {
      throw Error("lion_owner_changed");
    }
    _fn15(document.querySelector("#username input"), _p67.username);
    _fn15(document.querySelector("#note textarea"), _p67.marker);
    for (const _v68 of [...document.querySelectorAll("button")].filter(_p69 => _v6(_p69) && _v7(_p69) === "Select All")) {
      _v68.click();
    }
    await _fn8(() => _fn14().every(_p70 => _p70.selected));
    if (document.querySelector("#username input")?.value !== _p67.username || document.querySelector("#note textarea")?.value !== _p67.marker) {
      throw Error("lion_identity_not_set");
    }
    return {
      summary: _fn17(),
      selected: _fn14().map(_p71 => _p71.id)
    };
  }
  function _fn19(_p72) {
    const _v73 = _fn17();
    if (_v73.reseller !== _p72.reseller || _v73.balance !== _p72.balance || document.querySelector("#username input")?.value !== _p72.username || document.querySelector("#note textarea")?.value !== _p72.marker || _fn14().some(_p74 => !_p74.selected)) {
      throw Error("lion_pre_submit_changed");
    }
    _fn11(document.querySelector("form")).click();
    return {
      submitted: true
    };
  }
  async function _fn20(_p75) {
    if (location.pathname !== "/devices/m3u") {
      throw Error("lion_list_page_required");
    }
    _v4 = "search_input";
    const _v76 = await _fn8(() => document.querySelector("input[placeholder=\"Search, Seller...\"]"));
    if (_v76.value !== _p75.username) {
      _fn15(_v76, _p75.username);
      await _v5(1200);
    }
    _v4 = "account_row";
    let _v77 = null;
    let _v78 = 0;
    return _fn8(() => {
      const _v79 = [...document.querySelectorAll("tbody tr")].filter(_p81 => _v7(_p81.children[1]) === _p75.username);
      if (_v79.length > 1) {
        throw Error("lion_duplicate_account");
      }
      const _v80 = _v79.length === 1 ? _v79[0] : null;
      if (_v80 !== _v77) {
        _v77 = _v80;
        _v78 = Date.now();
      }
      if (_v80?.isConnected && Date.now() - _v78 >= 400) {
        return _v80;
      } else {
        return null;
      }
    });
  }
  async function _fn21(_p82) {
    const _v83 = await _fn20(_p82);
    const _v84 = _v83.children;
    if (_fn13() !== _p82.reseller || _v7(_v84[4]) !== _p82.reseller) {
      throw Error("lion_account_owner_mismatch");
    }
    const _v85 = _v84[11].querySelector("button");
    let _v86 = _v7(_v84[11]);
    if (_v86 !== _p82.marker && _v85) {
      _v4 = "note_open";
      _v85.click();
      const _v93 = await _fn8(() => [...document.querySelectorAll("[role=dialog][data-slot=popover-content] p")].find(_p94 => _v6(_p94)) || [...document.querySelectorAll("[role=dialog] p")].find(_p95 => _v6(_p95)));
      _v86 = _v7(_v93);
      _v85.click();
      _v4 = "note_close";
      await _fn8(() => !_v6(_v93));
    }
    if (_v86 !== _p82.marker) {
      throw Error("lion_marker_mismatch");
    }
    const _v87 = _v7(_v84[1]);
    const _v88 = _v7(_v84[2]);
    const _v89 = _v7(_v84[3]);
    _v4 = "link_open";
    _fn10(_v83, "Link").click();
    await _fn8(() => _v9("Link"));
    _v4 = "link_value";
    const _v90 = await _fn8(() => {
      const _v96 = _v9("Link")?.querySelector("input");
      if (_v96?.value) {
        return _v96;
      } else {
        return null;
      }
    });
    const _v91 = new URL(_v90.value);
    if (!["http:", "https:"].includes(_v91.protocol) || _v91.pathname !== "/get.php" || _v91.searchParams.get("username") !== _v87 || _v91.searchParams.get("password") !== _v88) {
      throw Error("lion_playback_identity_mismatch");
    }
    const _v92 = {
      server: "LION",
      id: _v87,
      username: _v87,
      password: _v88,
      playbackServer: _v91.origin,
      marker: _v86,
      reseller: _p82.reseller,
      expiryLabel: _v89,
      package: "12 Hours",
      hours: 12
    };
    _fn10(_v9("Link"), "Close").click();
    _v4 = "link_close";
    await _fn8(() => !_v9("Link"));
    return _v92;
  }
  async function _fn22(_p97) {
    const _v98 = await _fn20(_p97);
    _v4 = "packages_open";
    _fn10(_v98, "Packages").click();
    await _fn8(() => _v9("Bouquets"));
    _v4 = "packages_catalog";
    await _fn8(() => _v9("Bouquets")?.querySelectorAll("input[type=checkbox]").length > 0);
    return _v9("Bouquets");
  }
  async function _fn23(_p99) {
    const _v100 = await _fn21(_p99);
    const _v101 = await _fn22(_p99);
    const _v102 = _fn14(_v101);
    const _v103 = _fn12();
    _fn10(_v101, "Close").click();
    _v4 = "packages_close";
    await _fn8(() => !_v9("Bouquets"));
    return {
      account: _v100,
      catalog: _v102,
      balance: _v103
    };
  }
  async function _fn24(_p104) {
    await _fn21(_p104.account);
    const _v105 = await _fn22(_p104.account);
    const _v106 = _fn14(_v105);
    if (!Array.isArray(_p104.selected) || !_p104.selected.length || _p104.selected.some(_p108 => !_v106.some(_p109 => _p109.id === _p108))) {
      throw Error("lion_selection_invalid");
    }
    const _v107 = new Set(_p104.selected);
    for (const _v110 of _v105.querySelectorAll("input[type=checkbox]")) {
      if (_v110.checked !== _v107.has(_v110.value)) {
        _v110.click();
      }
    }
    await _fn8(() => _fn14(_v105).every(_p111 => _p111.selected === _v107.has(_p111.id)));
    return {
      configured: true
    };
  }
  async function _fn25(_p112) {
    const _v113 = _v9("Bouquets");
    if (!_v113 || _fn12() !== _p112.balance || _fn13() !== _p112.account.reseller) {
      throw Error("lion_edit_pre_submit_changed");
    }
    const _v114 = _fn11(_v113);
    _v4 = "packages_save_close";
    _v114.click();
    await _fn8(() => !_v9("Bouquets"));
    return {
      submitted: true
    };
  }
  chrome.runtime.onMessage.addListener((_p115, _p116, _p117) => {
    if (_p116.id !== chrome.runtime.id || _p115.type !== "iptv-lion-command") {
      return;
    }
    if (_p115.action === "ping") {
      _p117({
        ok: true,
        result: {
          server: "LION",
          version: _v1,
          revision: "lion-readback-4",
          documentToken: _v3,
          url: location.href,
          stage: _v4,
          loggedIn: location.pathname !== "/login"
        }
      });
      return;
    }
    const _v118 = {
      prepare: _fn16,
      configure: _fn18,
      submitCreate: _fn19,
      find: _fn21,
      inspect: _fn23,
      apply: _fn24,
      save: _fn25
    }[_p115.action];
    if (!_v118) {
      _p117({
        ok: false,
        error: "lion_action_unsupported"
      });
      return;
    }
    Promise.resolve().then(() => _v118(_p115.args || {})).then(_p119 => _p117({
      ok: true,
      result: _p119
    })).catch(_p120 => _p117({
      ok: false,
      error: /^lion_[a-z_]+$/.test(_p120.message) ? _p120.message : "lion_requires_review"
    }));
    return true;
  });
})();