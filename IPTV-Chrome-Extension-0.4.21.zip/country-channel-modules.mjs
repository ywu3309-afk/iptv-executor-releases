/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
const E = ["en", "zh", "es", "fr", "de", "pt", "it", "sv", "ar"];
const o = [["italy", "IT", "it", ["ITALY", "ITALIA", "ITALIAN"]], ["sweden", "SE", "sv", ["SWEDEN", "SWEDISH"]], ["germany", "DE", "de", ["GERMANY", "GERMAN", "DEUTSCH", "ALMANIA", "ألمانية", "ألمانيه"]], ["france", "FR", "fr", ["FRANCE", "FRENCH", "FR", "FRANCAIS", "FRANÇAISE", "فرنسية"]], ["spain", "ES", "es", ["SPAIN", "SPANISH", "ES", "ESPANA", "ESPAÑA"]], ["united-kingdom", "GB", null, ["UK", "UNITED KINGDOM", "BRITISH"]], ["united-states", "US", null, ["USA", "UNITED STATES", "AMERICAN"]], ["canada", "CA", null, ["CANADA", "CANADIAN", "QUEBEC"]], ["portugal", "PT", "pt", ["PORTUGAL", "PORTUGUESE"]], ["netherlands", "NL", "nl", ["NETHERLAND", "NETHERLANDS", "DUTCH"]], ["belgium", "BE", null, ["BELGIUM", "BELGIAN"]], ["austria", "AT", null, ["AUSTRIA", "AUSTRIAN"]], ["switzerland", "CH", null, ["SWISS", "SWITZERLAND"]], ["poland", "PL", "pl", ["POLAND", "POLISH", "POLONIA", "POLSKIE", "PL"]], ["greece", "GR", "el", ["GREECE", "GREEK", "GR"]], ["cyprus", "CY", null, ["CYPRUS"]], ["latvia", "LV", null, ["LATVIA"]], ["denmark", "DK", "da", ["DENMARK", "DANMARK", "DANISH"]], ["norway", "NO", "no", ["NORWAY", "NORWEGIAN"]], ["finland", "FI", "fi", ["FINLAND", "FINNISH"]], ["iceland", "IS", null, ["ICELAND", "ICELANDIC"]], ["hungary", "HU", "hu", ["HUNGARY", "HUNGARIA", "HUNGARIAN"]], ["romania", "RO", "ro", ["ROMANIA", "ROMANIAN"]], ["albania", "AL", "sq", ["ALBANIA", "ALBANIAN"]], ["kosovo", "XK", null, ["KOSOVO"]], ["russia", "RU", "ru", ["RUSSIA", "RUSSIAN", "روسيه"]], ["ukraine", "UA", "uk", ["UKRAINE", "UKRAINIAN"]], ["israel", "IL", "he", ["ISRAEL", "HEBREW"]], ["australia", "AU", null, ["AUSTRALIA", "AUSTRALIAN"]], ["new-zealand", "NZ", null, ["NEW ZEALAND"]], ["lithuania", "LT", "lt", ["LITHUANIA", "LITHUANIAN"]], ["estonia", "EE", "et", ["ESTONIA", "ESTONIAN"]], ["slovenia", "SI", "sl", ["SLOVENIA", "SLOVENIAN"]], ["czechia", "CZ", "cs", ["CZECH", "CZECHIA"]], ["bulgaria", "BG", "bg", ["BULGARIA", "BULGARY", "BULGARIAN"]], ["armenia", "AM", "hy", ["ARMENIA", "ARMENIAN"]], ["georgia", "GE", "ka", ["GEORGIA", "GEORGIE", "GEORGIAN"]], ["malta", "MT", null, ["MALTA", "MALTESE"]], ["turkey", "TR", "tr", ["TURKEY", "TURKISH", "TURK", "تركية"]], ["india", "IN", "hi", ["INDIA", "INDIAN", "BOLLYWOOD", "هندية", "هندي"]], ["pakistan", "PK", "ur", ["PAKISTAN", "PAKISTANI"]], ["iran", "IR", "fa", ["IRAN", "IRANIAN"]], ["iraq", "IQ", null, ["IRAQ", "IRAQI", "عراقية", "عراقي"]], ["azerbaijan", "AZ", "az", ["AZERBAIJAN", "AZERBAIJANI", "AZERBAYCAN", "AZERBAJAN"]], ["kazakhstan", "KZ", "kk", ["KAZAKHSTAN", "KAZACHSTAN"]], ["afghanistan", "AF", null, ["AFGHANISTAN", "AFGHAN"]], ["philippines", "PH", "fil", ["PHILIPPINES", "PHILIPPINE", "PHILIPINES", "PHILIPINNES"]], ["china", "CN", "zh", ["CHINA", "CHINESE", "صيني"]], ["japan", "JP", "ja", ["JAPAN", "JAPANESE"]], ["south-korea", "KR", "ko", ["SOUTH KOREA", "SOUTHKOREA", "KOREA", "KOREAN"]], ["thailand", "TH", "th", ["THAILAND", "THAILLAND", "THAILANDE", "THAI"]], ["vietnam", "VN", "vi", ["VIETNAM", "VIETNAMESE"]], ["indonesia", "ID", "id", ["INDONESIA", "INDONESIAN"]], ["malaysia", "MY", "ms", ["MALAYSIA", "MALAYSIAN"]], ["singapore", "SG", null, ["SINGAPORE"]], ["bangladesh", "BD", "bn", ["BANGLADESH", "BENGALI"]], ["sri-lanka", "LK", null, ["SRI LANKA"]], ["somalia", "SO", "so", ["SOMALIA", "SOMALI"]], ["brazil", "BR", null, ["BRAZIL", "BRASIL"]], ["argentina", "AR", null, ["ARGENTINA"]], ["mexico", "MX", null, ["MEXICO"]], ["chile", "CL", null, ["CHILE"]], ["colombia", "CO", null, ["COLOMBIA"]], ["uruguay", "UY", null, ["URUGUAY"]], ["paraguay", "PY", null, ["PARAGUAY"]], ["peru", "PE", null, ["PERU"]], ["ecuador", "EC", null, ["ECUADOR"]], ["venezuela", "VE", null, ["VENEZUELA"]], ["panama", "PA", null, ["PANAMA"]], ["bolivia", "BO", null, ["BOLIVIA"]], ["costa-rica", "CR", null, ["COSTA RICA"]], ["dominican-republic", "DO", null, ["DOMINICAN"]], ["puerto-rico", "PR", null, ["PUERTO RICO"]], ["el-salvador", "SV", null, ["EL SALVADOR"]], ["guatemala", "GT", null, ["GUATEMALA"]], ["nicaragua", "NI", null, ["NICARAGUA"]], ["honduras", "HN", null, ["HONDURAS"]], ["cuba", "CU", null, ["CUBA"]], ["haiti", "HT", null, ["HAITI"]], ["jamaica", "JM", null, ["JAMAICA"]], ["morocco", "MA", null, ["MOROCCO", "MOROCCAN", "MAGHREB", "مغربية", "مغربي"]], ["algeria", "DZ", null, ["ALGERIA", "ALGERIE", "ALGERIAN", "جزائرية", "جزائري"]], ["tunisia", "TN", null, ["TUNISIA", "TUNIS", "TUNISIAN", "تونسية", "تونسي"]], ["egypt", "EG", null, ["EGYPT", "EGYPTE", "MASR", "مصرية", "مصريه", "مصري"]], ["libya", "LY", null, ["LIBYA", "LIBYAN", "ليبيا", "ليبي"]], ["sudan", "SD", null, ["SUDAN", "SUDANESE"]], ["lebanon", "LB", null, ["LEBANON", "LEBANESE", "لبناني", "لبنانية"]], ["syria", "SY", null, ["SYRIA", "SYRIAN", "سورية", "سوري"]], ["jordan", "JO", null, ["JORDAN", "JORDANIAN", "أردني"]], ["palestine", "PS", null, ["PALESTINE", "PALESTINIAN", "فلسطيني"]], ["saudi-arabia", "SA", null, ["SAUDI", "SAUDI ARABIA"]], ["united-arab-emirates", "AE", null, ["UAE", "EMIRATES"]], ["qatar", "QA", null, ["QATAR"]], ["kuwait", "KW", null, ["KUWAIT"]], ["bahrain", "BH", null, ["BAHRAIN"]], ["oman", "OM", null, ["OMAN"]], ["yemen", "YE", null, ["YEMEN", "YEMENI", "يمنية", "يمني"]], ["ireland", "IE", null, ["IRELAND", "IRISH"]], ["slovakia", "SK", "sk", ["SLOVAKIA", "SLOVAK"]], ["serbia", "RS", "sr", ["SERBIA", "SRBIJA"]], ["bosnia", "BA", "bs", ["BOSNIA"]], ["croatia", "HR", "hr", ["CROATIA"]], ["north-macedonia", "MK", "mk", ["MACEDONIA", "NORTH MACEDONIA"]], ["montenegro", "ME", null, ["MONTENEGRO"]], ["mauritania", "MR", "ar", ["MAURITANIA"]], ["cameroon", "CM", null, ["CAMEROON", "CAMEROONIAN"]], ["ghana", "GH", null, ["GHANA"]], ["ethiopia", "ET", null, ["ETHIOPIA"]], ["kenya", "KE", null, ["KENYA"]], ["congo", "CG", null, ["CONGO"]], ["senegal", "SN", null, ["SENEGAL"]], ["nigeria", "NG", null, ["NIGERIA"]], ["uganda", "UG", null, ["UGANDA"]], ["suriname", "SR", null, ["SURINAME"]], ["taiwan", "TW", null, ["TAIWAN"]], ["cambodia", "KH", null, ["CAMBODIA"]], ["hong-kong", "HK", null, ["HONG KONG", "HONGKONG"]], ["saint-lucia", "LC", null, ["SAINT LUCIA"]], ["uzbekistan", "UZ", "uz", ["UZBEKISTAN"]], ["tajikistan", "TJ", "tg", ["TAJIKISTAN"]], ["myanmar", "MM", null, ["MYANMAR"]], ["arabic", null, "ar", ["ARABIC", "ARABE", "ARAB"]], ["africa", null, null, ["AFRICA", "AFRICAN", "AFRIQUE"]], ["latin-america", null, null, ["LATINO", "LATIN AMERICA"]], ["scandinavia", null, null, ["SCANDINAVIA", "SCANDINAVIAN", "SCANDINAVE", "NORDIC"]], ["ex-yugoslavia", null, null, ["EXYU", "EX YU"]], ["caribbean", null, null, ["CARIBBEAN", "CARRIBEAN"]], ["kurdish", null, null, ["KURDISH", "KURD", "KURDISTAN"]], ["asia", null, null, ["ASIA", "ASIAN", "ASIATIC"]]];
const t = _p1 => String(_p1 || "").normalize("NFKD").replace(new RegExp("\\p{M}", "gu"), "").toUpperCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const R = (_p2, _p3) => (" " + _p2 + " ").includes(" " + _p3 + " ");
const S = /体育|運動|直播|频道|頻道|电视|電視|(?:sports?|sportifs?|deportes?|esportes?|sportivi|sportkanaler|live|direct|diretta|direto|en\s+vivo|ao\s+vivo|channels?|canales?|chaines?|sender|kanaler|canali|canais|tv)|(?:القنوات|قنوات|القناة|قناة|رياضة|رياضية|مباشر)/giu;
const c = /体育|運動|sports?|sportifs?|deportes?|esportes?|sportivi|sportkanaler|رياضة|رياضية/iu;
const O = /直播|live|direct|diretta|direto|en\s+vivo|ao\s+vivo|مباشر/iu;
function r(_p4, _p5, _p6) {
  try {
    return new Intl.DisplayNames([_p6], {
      type: _p4,
      fallback: "none"
    }).of(_p5) || "";
  } catch {
    return "";
  }
}
const u = o.map(([_p7, _p8, _p9, _p10]) => {
  const _v11 = new Set([_p7.replaceAll("-", " "), ..._p10]);
  for (const _v12 of E) {
    if (_p8) {
      _v11.add(r("region", _p8, _v12));
    }
    if (_p9) {
      _v11.add(r("language", _p9, _v12));
    }
  }
  return {
    id: _p7,
    labelTerms: [...new Set(_p10.map(t).filter(Boolean))],
    aliases: [...new Set([..._v11].map(t).filter(Boolean))]
  };
});
function L(_p13, _p14) {
  if (_p13 === _p14) {
    return true;
  } else if (_p13.includes(" ") || _p14.includes(" ") || _p14.length < 4) {
    return false;
  } else {
    return (_p13.startsWith(_p14) || _p14.startsWith(_p13)) && Math.abs(_p13.length - _p14.length) <= 6;
  }
}
function T(_p15) {
  const _v16 = String(_p15 || "");
  const _v17 = c.test(_v16);
  const _v18 = _v17 || O.test(_v16);
  const _v19 = t(_v16.replace(S, " ").replace(/\b(?:THE|LES|DIE|DER|DAS|LOS|LAS|OS|AS|I|LE|LA|DE|DEL|DES|DI|DA|DO|DAS)\b/giu, " ").replace(/[的]+/gu, " "));
  if (!_v19) {
    return null;
  }
  const _v20 = u.filter(_p21 => _p21.aliases.some(_p22 => L(_v19, _p22)));
  if (_v20.length !== 1) {
    return null;
  } else {
    return {
      definition: _v20[0],
      scope: _v18 ? "live" : "all",
      sports: _v17
    };
  }
}
function s(_p23, _p24) {
  const _v25 = t(_p23);
  return _p24.labelTerms.some(_p26 => R(_v25, _p26));
}
export function resolveCountryModule(_p27, _p28) {
  const _v29 = T(_p28);
  if (!_v29) {
    return null;
  }
  const _v30 = _v29.scope === "live" ? ["live"] : ["live", "movies", "series"];
  const _v31 = {
    live: [],
    movies: [],
    series: []
  };
  for (const _v33 of _v30) {
    _v31[_v33] = (_p27?.[_v33] || []).filter(_p34 => s(_p34.label, _v29.definition) && (!_v29.sports || /SPORT|DEPORT|رياض/iu.test(t(_p34.label))));
  }
  const _v32 = Object.values(_v31).reduce((_p35, _p36) => _p35 + _p36.length, 0);
  if (_v32) {
    return {
      id: _v29.definition.id,
      scope: _v29.scope,
      sports: _v29.sports,
      matches: _v31,
      count: _v32
    };
  } else {
    return null;
  }
}
export function countryModuleInventory(_p37) {
  return u.map(_p38 => {
    const _v39 = {
      live: [],
      movies: [],
      series: []
    };
    for (const _v40 of Object.keys(_v39)) {
      _v39[_v40] = (_p37?.[_v40] || []).filter(_p41 => s(_p41.label, _p38));
    }
    return {
      id: _p38.id,
      counts: Object.fromEntries(Object.entries(_v39).map(([_p42, _p43]) => [_p42, _p43.length])),
      total: Object.values(_v39).reduce((_p44, _p45) => _p44 + _p45.length, 0)
    };
  }).filter(_p46 => _p46.total > 0);
}