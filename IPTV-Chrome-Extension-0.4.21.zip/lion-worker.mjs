/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
const LION_ORIGIN = "https://lion2.bycdn.network";
const sleep = ms => new Promise(resolveLater => setTimeout(resolveLater, ms));
const selectedIds = items => items.filter(item => item.selected).map(item => item.id).sort();
/*
 * LION 标签页操作手
 *
 * 和另外两个 worker 一样：不直接碰页面，而是通过 chrome.tabs.sendMessage 把动作
 * 交给 lion-content.js，自己只负责「确认还在对的页面 → 发指令 → 核对结果」。
 *
 * 支持动作：prepare / create / inspect / edit / recover
 * 所有开号动作最后都会回读一次余额和频道，确认「扣了 0 积分、频道和预期一致」。
 */
export async function runLion(tabId, job) {
  // 每次操作前先确认标签页还在 lion 域名下、且不是登录页，避免在错误页面乱点。
  async function getTab() {
    const tab = await chrome.tabs.get(tabId);
    if (new URL(tab.url).origin !== LION_ORIGIN) {
      throw Error("lion_wrong_origin");
    }
    if (new URL(tab.url).pathname === "/login") {
      throw Error("lion_login_required");
    }
    return tab;
  }
  // 给页面脚本发指令；页面脚本没就绪会返回 ok:false，这里统一转成异常。
  async function sendCommand(action, args = {}) {
    await getTab();
    const reply = await chrome.tabs.sendMessage(tabId, {
      type: "iptv-lion-command",
      action: action,
      args: args
    });
    if (!reply?.ok) {
      throw Error(reply?.error || "lion_extension_not_ready");
    }
    return reply.result;
  }
  // 跳转到指定路径，等到「URL 对 + ping 通过 + documentToken 变了」才算完成。
  // documentToken 是页面实例的随机标识，变了说明真的是新页面，不是旧的没刷新。
  async function navigate(path) {
    await getTab();
    let previousToken;
    try {
      previousToken = (await sendCommand("ping")).documentToken;
    } catch {}
    if (typeof previousToken != "string" || !previousToken) {
      previousToken = null;
    }
    const targetUrl = new URL(LION_ORIGIN + path);
    await chrome.tabs.update(tabId, {
      url: targetUrl.href
    });
    const deadline = Date.now() + 25000;
    while (Date.now() < deadline) {
      const tab = await getTab();
      if (new URL(tab.url).href === targetUrl.href) {
        try {
          const reply = await sendCommand("ping");
          if (reply.version === "0.4.5" && reply.loggedIn === true && typeof reply.documentToken == "string" && reply.documentToken && (!previousToken || reply.documentToken !== previousToken) && new URL(reply.url).href === targetUrl.href) {
            return;
          }
        } catch {}
      }
      await sleep(200);
    }
    throw Error("lion_navigation_timeout");
  }
  // 已经在目标页就直接用，省一次刷新；否则走 navigate。
  async function ensurePage(path) {
    const targetUrl = new URL(LION_ORIGIN + path);
    const tab = await getTab();
    if (new URL(tab.url).href === targetUrl.href) {
      try {
        const reply = await sendCommand("ping");
        if (reply.version === "0.4.5" && reply.loggedIn === true && typeof reply.documentToken == "string" && reply.documentToken && new URL(reply.url).href === targetUrl.href) {
          return;
        }
      } catch {}
    }
    await navigate(path);
  }
  if (["prepare", "create"].includes(job.action)) {
    await ensurePage("/devices/m3u/create");
    if (job.action === "prepare") {
      return sendCommand("prepare");
    }
    const configured = await sendCommand("configure", job.args);
    try {
      await sendCommand("submitCreate", {
        ...job.args,
        balance: configured.summary.balance
      });
    } catch (error) {
      if (/^lion_/.test(error.message)) {
        throw error;
      }
    }
    const deadline = Date.now() + 30000;
    let arrived = false;
    while (Date.now() < deadline) {
      const tab = await getTab();
      if (tab.status === "complete" && new URL(tab.url).pathname === "/devices/m3u") {
        arrived = true;
        break;
      }
      await sleep(200);
    }
    if (!arrived) {
      throw Error("lion_creation_requires_review");
    }
    const readback = await sendCommand("inspect", job.args);
    if (readback.balance !== configured.summary.balance || JSON.stringify(selectedIds(readback.catalog)) !== JSON.stringify([...configured.selected].sort())) {
      throw Error("lion_creation_readback_mismatch");
    }
    return {
      ...readback,
      charge: {
        credits: 0,
        before: configured.summary.balance,
        after: readback.balance,
        trialLabel: configured.summary.trialLabel,
        source: "exact-zero-package-and-balance-readback"
      }
    };
  }
  if (!["inspect", "edit", "recover"].includes(job.action)) {
    throw Error("lion_unsupported_action");
  }
  await navigate("/devices/m3u");
  const account = await sendCommand("inspect", job.args.account);
  if (job.action === "inspect") {
    return account;
  }
  if (job.action === "recover") {
    if (account.balance !== job.args.expectedBalance || JSON.stringify(selectedIds(account.catalog)) !== JSON.stringify([...job.args.selected].sort())) {
      throw Error("lion_recovery_readback_mismatch");
    }
    return {
      ...account,
      charge: {
        credits: 0,
        before: job.args.expectedBalance,
        after: account.balance,
        trialLabel: "1 Day (12hours trial) (0 cds)",
        source: "original-preflight-and-readonly-recovery"
      }
    };
  }
  const nextSelected = new Set(job.args.selected || selectedIds(account.catalog));
  for (const channelId of job.args.selected || job.args.channelIds) {
    if (!account.catalog.some(item => item.id === channelId)) {
      throw Error("lion_unknown_channel");
    }
    if (!job.args.selected) {
      if (job.args.operation === "add") {
        nextSelected.add(channelId);
      } else if (job.args.operation === "remove") {
        nextSelected.delete(channelId);
      } else {
        throw Error("lion_invalid_operation");
      }
    }
  }
  if (!nextSelected.size) {
    throw Error("lion_empty_content");
  }
  const sorted = [...nextSelected].sort();
  if (JSON.stringify(sorted) === JSON.stringify(selectedIds(account.catalog))) {
    return {
      ...account,
      updated: false
    };
  }
  await sendCommand("apply", {
    account: job.args.account,
    selected: sorted
  });
  await sendCommand("save", {
    account: job.args.account,
    balance: account.balance
  });
  await navigate("/devices/m3u");
  const verified = await sendCommand("inspect", job.args.account);
  if (verified.balance !== account.balance || JSON.stringify(selectedIds(verified.catalog)) !== JSON.stringify(sorted) || ["username", "password", "expiryLabel", "playbackServer"].some(key => verified.account[key] !== account.account[key])) {
    throw Error("lion_edit_readback_mismatch");
  }
  return {
    ...verified,
    updated: true,
    refreshRequired: true
  };
}