/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
/*
 * MEGA（megaott.net）MAG 订阅页助手
 *
 * MAG 是按 MAC 地址开的线路，和普通线路页是两套页面，所以单独一个脚本。
 * 动作：ping / lookup / prepare / configure / submitCreate / submitEdit /
 *       find / inspect / apply / verify / ledger
 *
 * 关键约束：同一 MAC 只能存在一条记录。lookup 一旦发现已存在就拒绝开号。
 */
(() => {
  const CONTENT_VERSION = "0.4.12";
  const documentToken = crypto.randomUUID();
  const sleep = ms => new Promise(resolveLater => setTimeout(resolveLater, ms));
  const isVisible = node => !!node?.getClientRects().length;
  const textOf = node => (node?.innerText || "").trim();
  const waitFor = async (probe, timeoutMs = 18000) => {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const value = probe();
      if (value) {
        return value;
      }
      await sleep(200);
    }
    throw Error("mega_mag_page_timeout");
  };
  const findButtonByText = label => {
    const buttons = [...document.querySelectorAll("button,[role=\"button\"]")].filter(button => isVisible(button) && textOf(button) === label);
    if (buttons.length !== 1) {
      throw Error("mega_mag_button_mismatch");
    }
    return buttons[0];
  };
  const getScopeSelects = () => {
    const selects = [...document.querySelectorAll("select[multiple]")].filter(isVisible);
    if (selects.length !== 3) {
      throw Error("mega_mag_catalog_structure_changed");
    }
    return selects;
  };
  const readCatalog = () => Object.fromEntries(["live", "movies", "series"].map((scope, index) => [scope, [...getScopeSelects()[index].options].map(option => ({
    id: option.value,
    label: option.text.trim(),
    selected: option.selected
  }))]));
  const getNoteField = () => {
    const notes = [...document.querySelectorAll("textarea[name=\"note\"],textarea[placeholder=\"Add notes or special instructions...\"]")].filter(isVisible);
    if (notes.length !== 1) {
      throw Error("mega_mag_note_field_mismatch");
    }
    return notes[0];
  };
  const getMacInput = () => [...document.querySelectorAll("#mac_address")].find(isVisible);
  const setNativeValue = (field, value) => {
    if (!field) {
      throw Error("mega_mag_field_missing");
    }
    const prototype = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value").set.call(field, value);
    field.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    field.dispatchEvent(new Event("change", {
      bubbles: true
    }));
  };
  const normalizeMac = value => String(value || "").trim().toUpperCase();
  const toHttpsUrl = value => {
    try {
      const url = new URL(String(value || "").trim());
      if (["http:", "https:"].includes(url.protocol) && !url.username && !url.password && url.hostname) {
        return url.href.replace(/\/$/, "");
      } else {
        return null;
      }
    } catch {
      return null;
    }
  };
  const findTrialSelect = () => [...document.querySelectorAll("select")].find(select => [...select.options].some(option => option.text.trim() === "24 Hours - 0 Credits"));
  // 开号前的硬门槛：必须选中「24 Hours - 0 Credits」、免费名额 ≥ 1、积分 = 0、余额可读。
  function readTrialSummary() {
    const select = findTrialSelect();
    const option = select?.selectedOptions[0];
    const bodyText = document.body.innerText;
    const remainingMatch = bodyText.match(/Remaining Free Demo\s+(\d+)/i);
    const creditMatch = bodyText.match(/Package credit\s+([\d.]+)/i);
    const balanceMatch = bodyText.match(/\bBalance\s+([\d.]+)/i) || bodyText.match(/CREDITS\s+([\d.]+)\s+credits/i);
    if (option?.value !== "1" || option.text.trim() !== "24 Hours - 0 Credits" || !remainingMatch || Number(remainingMatch[1]) < 1 || !creditMatch || Number(creditMatch[1]) !== 0 || !balanceMatch || !Number.isFinite(Number(balanceMatch[1]))) {
      throw Error("mega_mag_nonfree_package");
    }
    return {
      credits: 0,
      remaining: Number(remainingMatch[1]),
      balance: Number(balanceMatch[1]),
      trialLabel: option.text.trim()
    };
  }
  const applyPlan = plan => {
    for (const scope of plan.changed) {
      const index = ["live", "movies", "series"].indexOf(scope);
      if (index < 0) {
        throw Error("mega_mag_invalid_scope");
      }
      const select = getScopeSelects()[index];
      const wanted = new Set(plan.selected[scope]);
      if ([...wanted].some(id => ![...select.options].some(option => option.value === id))) {
        throw Error("mega_mag_catalog_changed");
      }
      for (const option of select.options) {
        option.selected = wanted.has(option.value);
      }
      select.dispatchEvent(new Event("input", {
        bubbles: true
      }));
      select.dispatchEvent(new Event("change", {
        bubbles: true
      }));
    }
  };
  const verifyPlan = plan => {
    const snapshot = readCatalog();
    for (const scope of plan.changed) {
      if (JSON.stringify(snapshot[scope].filter(item => item.selected).map(item => item.id).sort()) !== JSON.stringify([...plan.selected[scope]].sort())) {
        throw Error("mega_mag_selection_mismatch");
      }
    }
  };
  // 三个分类都没选时，先套模板（test-huberyliu）把默认频道带上。
  async function applyTemplate() {
    if (getScopeSelects().every(select => select.selectedOptions.length > 0)) {
      return;
    }
    findButtonByText("Select Template").click();
    (await waitFor(() => [...document.querySelectorAll("button,[role=\"button\"]")].find(button => isVisible(button) && textOf(button) === "test-huberyliu"))).click();
    await waitFor(() => {
      try {
        return getScopeSelects().every(select => select.selectedOptions.length > 0);
      } catch {
        return false;
      }
    });
  }
  const listRows = () => [...document.querySelectorAll("tbody tr")].filter(isVisible);
  // 在订阅列表里按 MAC 搜索，返回带行号（bulk-cb-row-N）的行。
  // 搜索参数写死 searchBy=mac_address，防止搜到别的字段。
  async function loadRows(macAddress) {
    if (!location.pathname.startsWith("/subscriptions/mag")) {
      throw Error("mega_mag_wrong_list_page");
    }
    const url = new URL(location.href);
    if (url.searchParams.get("searchBy") !== "mac_address" || normalizeMac(url.searchParams.get("search")) !== normalizeMac(macAddress)) {
      throw Error("mega_mag_search_not_applied");
    }
    await sleep(1800);
    return listRows().filter(row => /^bulk-cb-row-\d+$/.test(row.querySelector("input[type=\"checkbox\"]")?.id || ""));
  }
  function rowId(row) {
    const id = row.querySelector("input[type=\"checkbox\"]")?.id?.match(/^bulk-cb-row-(\d+)$/)?.[1];
    if (!id) {
      throw Error("mega_mag_account_id_missing");
    }
    return id;
  }
  // 取播放门户链接：先看行内有没有现成的 https 链接，
  // 没有就点「portal/link」按钮，从弹出的 #portal-link 里读，读完按 Esc 关掉。
  async function readPortalUrl(row) {
    const href = [...row.querySelectorAll("a[href],input[value]")].map(element => element.href || element.value).map(toHttpsUrl).find(Boolean);
    if (href && new URL(href).hostname !== "megaott.net") {
      return href;
    }
    const buttons = [...row.querySelectorAll("button,[role=\"button\"],a")].filter(button => /portal|link/i.test([textOf(button), button.title, button.getAttribute("aria-label"), button.getAttribute("data-tooltip")].filter(Boolean).join(" ")));
    if (buttons.length === 1) {
      buttons[0].click();
      const link = await waitFor(() => {
        const linkElement = document.querySelector("#portal-link");
        return isVisible(linkElement) && toHttpsUrl(linkElement.value);
      }, 7000);
      document.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Escape",
        bubbles: true
      }));
      return link;
    }
    throw Error("mega_mag_portal_missing");
  }
  let submitted = false;
  // 指令入口。submitCreate / submitEdit 单独处理：先核对绑定，再置「已提交」标志，
  // 然后才点按钮——这样即使网络卡住也不会被点第二次。
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || message.type !== "iptv-mega-mag-command" || location.origin !== "https://megaott.net") {
      return;
    }
    const action = message.action;
    const args = message.args || {};
    if (action === "submitCreate" || action === "submitEdit") {
      try {
        if (submitted) {
          throw Error("mega_mag_write_already_dispatched");
        }
        if (action === "submitCreate") {
          const summary = readTrialSummary();
          if (normalizeMac(getMacInput()?.value) !== normalizeMac(args.macAddress) || getNoteField()?.value !== args.marker) {
            throw Error("mega_mag_create_binding_mismatch");
          }
          verifyPlan(args.plan);
          submitted = true;
          sendResponse({
            ok: true,
            result: {
              dispatched: true,
              summary: summary
            }
          });
          setTimeout(() => findButtonByText("Create Subscription").click(), 50);
        } else {
          if (!location.pathname.endsWith("/" + args.id + "/edit") || normalizeMac(getMacInput()?.value) !== normalizeMac(args.macAddress) || getNoteField()?.value !== args.marker) {
            throw Error("mega_mag_edit_binding_mismatch");
          }
          verifyPlan(args.plan);
          const buttons = ["Save Update", "Update Subscription"].flatMap(text => [...document.querySelectorAll("button")].filter(button => isVisible(button) && textOf(button) === text));
          if (buttons.length !== 1) {
            throw Error("mega_mag_update_button_mismatch");
          }
          submitted = true;
          sendResponse({
            ok: true,
            result: {
              dispatched: true
            }
          });
          setTimeout(() => buttons[0].click(), 50);
        }
      } catch (error) {
        sendResponse({
          ok: false,
          error: error.message
        });
      }
      return;
    }
    Promise.resolve().then(async () => {
      if (action === "ping") {
        return {
          version: CONTENT_VERSION,
          documentToken: documentToken,
          url: location.href,
          loggedIn: !location.pathname.includes("/login")
        };
      }
      if (action === "lookup") {
        const rows = await loadRows(args.macAddress);
        return {
          exists: rows.length > 0,
          count: rows.length,
          ids: rows.map(rowId)
        };
      }
      if (action === "prepare") {
        if (location.pathname !== "/subscriptions/mag/add") {
          throw Error("mega_mag_wrong_create_page");
        }
        await applyTemplate();
        return {
          catalog: readCatalog(),
          summary: readTrialSummary()
        };
      }
      if (action === "ledger") {
        return readTrialSummary();
      }
      if (action === "configure") {
        if (location.pathname !== "/subscriptions/mag/add") {
          throw Error("mega_mag_wrong_create_page");
        }
        applyPlan(args.plan);
        await sleep(1400);
        verifyPlan(args.plan);
        setNativeValue(getMacInput(), args.macAddress);
        await sleep(1400);
        setNativeValue(getNoteField(), args.marker);
        await sleep(1400);
        if (normalizeMac(getMacInput()?.value) !== normalizeMac(args.macAddress) || getNoteField()?.value !== args.marker) {
          throw Error("mega_mag_fields_not_saved");
        }
        verifyPlan(args.plan);
        return {
          prepared: true,
          summary: readTrialSummary()
        };
      }
      if (action === "find") {
        const rows = await loadRows(args.macAddress);
        if (rows.length !== 1) {
          throw Error(rows.length ? "mega_mag_mac_ambiguous" : "mega_mag_created_account_not_found");
        }
        const row = rows[0];
        const rowText = textOf(row);
        if (args.marker && !rowText.includes(args.marker)) {
          throw Error("mega_mag_marker_mismatch");
        }
        const id = rowId(row);
        const portalUrl = await readPortalUrl(row);
        const expiryLabel = /\bWaiting\b/i.test(rowText) ? "Waiting for first login" : rowText.match(/\b\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2})?\b/)?.[0];
        if (!expiryLabel) {
          throw Error("mega_mag_expiry_missing");
        }
        return {
          id: id,
          portalUrl: portalUrl,
          expiryLabel: expiryLabel
        };
      }
      if (action === "inspect") {
        if (!location.pathname.endsWith("/" + args.id + "/edit")) {
          throw Error("mega_mag_wrong_edit_page");
        }
        await waitFor(() => getNoteField() && getMacInput());
        const info = {
          id: String(args.id),
          macAddress: normalizeMac(getMacInput().value),
          marker: getNoteField().value,
          catalog: readCatalog()
        };
        if (args.macAddress && info.macAddress !== normalizeMac(args.macAddress)) {
          throw Error("mega_mag_mac_mismatch");
        }
        if (args.marker && info.marker !== args.marker) {
          throw Error("mega_mag_marker_mismatch");
        }
        return info;
      }
      if (action === "apply") {
        if (normalizeMac(getMacInput()?.value) !== normalizeMac(args.macAddress) || getNoteField()?.value !== args.marker) {
          throw Error("mega_mag_edit_binding_mismatch");
        }
        applyPlan(args.plan);
        await sleep(1600);
        verifyPlan(args.plan);
        return {
          prepared: true
        };
      }
      if (action === "verify") {
        verifyPlan(args.plan);
        return {
          verified: true
        };
      }
      throw Error("mega_mag_unsupported_command");
    }).then(result => sendResponse({
      ok: true,
      result: result
    }), error => sendResponse({
      ok: false,
      error: /^mega_mag_[a-z_]+$/.test(error.message) ? error.message : "mega_mag_operation_stopped"
    }));
    return true;
  });
})();