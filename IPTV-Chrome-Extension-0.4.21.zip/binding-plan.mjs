/* IPTV browser executor 0.4.21; source maps intentionally omitted. */
import { serverForUrl as _v1 } from "./server-registry.mjs";
export function bindingPlan(_p2, _p3) {
  if (!/^[a-f0-9]{64}$/.test(_p3 || "")) {
    throw Error("请从本机连接向导复制连接码。这不是后台 API 密钥或网页登录密码。");
  }
  const _v4 = {};
  for (const _v6 of _p2) {
    const _v7 = _v1(_v6.url);
    if (_v7) {
      (_v4[_v7.id] ??= []).push(_v6);
    }
  }
  const _v5 = Object.keys(_v4);
  if (!_v5.length) {
    throw Error("没有找到服务器后台。请先在此 Chrome 打开并登录至少一个后台。");
  }
  for (const [_v8, _v9] of Object.entries(_v4)) {
    if (_v9.length !== 1) {
      throw Error(_v8 + " 打开了多个标签，请只保留需要绑定的一个，避免选错账号。");
    }
    if (/\/(?:login|signin|auth)(?:\/|$)/i.test(new URL(_v9[0].url).pathname)) {
      throw Error(_v8 + " 仍在登录页，请先完成登录。");
    }
  }
  return {
    key: _p3,
    enabled: !!_v4.MEGA,
    tabId: _v4.MEGA?.[0].id || null,
    panelBindings: Object.fromEntries(_v5.filter(_p10 => _p10 !== "MEGA").map(_p11 => [_p11, {
      tabId: _v4[_p11][0].id,
      enabled: true
    }])),
    names: _v5
  };
}