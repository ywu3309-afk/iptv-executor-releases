/*
 * 执行端浏览器桥（chrome-bridge）
 *
 * 这是从 0.3.24 发布包里还原出来的源码，用来接插件、跑五个面板的开号/改频道任务。
 *
 * 结构：
 *   - 服务器表与试用规则（serverById / freeTrialCheck / planChannels）
 *   - 任务库（createPanelJobStore：panel_jobs 表，队列/结果都在这里）
 *   - 四个执行器：MEGA / LION / DINO+TREX / STRONG
 *   - createChromeBridge：起本机 HTTP 服务，给插件发任务、收结果
 *
 * 本版修改：STRONG 来源校验同时接受新旧两个域名（8k.cms-only.ru / 8k.online-cms.ru）。
 */
import { readFileSync as fn } from "node:fs";
import { join as fn2 } from "node:path";
import { DatabaseSync as value } from "node:sqlite";
function se(arg, arg2, arg3, arg4) {
  let value4;
  try {
    if (typeof arg2 != "string" || !/^[A-Za-z0-9-]{8,100}$/.test(arg2)) {
      return false;
    }
    let value5 = JSON.parse(fn(fn2(arg, "automation-config.json"), "utf8"));
    if (value5.enabled !== true || !value5.allowedCustomer || value5.allowedCustomer === "*" || value5.allowedCustomer !== value5.unlimitedTestCustomer) {
      return false;
    } else {
      value4 = new value(fn2(arg, "automation.sqlite"), {
        readOnly: true
      });
      return !!value4.prepare("SELECT 1 FROM customer_trials WHERE customer=? AND server_id=? AND request_id=? AND status=?").get(value5.unlimitedTestCustomer, arg3, arg2, arg4);
    }
  } catch {
    return false;
  } finally {
    value4?.close();
  }
}
function ae(arg, arg2, arg3) {
  return se(arg, arg2, arg3, "creating");
}
function oe(arg, arg2, arg3) {
  return se(arg, arg2, arg3, "needs_review");
}
import { randomUUID as fn3 } from "node:crypto";
var G = {
  updatedAt: "2026-09-07",
  source: "Owner corrected the complete quality order in this task",
  bestToWorst: ["STRONG", "TREX", "DINO", "MEGA", "LION"],
  topTierServer: "STRONG",
  defaultFirstTrial: "MEGA",
  rules: ["Recommend STRONG when the customer explicitly asks for the best or top-tier service.", "A customer may switch to an untried server, with at most one trial per customer per server.", "Do not infer quality from price or promise provisioning for a server whose reception integration is unavailable."]
};
var pr = "Owner-confirmed quality, best to worst: " + G.bestToWorst.join(" > ") + ". Recommend " + G.topTierServer + " for the best or top-tier service. Default first trial remains " + G.defaultFirstTrial + ". Each customer may try each server only once. Recommendation is not a claim of connection availability or account creation.";
var $ = Object.freeze([{
  id: "LION",
  rank: 5,
  origin: "https://lion2.bycdn.network",
  createPath: "/devices/m3u/create",
  family: "lion",
  trialLabel: "1 Day (12hours trial) (0 cds)",
  hours: 12
}, {
  id: "MEGA",
  rank: 4,
  origin: "https://megaott.net",
  createPath: "/subscriptions/lines/add",
  family: "mega",
  trialLabel: "24 Hours - 0 Credits",
  hours: 24
}, {
  id: "DINO",
  rank: 3,
  origin: "https://www.tvpluspanel.ru",
  origins: ["https://www.tvpluspanel.ru", "https://tvpluspanel.ru"],
  createPath: "/addnew?t=lines",
  family: "classic",
  trialLabel: "1 Day",
  hours: 24
}, {
  id: "TREX",
  rank: 2,
  origin: "https://activationpanel.ru",
  createPath: "/addnew?t=lines",
  family: "classic",
  trialLabel: "1 Day",
  hours: 24
}, {
  id: "STRONG",
  rank: 1,
  origin: "https://8k.cms-only.ru",
  createPath: "/addnew?t=lines",
  family: "strong",
  trialLabel: "1 Day",
  hours: 24
}].sort((arg, arg2) => G.bestToWorst.indexOf(arg.id) - G.bestToWorst.indexOf(arg2.id)));
var q = Object.freeze({
  mode: "browser_with_api_evaluation",
  apiCreateEnabled: false,
  allowCredits: false,
  allowDemoTickets: true
});
function W(arg) {
  let value4 = $.find(arg2 => arg2.id === arg);
  if (!value4) {
    throw Error("unknown_server");
  }
  return value4;
}
function V(arg, url) {
  let url2 = W(arg);
  if (!(url2.origins || [url2.origin]).includes(url.origin) || url.trialLabel !== url2.trialLabel) {
    return {
      ok: false,
      reason: "套餐或后台不匹配"
    };
  } else if (/ticket/i.test(url.price || "")) {
    if (!q.allowDemoTickets || !/^1\s+Ticket$/i.test((url.price || "").trim())) {
      return {
        ok: false,
        reason: "试用费用不明确或超过一次一张券"
      };
    } else if (!Number.isInteger(url.ticketsRemaining) || url.ticketsRemaining < 1) {
      return {
        ok: false,
        reason: "允许消耗试用券；可用券数量尚未确认或不足"
      };
    } else {
      return {
        ok: true,
        reason: "允许消耗 1 张试用券；不得扣积分",
        cost: {
          credits: 0,
          tickets: 1
        }
      };
    }
  } else if (/^(?:Free|0(?:\.0+)?(?:\s*(?:Credits|CDS))?)$/i.test((url.price || "").trim())) {
    if (!Number.isInteger(url.remaining) || url.remaining < 1) {
      return {
        ok: false,
        reason: "免费名额尚未确认或已用完"
      };
    } else {
      return {
        ok: true,
        reason: "免费价格及名额预检通过；仍需模板与发号验收"
      };
    }
  } else {
    return {
      ok: false,
      reason: "未确认零积分价格"
    };
  }
}
function ie(arg, {
  timeoutMs: arg2 = 45000
} = {}) {
  arg.exec("CREATE TABLE IF NOT EXISTS panel_jobs(id TEXT PRIMARY KEY,server TEXT NOT NULL,state TEXT NOT NULL,result TEXT,error TEXT,created_at TEXT NOT NULL);\n    UPDATE panel_jobs SET state='needs_review',error='服务重启，请重新预检' WHERE state IN ('queued','running');");
  let map = new Map();
  let map2 = new Map();
  let fn27 = arg3 => Date.now() - (map.get(arg3) || 0) < 65000;
  function value4() {
    return {
      defaultServer: "MEGA",
      servers: $.filter(arg3 => arg3.id !== "MEGA").map(arg3 => {
        let job = arg.prepare("SELECT * FROM panel_jobs WHERE server=? ORDER BY rowid DESC LIMIT 1").get(arg3.id);
        let value8 = job?.state === "done" ? JSON.parse(job.result) : null;
        return {
          ...arg3,
          connected: fn27(arg3.id),
          automationReady: false,
          stage: "preflight",
          latest: job ? {
            state: job.state,
            at: job.created_at,
            error: job.error,
            ...(value8 ? {
              summary: value8.summary,
              counts: value8.counts,
              check: V(arg3.id, value8.summary)
            } : {})
          } : null
        };
      })
    };
  }
  function value5(arg3) {
    W(arg3);
    if (arg3 === "MEGA") {
      throw Error("use_mega_bridge");
    }
    if (!fn27(arg3)) {
      throw Error("该服务器扩展尚未连接");
    }
    if (arg.prepare("SELECT id FROM panel_jobs WHERE server=? AND state IN ('queued','running')").get(arg3)) {
      throw Error("该服务器已有预检进行中");
    }
    let value8 = fn3();
    arg.prepare("INSERT INTO panel_jobs VALUES(?,?,?,NULL,NULL,?)").run(value8, arg3, "queued", new Date().toISOString());
    return new Promise((arg4, fn28) => {
      let value9 = setTimeout(() => {
        map2.delete(value8);
        arg.prepare("UPDATE panel_jobs SET state='failed',error='预检超时' WHERE id=? AND state IN ('queued','running')").run(value8);
        fn28(Error("预检超时，未提交账号操作"));
      }, arg2);
      map2.set(value8, {
        resolve: arg4,
        reject: fn28,
        timer: value9
      });
    });
  }
  function value6(arg3) {
    if (W(arg3).id === "MEGA") {
      throw Error("use_mega_bridge");
    }
    map.set(arg3, Date.now());
    if (arg.prepare("SELECT id FROM panel_jobs WHERE server=? AND state='running'").get(arg3)) {
      return {
        job: null
      };
    }
    let value8 = arg.prepare("SELECT id FROM panel_jobs WHERE server=? AND state='queued' ORDER BY rowid LIMIT 1").get(arg3);
    if (value8) {
      arg.prepare("UPDATE panel_jobs SET state='running' WHERE id=?").run(value8.id);
      return {
        job: {
          id: value8.id,
          server: arg3,
          action: "prepare"
        }
      };
    } else {
      return {
        job: null
      };
    }
  }
  function value7(server) {
    let server2 = arg.prepare("SELECT * FROM panel_jobs WHERE id=?").get(server.id);
    if (!server2 || server2.server !== server.server) {
      throw Error("wrong_server_result");
    }
    if (server2.state === "done" || server2.state === "failed") {
      return {
        received: true
      };
    }
    if (server2.state !== "running") {
      throw Error("stale_result");
    }
    let value8 = null;
    let value9 = server.error ? /^panel_preflight_(?:start|lion_open|lion_select|classic_select|strong_open|strong_select|catalog)$/.test(server.error) ? "后台预检未完成：" + server.error : "后台预检未完成，请检查登录和表单" : null;
    if (!value9) {
      try {
        let plan = server.result;
        let url = W(server2.server);
        if (!(url.origins || [url.origin]).includes(plan?.summary?.origin)) {
          throw Error();
        }
        let options = {
          origin: plan.summary.origin,
          trialLabel: String(plan.summary.trialLabel || "").slice(0, 80),
          price: String(plan.summary.price || "").slice(0, 40),
          remaining: Number.isInteger(plan.summary.remaining) ? plan.summary.remaining : null,
          ticketsRemaining: Number.isInteger(plan.summary.ticketsRemaining) ? plan.summary.ticketsRemaining : null
        };
        let options2 = {};
        for (let value11 of ["live", "movies", "series", "mixed"]) {
          if (!Array.isArray(plan.catalog?.[value11]) || plan.catalog[value11].length > 3000 || (options2[value11] = plan.catalog[value11].map(plan2 => {
            if (typeof plan2.id != "string" || !plan2.id || plan2.id.length > 100 || typeof plan2.label != "string" || !plan2.label || plan2.label.length > 300) {
              throw Error();
            }
            return {
              id: plan2.id,
              label: plan2.label,
              selected: plan2.selected === true
            };
          }), new Set(options2[value11].map(arg3 => arg3.id)).size !== options2[value11].length)) {
            throw Error();
          }
        }
        if (!options2.live.length) {
          throw Error();
        }
        value8 = {
          summary: options,
          catalog: options2,
          counts: Object.fromEntries(Object.entries(options2).map(([arg3, arg4]) => [arg3, arg4.length])),
          check: V(url.id, options)
        };
      } catch {
        value9 = "页面结构或套餐核验失败，未提交账号操作";
      }
    }
    arg.prepare("UPDATE panel_jobs SET state=?,result=?,error=? WHERE id=?").run(value9 ? "failed" : "done", JSON.stringify(value8), value9, server2.id);
    let value10 = map2.get(server2.id);
    if (value10) {
      clearTimeout(value10.timer);
      map2.delete(server2.id);
      if (value9) {
        value10.reject(Error(value9));
      } else {
        value10.resolve(value8);
      }
    }
    return {
      received: true
    };
  }
  return {
    status: value4,
    enqueue: value5,
    next: value6,
    result: value7,
    close() {
      for (let value8 of map2.values()) {
        clearTimeout(value8.timer);
        value8.reject(Error("bridge_closed"));
      }
      map2.clear();
    }
  };
}
import { randomUUID as fn4 } from "node:crypto";
import { existsSync as fn5, readFileSync as fn6 } from "node:fs";
import { join as fn7 } from "node:path";
function ne(arg, {
  data: arg2,
  timeoutMs: arg3 = 140000,
  maxCreates: arg4 = 1,
  canExceedLimit: fn27 = () => false,
  version: arg5 = "0.4.5"
} = {}) {
  arg.exec("CREATE TABLE IF NOT EXISTS strong_browser_jobs(id TEXT PRIMARY KEY,action TEXT,args TEXT,state TEXT,result TEXT,error TEXT,created_at TEXT);\n CREATE TABLE IF NOT EXISTS strong_browser_accounts(id TEXT PRIMARY KEY,account TEXT NOT NULL,catalog TEXT,source TEXT NOT NULL);\n UPDATE strong_browser_jobs SET state=CASE WHEN action='recover' THEN 'failed' ELSE 'needs_review' END,error='服务重启，禁止重复提交' WHERE state IN ('queued','running');");
  let value4 = arg2 && fn7(arg2, "strong-browser-validation.json");
  if (value4 && fn5(value4)) {
    let account = JSON.parse(fn6(value4, "utf8"));
    if (account.server === "STRONG" && account.browserRoundTripVerified === true && account.chargedCredits === 0 && /^\d+$/.test(account.id) && /^IPTVBOT-STRONG-/.test(account.marker)) {
      arg.prepare("INSERT OR IGNORE INTO strong_browser_accounts VALUES(?,?,?,?)").run(account.id, JSON.stringify({
        server: "STRONG",
        id: account.id,
        username: account.username,
        marker: account.marker,
        expiryLabel: account.expiryLabel
      }), null, "manual-validated");
    }
  }
  let map = new Map();
  let value5 = 0;
  let fn28 = () => Date.now() - value5 < 65000;
  function fn29() {
    return {
      server: "STRONG",
      mode: "browser",
      extensionReady: fn28(),
      version: arg5,
      automaticReceptionEnabled: false,
      createRemaining: Math.max(0, arg4 - arg.prepare("SELECT count(*) n FROM strong_browser_accounts").get().n - arg.prepare("SELECT count(*) n FROM strong_browser_jobs WHERE action='create' AND state!='done'").get().n),
      accounts: arg.prepare("SELECT * FROM strong_browser_accounts").all().map(plan => {
        let account = JSON.parse(plan.account);
        return {
          id: account.id,
          username: account.username,
          marker: account.marker,
          expiryLabel: account.expiryLabel,
          catalog: plan.catalog ? JSON.parse(plan.catalog) : null,
          source: plan.source
        };
      }),
      jobs: arg.prepare("SELECT id,action,state,error,created_at FROM strong_browser_jobs ORDER BY rowid DESC LIMIT 10").all()
    };
  }
  function value6(arg6) {
    if (arg6 !== arg5) {
      return {
        job: null
      };
    }
    value5 = Date.now();
    if (arg.prepare("SELECT id FROM strong_browser_jobs WHERE state='running'").get()) {
      return {
        job: null
      };
    }
    let value9 = arg.prepare("SELECT * FROM strong_browser_jobs WHERE state='queued' ORDER BY rowid LIMIT 1").get();
    if (value9) {
      arg.prepare("UPDATE strong_browser_jobs SET state='running' WHERE id=?").run(value9.id);
      return {
        job: {
          id: value9.id,
          server: "STRONG",
          action: value9.action,
          args: JSON.parse(value9.args)
        }
      };
    } else {
      return {
        job: null
      };
    }
  }
  function value7(arg6, plan = {}) {
    if (!["prepare", "inspect", "create", "edit", "recover"].includes(arg6)) {
      throw Error("操作不支持");
    }
    if (!fn28()) {
      throw Error("请重载扩展至 " + arg5 + " 并保持 STRONG 标签已绑定");
    }
    if (arg.prepare(arg6 === "recover" ? "SELECT id FROM strong_browser_jobs WHERE state IN ('queued','running')" : "SELECT id FROM strong_browser_jobs WHERE state IN ('queued','running','needs_review')").get()) {
      throw Error("已有待处理或待核查任务，禁止重复操作");
    }
    let value9;
    let value10 = fn4();
    if (arg6 === "create") {
      if (fn29().createRemaining < 1 && !fn27(plan.requestId, "STRONG")) {
        throw Error("本轮 STRONG 测试账号已创建，禁止重复开户");
      }
      if (!/^[A-Za-z0-9-]{8,80}$/.test(plan.requestId || "")) {
        throw Error("请求编号无效");
      }
      value10 = plan.requestId;
      if (arg.prepare("SELECT id FROM strong_browser_jobs WHERE id=?").get(value10)) {
        throw Error("该开户请求已有记录");
      }
      value9 = {
        marker: "IPTVBOT-STRONG-" + value10.toUpperCase()
      };
    } else if (arg6 === "recover") {
      if (!/^[A-Za-z0-9-]{8,80}$/.test(plan.requestId || "") || !/^\d+$/.test(String(plan.id || "")) || typeof plan.username != "string" || !plan.username.trim() || plan.username.length > 100) {
        throw Error("恢复参数无效");
      }
      let value11 = arg.prepare("SELECT * FROM strong_browser_jobs WHERE id=? AND action='create' AND state='needs_review'").get(plan.requestId);
      if (!value11) {
        throw Error("仅允许核查原先结果不明的开户任务");
      }
      let account = JSON.parse(value11.args);
      if (account.marker !== "IPTVBOT-STRONG-" + plan.requestId.toUpperCase()) {
        throw Error("原开户归属标记不符");
      }
      value9 = {
        originalRequestId: plan.requestId,
        account: {
          server: "STRONG",
          id: String(plan.id),
          username: plan.username,
          marker: account.marker
        }
      };
    } else if (arg6 === "prepare") {
      value9 = {};
    } else {
      let value11 = arg.prepare("SELECT account FROM strong_browser_accounts WHERE id=?").get(String(plan.accountId));
      if (!value11) {
        throw Error("仅允许操作已绑定的 STRONG 测试账号");
      }
      value9 = {
        account: JSON.parse(value11.account)
      };
      if (arg6 === "edit") {
        if (plan.selected) {
          if (!Array.isArray(plan.selected) || !plan.selected.length || plan.selected.length > 3000 || plan.selected.some(arg7 => typeof arg7 != "string" || !/^\d+$/.test(arg7)) || new Set(plan.selected).size !== plan.selected.length) {
            throw Error("频道参数无效");
          }
          value9 = {
            ...value9,
            selected: plan.selected
          };
        } else {
          if (!["add", "remove"].includes(plan.operation) || !Array.isArray(plan.channelIds) || !plan.channelIds.length || plan.channelIds.length > 500 || plan.channelIds.some(arg7 => typeof arg7 != "string" || !/^\d+$/.test(arg7))) {
            throw Error("频道参数无效");
          }
          value9 = {
            ...value9,
            operation: plan.operation,
            channelIds: [...new Set(plan.channelIds)]
          };
        }
      }
    }
    arg.prepare("INSERT INTO strong_browser_jobs VALUES(?,?,?,?,NULL,NULL,?)").run(value10, arg6, JSON.stringify(value9), "queued", new Date().toISOString());
    return new Promise((arg7, fn30) => {
      let value11 = setTimeout(() => {
        map.delete(value10);
        arg.prepare("UPDATE strong_browser_jobs SET state=?,error='结果不明，禁止重试' WHERE id=? AND state IN ('queued','running')").run(arg6 === "recover" ? "failed" : "needs_review", value10);
        fn30(Error("浏览器结果不明，已阻止自动重试"));
      }, arg3);
      map.set(value10, {
        resolve: arg7,
        reject: fn30,
        timer: value11
      });
    });
  }
  function value8(server) {
    let job = arg.prepare("SELECT * FROM strong_browser_jobs WHERE id=?").get(server.id);
    if (!job || server.server !== "STRONG") {
      throw Error("任务归属不符");
    }
    if (["done", "failed"].includes(job.state)) {
      return {
        received: true
      };
    }
    if (job.state !== "running") {
      throw Error("过期结果需人工核查");
    }
    let value9 = null;
    let value10 = server.error ? /^strong_[a-z_]{1,100}$/.test(server.error) ? server.error : "STRONG 操作未完成，需核查后台；不自动重试" : null;
    if (job.action === "prepare") {
      let plan = server.result;
      if (!value10 && (!["https://8k.cms-only.ru", "https://8k.online-cms.ru"].includes(plan?.summary?.origin) || plan.summary.price !== "Free" || plan.summary.trialLabel !== "1 Day" || !Number.isInteger(plan.summary.remaining) || plan.summary.remaining < 1 || !Array.isArray(plan.catalog) || !plan.catalog.length)) {
        value10 = "STRONG 免费预检未通过";
      }
      value9 = value10 ? null : plan;
      arg.prepare("UPDATE strong_browser_jobs SET state=?,result=?,error=? WHERE id=?").run(value10 ? "failed" : "done", JSON.stringify(value9), value10, job.id);
      let value13 = map.get(job.id);
      if (value13) {
        clearTimeout(value13.timer);
        map.delete(job.id);
        if (value10) {
          value13.reject(Error(value10));
        } else {
          value13.resolve(value9);
        }
      }
      return {
        received: true
      };
    }
    if (!value10) {
      try {
        let plan = server.result;
        let account = JSON.parse(job.args);
        let account2 = plan.account;
        if (account2?.server !== "STRONG" || !/^\d+$/.test(account2.id) || !account2.username || !account2.password || account2.marker !== (account.marker || account.account.marker) || account2.reseller !== "ych2025iptv") {
          throw Error();
        }
        let url = new URL(account2.m3uUrl);
        if (account2.linkSource !== "My Cloud" || !["http:", "https:"].includes(url.protocol) || url.username || url.password || url.hostname !== "cf.my8kk.com" || url.origin !== account2.playbackServer || url.pathname !== "/get.php" || url.searchParams.get("username") !== account2.username || url.searchParams.get("password") !== account2.password || url.searchParams.get("type") !== "m3u_plus" || url.searchParams.get("output") !== "ts" || ["username", "password", "type", "output"].some(arg6 => url.searchParams.getAll(arg6).length !== 1) || account.account && (account2.id !== account.account.id || account2.username !== account.account.username) || !Array.isArray(plan.catalog) || !plan.catalog.length || plan.catalog.length > 3000 || plan.catalog.some(plan2 => !/^\d+$/.test(plan2.id) || typeof plan2.label != "string" || !plan2.label || plan2.label.length > 300 || typeof plan2.selected != "boolean") || new Set(plan.catalog.map(arg6 => arg6.id)).size !== plan.catalog.length || ["create", "recover"].includes(job.action) && (plan.charge?.credits !== 0 || plan.charge?.type !== "Demo" || plan.charge.username !== account2.username || plan.catalog.some(plan2 => !plan2.selected))) {
          throw Error();
        }
        if (job.action === "recover") {
          let value13 = arg.prepare("SELECT * FROM strong_browser_jobs WHERE id=? AND action='create' AND state='needs_review'").get(account.originalRequestId);
          if (!value13 || JSON.parse(value13.args).marker !== account2.marker || !/^\d+$/.test(String(plan.charge.ledgerId || ""))) {
            throw Error();
          }
          let url2 = new URL(account2.playbackServer);
          if (!["http:", "https:"].includes(url2.protocol) || url2.origin !== account2.playbackServer) {
            throw Error();
          }
          let value14 = arg.prepare("SELECT account FROM strong_browser_accounts WHERE id=?").get(account2.id);
          if (value14) {
            let account3 = JSON.parse(value14.account);
            if (account3.marker !== account2.marker || account3.username !== account2.username) {
              throw Error();
            }
          }
        }
        value9 = {
          account: account2,
          catalog: plan.catalog,
          updated: plan.updated === true,
          refreshRequired: plan.refreshRequired === true,
          ...(["create", "recover"].includes(job.action) ? {
            charge: plan.charge
          } : {}),
          ...(job.action === "recover" ? {
            recoveredRequestId: account.originalRequestId
          } : {})
        };
        arg.exec("BEGIN IMMEDIATE");
        try {
          arg.prepare("INSERT INTO strong_browser_accounts VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog,source=excluded.source").run(account2.id, JSON.stringify(account2), JSON.stringify(plan.catalog), job.action === "recover" ? "extension-recovered" : "extension-verified");
          if (job.action === "recover") {
            arg.prepare("UPDATE strong_browser_jobs SET state='done',result=?,error=NULL WHERE id=? AND state='needs_review'").run(JSON.stringify(value9), account.originalRequestId);
            arg.prepare("UPDATE strong_browser_jobs SET state='done',result=?,error=NULL WHERE id=? AND state='running'").run(JSON.stringify(value9), job.id);
          }
          arg.exec("COMMIT");
        } catch (value13) {
          arg.exec("ROLLBACK");
          throw value13;
        }
      } catch {
        value10 = "STRONG 账号或频道回读不符，需核查后台";
      }
    }
    let value11 = value10 ? ["inspect", "recover"].includes(job.action) ? "failed" : "needs_review" : "done";
    arg.prepare("UPDATE strong_browser_jobs SET state=?,result=?,error=? WHERE id=?").run(value11, JSON.stringify(value9), value10, job.id);
    let value12 = map.get(job.id);
    if (value12) {
      clearTimeout(value12.timer);
      map.delete(job.id);
      if (value10) {
        value12.reject(Error(value10));
      } else {
        value12.resolve(value9);
      }
    }
    return {
      received: true
    };
  }
  return {
    status: fn29,
    next: value6,
    enqueue: value7,
    result: value8,
    close() {
      for (let value9 of map.values()) {
        clearTimeout(value9.timer);
        value9.reject(Error("bridge_closed"));
      }
      map.clear();
    }
  };
}
import { randomUUID as fn8, createHash as fn9 } from "node:crypto";
var ce = "1 Day (12hours trial) (0 cds)";
var ke = "https://lion2.bycdn.network";
function le(arg) {
  return Array.isArray(arg) && arg.length > 0 && arg.length <= 3000 && arg.every(plan => /^\d+$/.test(plan.id) && typeof plan.label == "string" && plan.label.length > 0 && plan.label.length <= 300 && typeof plan.selected == "boolean" && ["live", "movies", "series"].includes(plan.group)) && new Set(arg.map(arg2 => arg2.id)).size === arg.length;
}
function ue(arg, {
  timeoutMs: arg2 = 140000,
  maxCreates: arg3 = 1,
  canExceedLimit: fn27 = () => false,
  version: arg4 = "0.4.5"
} = {}) {
  if (!Number.isInteger(arg3) || arg3 < 0) {
    throw Error("lion_invalid_limit");
  }
  arg.exec("CREATE TABLE IF NOT EXISTS lion_browser_jobs(id TEXT PRIMARY KEY,action TEXT NOT NULL,args TEXT NOT NULL,state TEXT NOT NULL,result TEXT,error TEXT,created_at TEXT NOT NULL);\n    CREATE TABLE IF NOT EXISTS lion_browser_accounts(id TEXT PRIMARY KEY,customer TEXT,account TEXT NOT NULL,catalog TEXT NOT NULL);\n    CREATE TABLE IF NOT EXISTS lion_browser_meta(id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT,prepared_at TEXT);\n    UPDATE lion_browser_jobs SET state='needs_review',error='服务重启，结果待核查；禁止重复提交' WHERE state IN ('queued','running');");
  let value4 = 0;
  let map = new Map();
  let fn28 = () => value4 > 0 && Date.now() - value4 < 65000;
  function fn29() {
    let value8 = arg.prepare("SELECT * FROM lion_browser_meta WHERE id=1").get();
    return {
      server: "LION",
      mode: "browser",
      version: arg4,
      extensionReady: fn28(),
      prepared: !!value8,
      automaticReceptionEnabled: fn28() && !!value8,
      maxCreates: arg3,
      createRemaining: Math.max(0, arg3 - arg.prepare("SELECT count(*) n FROM lion_browser_jobs WHERE action='create'").get().n),
      accounts: arg.prepare("SELECT id,customer,account FROM lion_browser_accounts").all().map(arg5 => {
        let account = JSON.parse(arg5.account);
        return {
          id: arg5.id,
          customer: arg5.customer,
          username: account.username,
          expiryLabel: account.expiryLabel
        };
      }),
      jobs: arg.prepare("SELECT id,action,state,error,created_at FROM lion_browser_jobs ORDER BY rowid DESC LIMIT 10").all()
    };
  }
  function value5(arg5) {
    if (arg5 !== arg4) {
      return {
        job: null
      };
    }
    value4 = Date.now();
    if (arg.prepare("SELECT id FROM lion_browser_jobs WHERE state='running'").get()) {
      return {
        job: null
      };
    }
    let value8 = arg.prepare("SELECT * FROM lion_browser_jobs WHERE state='queued' ORDER BY rowid LIMIT 1").get();
    if (value8) {
      arg.prepare("UPDATE lion_browser_jobs SET state='running' WHERE id=?").run(value8.id);
      return {
        job: {
          id: value8.id,
          server: "LION",
          action: value8.action,
          args: JSON.parse(value8.args)
        }
      };
    } else {
      return {
        job: null
      };
    }
  }
  function value6(arg5, plan = {}) {
    if (!["prepare", "create", "inspect", "edit", "recover"].includes(arg5)) {
      throw Error("LION 操作不支持");
    }
    if (!fn28()) {
      throw Error("LION 扩展未连接，请重载并保持登录");
    }
    if (arg.prepare("SELECT id FROM lion_browser_jobs WHERE state IN ('queued','running')").get() || arg5 !== "recover" && arg.prepare("SELECT id FROM lion_browser_jobs WHERE state='needs_review'").get()) {
      throw Error("LION 有待处理或待核查任务，禁止重复操作");
    }
    let value8 = fn8();
    let options = {};
    if (arg5 === "recover") {
      let value9 = arg.prepare("SELECT rowid AS job_row,* FROM lion_browser_jobs WHERE id=? AND action='create' AND state='needs_review'").get(plan.requestId);
      if (!value9) {
        throw Error("LION 无可回读恢复的原始开户任务");
      }
      if (arg.prepare("SELECT id FROM lion_browser_jobs WHERE state='needs_review' AND id<>?").get(value9.id)) {
        throw Error("LION 另有待核查任务");
      }
      let job = arg.prepare("SELECT result FROM lion_browser_jobs WHERE action='prepare' AND state='done' AND rowid<? ORDER BY rowid DESC LIMIT 1").get(value9.job_row);
      let plan2 = job && JSON.parse(job.result);
      let value10 = JSON.parse(value9.args);
      if (!plan2 || !Number.isFinite(plan2.summary?.balance) || !le(plan2.catalog) || value10.reseller !== plan2.summary.reseller) {
        throw Error("LION 原始零费用预检证据缺失");
      }
      options = {
        account: value10,
        customer: value10.customer,
        originalRequestId: value9.id,
        expectedBalance: plan2.summary.balance,
        selected: plan2.catalog.map(arg6 => arg6.id),
        reseller: value10.reseller
      };
    } else if (arg5 === "create") {
      let value9 = arg.prepare("SELECT * FROM lion_browser_meta WHERE id=1").get();
      if (!value9) {
        throw Error("LION 需要先完成免费套餐预检");
      }
      if (fn29().createRemaining < 1 && !fn27(plan.requestId, "LION")) {
        throw Error("LION 本轮开户额度已用完");
      }
      if (!/^[\w-]{8,100}$/.test(plan.requestId || "")) {
        throw Error("LION 请求编号无效");
      }
      if (plan.customer != null && (typeof plan.customer != "string" || plan.customer.length > 160 || !plan.customer)) {
        throw Error("LION 客户标识无效");
      }
      if (plan.customer && arg.prepare("SELECT id FROM lion_browser_accounts WHERE customer=?").get(plan.customer)) {
        throw Error("该客户已领取 LION 试用");
      }
      value8 = plan.requestId;
      if (arg.prepare("SELECT id FROM lion_browser_jobs WHERE id=?").get(value8)) {
        throw Error("LION 请求已登记，禁止重复开户");
      }
      let value10 = fn9("sha256").update(value8).digest("hex").slice(0, 20);
      options = {
        username: "ib" + value10,
        marker: "IPTVBOT-LION-" + value10.toUpperCase(),
        reseller: value9.owner,
        customer: plan.customer || null
      };
    } else if (arg5 !== "prepare") {
      let plan2 = arg.prepare("SELECT * FROM lion_browser_accounts WHERE id=?").get(String(plan.accountId));
      if (!plan2) {
        throw Error("只允许操作已绑定 LION 试用账号");
      }
      if (plan2.customer && plan.customer !== plan2.customer) {
        throw Error("LION 客户与账号归属不符");
      }
      options = {
        account: JSON.parse(plan2.account),
        customer: plan2.customer
      };
      if (arg5 === "edit") {
        let value9 = plan.selected ?? plan.channelIds;
        if (!Array.isArray(value9) || !value9.length || value9.length > 3000 || value9.some(arg6 => typeof arg6 != "string" || !/^\d+$/.test(arg6))) {
          throw Error("LION 频道参数无效");
        }
        let value10 = JSON.parse(plan2.catalog);
        if (value9.some(arg6 => !value10.some(arg7 => arg7.id === arg6))) {
          throw Error("LION 未知频道 ID");
        }
        if (plan.selected !== undefined) {
          options.selected = [...new Set(value9)];
        } else {
          if (!["add", "remove"].includes(plan.operation)) {
            throw Error("LION 频道参数无效");
          }
          options.operation = plan.operation;
          options.channelIds = [...new Set(value9)];
        }
      }
    }
    arg.prepare("INSERT INTO lion_browser_jobs VALUES(?,?,?,?,NULL,NULL,?)").run(value8, arg5, JSON.stringify(options), "queued", new Date().toISOString());
    return new Promise((arg6, fn30) => {
      let value9 = setTimeout(() => {
        map.delete(value8);
        arg.prepare("UPDATE lion_browser_jobs SET state=?,error='浏览器结果不明，禁止自动重试' WHERE id=? AND state IN ('queued','running')").run(arg5 === "recover" ? "failed" : "needs_review", value8);
        fn30(Error("LION 结果不明，需人工核查"));
      }, arg2);
      map.set(value8, {
        resolve: arg6,
        reject: fn30,
        timer: value9
      });
    });
  }
  function value7(server) {
    let job = arg.prepare("SELECT * FROM lion_browser_jobs WHERE id=?").get(server.id);
    if (!job || server.server !== "LION") {
      throw Error("LION 任务归属不符");
    }
    if (["done", "failed"].includes(job.state)) {
      return {
        received: true
      };
    }
    if (job.state !== "running") {
      throw Error("LION 过期结果需人工核查");
    }
    let plan = JSON.parse(job.args);
    let value8 = null;
    let value9 = server.error ? "LION 页面操作未完成，需检查登录、免费套餐和任务结果" + (/^lion_[a-z_]{1,80}$/.test(server.error) ? "：" + server.error : "") : null;
    if (!value9) {
      try {
        let plan2 = server.result;
        if (!le(plan2?.catalog)) {
          throw Error();
        }
        if (job.action === "prepare") {
          let value11 = plan2.summary;
          if (value11?.origin !== ke || value11.trialLabel !== ce || value11.credits !== 0 || !["", undefined].includes(value11.totalCredit) && !/^0(?:\.0+)?$/.test(value11.totalCredit) || !Number.isFinite(value11.balance) || value11.balance < 0 || !/^[\w.-]{2,80}$/.test(value11.reseller)) {
            throw Error();
          }
          let value12 = arg.prepare("SELECT owner FROM lion_browser_meta WHERE id=1").get();
          if (value12 && value12.owner !== value11.reseller) {
            throw Error();
          }
          arg.prepare("INSERT INTO lion_browser_meta VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET prepared_at=excluded.prepared_at").run(value11.reseller, new Date().toISOString());
          value8 = {
            summary: value11,
            catalog: plan2.catalog
          };
        } else {
          let account = plan2.account;
          let account2 = plan.account || plan;
          if (account?.server !== "LION" || account.id !== account.username || account.username !== account2.username || account.marker !== account2.marker || account.reseller !== account2.reseller || typeof account.password != "string" || !account.password || account.password.length > 200 || account.hours !== 12 || account.package !== "12 Hours" || typeof account.expiryLabel != "string" || !account.expiryLabel) {
            throw Error();
          }
          let url = new URL(account.playbackServer);
          if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.pathname !== "/" || ["create", "recover"].includes(job.action) && (plan2.charge?.credits !== 0 || plan2.charge?.trialLabel !== ce || !Number.isFinite(plan2.charge.before) || plan2.charge.before !== plan2.charge.after || plan2.catalog.some(plan3 => !plan3.selected)) || job.action === "recover" && (plan2.charge.before !== plan.expectedBalance || plan2.catalog.length !== plan.selected.length || plan.selected.some(arg5 => !plan2.catalog.some(arg6 => arg6.id === arg5))) || plan.account && job.action !== "recover" && ["password", "playbackServer", "expiryLabel"].some(arg5 => account[arg5] !== plan.account[arg5])) {
            throw Error();
          }
          if (job.action === "edit") {
            let value11 = JSON.parse(arg.prepare("SELECT catalog FROM lion_browser_accounts WHERE id=?").get(account.id).catalog);
            let set = new Set(plan.selected ?? plan.channelIds);
            if ([...set].some(arg5 => !value11.some(arg6 => arg6.id === arg5)) || plan2.catalog.length !== value11.length || value11.some(plan3 => {
              let plan4 = plan2.catalog.find(arg5 => arg5.id === plan3.id);
              let value12 = plan.selected ? set.has(plan3.id) : set.has(plan3.id) ? plan.operation === "add" : plan3.selected;
              return !plan4 || plan4.selected !== value12;
            })) {
              throw Error();
            }
          }
          arg.prepare("INSERT INTO lion_browser_accounts VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog").run(account.id, plan.customer || null, JSON.stringify(account), JSON.stringify(plan2.catalog));
          value8 = {
            account: account,
            catalog: plan2.catalog,
            updated: plan2.updated === true,
            refreshRequired: plan2.refreshRequired === true,
            ...(plan2.charge ? {
              charge: plan2.charge
            } : {})
          };
          if (job.action === "recover") {
            arg.prepare("UPDATE lion_browser_jobs SET state='done',result=?,error=NULL WHERE id=? AND state='needs_review'").run(JSON.stringify(value8), plan.originalRequestId);
          }
        }
      } catch {
        value9 = "LION 免费费用、账号归属或频道回读不符，需人工核查";
      }
    }
    arg.prepare("UPDATE lion_browser_jobs SET state=?,result=?,error=? WHERE id=?").run(value9 ? ["prepare", "inspect", "recover"].includes(job.action) ? "failed" : "needs_review" : "done", JSON.stringify(value8), value9, job.id);
    let value10 = map.get(job.id);
    if (value10) {
      clearTimeout(value10.timer);
      map.delete(job.id);
      if (value9) {
        value10.reject(Error(value9));
      } else {
        value10.resolve(value8);
      }
    }
    return {
      received: true
    };
  }
  return {
    status: fn29,
    next: value5,
    enqueue: value6,
    result: value7,
    close() {
      for (let value8 of map.values()) {
        clearTimeout(value8.timer);
        value8.reject(Error("bridge_closed"));
      }
      map.clear();
    }
  };
}
import { randomUUID as fn10 } from "node:crypto";
var z = new Set(["DINO", "TREX"]);
var de = (arg, arg2) => new RegExp("^IPTVBOT-" + arg + "-[A-Z0-9-]{8,90}$").test(arg2 || "");
var Ee = arg => arg && typeof arg == "object" ? Object.values(arg).flat() : [];
function pe(arg, {
  timeoutMs: arg2 = 140000,
  version: arg3 = "0.4.7",
  maxCreates: arg4 = 1,
  canExceedLimit: fn27 = () => false
} = {}) {
  arg.exec("CREATE TABLE IF NOT EXISTS classic_browser_jobs(id TEXT PRIMARY KEY,server TEXT,action TEXT,args TEXT,state TEXT,result TEXT,error TEXT);CREATE TABLE IF NOT EXISTS classic_browser_accounts(server TEXT,id TEXT,account TEXT,catalog TEXT,PRIMARY KEY(server,id));\n UPDATE classic_browser_jobs SET state=CASE WHEN action IN ('create','edit') THEN 'needs_review' ELSE 'failed' END,error='interrupted' WHERE state IN ('queued','running');\n UPDATE classic_browser_jobs SET state='failed' WHERE action IN ('prepare','inspect','recover') AND state='needs_review';\n UPDATE classic_browser_jobs SET state='needs_review' WHERE action IN ('create','edit') AND state='failed';");
  let fn28 = arg5 => ["create", "edit"].includes(arg5);
  let map = new Map();
  let map2 = new Map();
  function value4() {
    return {
      servers: [...z].map(arg5 => ({
        id: arg5,
        extensionReady: Date.now() - (map.get(arg5) || 0) < 65000
      })),
      jobs: arg.prepare("SELECT id,server,action,state,error FROM classic_browser_jobs ORDER BY rowid DESC LIMIT 12").all()
    };
  }
  function value5(arg5, arg6) {
    if (!z.has(arg5) || arg6 !== arg3) {
      return {
        job: null
      };
    }
    map.set(arg5, Date.now());
    if (arg.prepare("SELECT id FROM classic_browser_jobs WHERE server=? AND state='running'").get(arg5)) {
      return {
        job: null
      };
    }
    let value8 = arg.prepare("SELECT * FROM classic_browser_jobs WHERE server=? AND state='queued' ORDER BY rowid LIMIT 1").get(arg5);
    if (value8) {
      arg.prepare("UPDATE classic_browser_jobs SET state='running' WHERE id=?").run(value8.id);
      return {
        job: {
          id: value8.id,
          server: arg5,
          action: value8.action,
          args: JSON.parse(value8.args)
        }
      };
    } else {
      return {
        job: null
      };
    }
  }
  function value6(arg5, arg6) {
    let options = {
      ...arg6
    };
    let value8 = options.server;
    if (!z.has(value8) || !["prepare", "create", "inspect", "edit", "recover"].includes(arg5)) {
      throw Error("classic_invalid_action");
    }
    if (Date.now() - (map.get(value8) || 0) > 65000) {
      throw Error("请重载扩展并绑定 " + value8);
    }
    if (arg.prepare("SELECT id FROM classic_browser_jobs WHERE server=? AND state IN ('queued','running')").get(value8)) {
      throw Error("该服务器已有任务正在处理");
    }
    if (arg5 === "recover") {
      if (!/^[A-Za-z0-9-]{8,80}$/.test(options.requestId || "")) {
        throw Error("classic_recovery_record_required");
      }
      let value10 = arg.prepare("SELECT * FROM classic_browser_jobs WHERE id=? AND server=? AND action='create' AND state='needs_review'").get(options.requestId, value8);
      if (!value10) {
        throw Error("classic_recovery_record_required");
      }
      if (arg.prepare("SELECT id FROM classic_browser_jobs WHERE server=? AND state='needs_review' AND id<>?").get(value8, value10.id)) {
        throw Error("该服务器存在其他待核查任务");
      }
      let account = JSON.parse(value10.args);
      if (!de(value8, account.marker)) {
        throw Error("classic_recovery_binding_missing");
      }
      options = {
        server: value8,
        originalRequestId: value10.id,
        marker: account.marker
      };
    } else if (arg.prepare("SELECT id FROM classic_browser_jobs WHERE server=? AND state='needs_review'").get(value8)) {
      throw Error("该服务器已有任务待核查");
    }
    if (["inspect", "edit"].includes(arg5)) {
      if (!options.account && options.accountId) {
        let value10 = arg.prepare("SELECT account FROM classic_browser_accounts WHERE server=? AND id=?").get(value8, String(options.accountId));
        if (value10) {
          options = {
            ...options,
            account: JSON.parse(value10.account)
          };
        }
      }
      let account = options.account;
      if (!/^\d+$/.test(String(account?.id)) || account?.serverId !== value8 || !account.username || !account.password || !de(value8, account.marker)) {
        throw Error("classic_missing_binding");
      }
    }
    if (arg5 === "create") {
      if (value8 === "TREX" && options.allowAdvisoryTicketBalance !== true || !/^[-A-Za-z0-9]{8,80}$/.test(options.requestId || "")) {
        throw Error("classic_create_forbidden");
      }
      let value10 = typeof arg4 == "number" ? arg4 : arg4?.[value8];
      if (!fn27(options.requestId, value8) && (!Number.isInteger(value10) || value10 < 1 || arg.prepare("SELECT count(*) n FROM classic_browser_jobs WHERE server=? AND action='create'").get(value8).n >= value10)) {
        throw Error("classic_create_limit");
      }
      options = {
        ...options,
        marker: "IPTVBOT-" + value8 + "-" + options.requestId.toUpperCase()
      };
    }
    if (arg5 === "edit" && (!Array.isArray(options.selected) || !options.selected.length || options.selected.length > 4000 || options.selected.some(arg7 => !/^\d+$/.test(arg7)) || new Set(options.selected).size !== options.selected.length)) {
      throw Error("classic_invalid_selection");
    }
    let value9 = arg5 === "create" ? options.requestId : fn10();
    arg.prepare("INSERT INTO classic_browser_jobs VALUES(?,?,?,?,?,NULL,NULL)").run(value9, value8, arg5, JSON.stringify(options), "queued");
    return new Promise((arg7, fn32) => {
      let value10 = setTimeout(() => {
        map2.delete(value9);
        arg.prepare("UPDATE classic_browser_jobs SET state=?,error='timeout' WHERE id=? AND state IN ('queued','running')").run(fn28(arg5) ? "needs_review" : "failed", value9);
        fn32(Error(fn28(arg5) ? "classic_result_requires_review" : "classic_read_timeout"));
      }, arg2);
      map2.set(value9, {
        timer: value10,
        resolve: arg7,
        reject: fn32
      });
    });
  }
  function fn29(plan, arg5, arg6) {
    let account = plan?.account;
    return !!account && account.serverId === arg5 && account.marker === arg6 && !!/^\d+$/.test(String(account.id)) && !!account.username && !!account.password && !!account.expiryLabel && !!/^https?:\/\//.test(account.server || "") && !!plan.catalog && !!Ee(plan.catalog).length;
  }
  function fn30(arg5, account, {
    requireBalanceSnapshot: arg6
  }) {
    let account2 = arg5?.charge;
    return !!account2 && account2.credits === 0 && account2.type === "Demo" && account2.duration === "1 Day" && account2.lineType === "M3U" && account2.username === account.username && account2.reseller === account.reseller && !!Number.isFinite(account2.after) && (!arg6 || !!Number.isFinite(account2.before) && account2.before === account2.after);
  }
  function fn31(arg5, arg6, arg7) {
    let value8 = map2.get(arg5.id);
    if (value8) {
      clearTimeout(value8.timer);
      map2.delete(arg5.id);
      if (arg6) {
        value8.reject(Error(arg6));
      } else {
        value8.resolve(arg7);
      }
    }
  }
  function value7(server) {
    let server2 = arg.prepare("SELECT * FROM classic_browser_jobs WHERE id=?").get(server.id);
    if (!server2 || server2.server !== server.server) {
      throw Error("classic_wrong_server");
    }
    if (["done", "failed"].includes(server2.state)) {
      return {
        received: true
      };
    }
    if (server2.state !== "running") {
      throw Error("classic_late_result");
    }
    let account = JSON.parse(server2.args);
    let value8 = server.error ? /^classic_[a-z_]+$/.test(server.error) ? server.error : "classic_browser_operation_stopped" : null;
    let plan = server.result;
    let account2 = account.account;
    if (!value8 && ["inspect", "edit"].includes(server2.action) && (String(plan?.account?.id) !== String(account2.id) || plan.account.username !== account2.username || plan.account.password !== account2.password || plan.account.marker !== account2.marker || !plan.catalog)) {
      value8 = "classic_identity_mismatch";
    }
    if (!value8 && server2.action === "create" && (!fn29(plan, server2.server, account.marker) || !fn30(plan, plan.account, {
      requireBalanceSnapshot: true
    }))) {
      value8 = "classic_free_creation_unverified";
    }
    if (!value8 && server2.action === "recover") {
      let value10 = Ee(plan?.catalog);
      if (plan?.originalRequestId !== account.originalRequestId || plan?.recovered !== true || !fn29(plan, server2.server, account.marker) || !fn30(plan, plan.account, {
        requireBalanceSnapshot: false
      }) || value10.some(plan2 => plan2.selected !== true)) {
        value8 = "classic_recovery_unverified";
      }
    }
    if (!value8 && server2.action === "recover") {
      try {
        arg.exec("BEGIN IMMEDIATE");
        if (arg.prepare("UPDATE classic_browser_jobs SET state='done',result=?,error=NULL WHERE id=? AND server=? AND action='create' AND state='needs_review'").run(JSON.stringify(plan), account.originalRequestId, server2.server).changes !== 1) {
          throw Error("classic_recovery_original_changed");
        }
        arg.prepare("INSERT INTO classic_browser_accounts VALUES(?,?,?,?) ON CONFLICT(server,id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog").run(server2.server, plan.account.id, JSON.stringify(plan.account), JSON.stringify(plan.catalog));
        arg.prepare("UPDATE classic_browser_jobs SET state='done',result=?,error=NULL WHERE id=?").run(JSON.stringify(plan), server2.id);
        arg.exec("COMMIT");
      } catch (value10) {
        try {
          arg.exec("ROLLBACK");
        } catch {}
        value8 = /^classic_[a-z_]+$/.test(value10.message) ? value10.message : "classic_recovery_commit_failed";
      }
      if (!value8) {
        fn31(server2, null, plan);
        return {
          received: true
        };
      }
    }
    if (!value8 && server2.action !== "prepare") {
      arg.prepare("INSERT INTO classic_browser_accounts VALUES(?,?,?,?) ON CONFLICT(server,id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog").run(server2.server, plan.account.id, JSON.stringify(plan.account), JSON.stringify(plan.catalog));
    }
    let value9 = value8 ? fn28(server2.action) ? "needs_review" : "failed" : "done";
    arg.prepare("UPDATE classic_browser_jobs SET state=?,result=?,error=? WHERE id=?").run(value9, JSON.stringify(plan || null), value8, server2.id);
    fn31(server2, value8, plan);
    return {
      received: true
    };
  }
  return {
    status: value4,
    next: value5,
    enqueue: value6,
    result: value7,
    close() {
      for (let value8 of map2.values()) {
        clearTimeout(value8.timer);
        value8.reject(Error("closed"));
      }
      map2.clear();
    }
  };
}
import { randomUUID as fn11 } from "node:crypto";
var Ge = ["en", "zh", "es", "fr", "de", "pt", "it", "sv", "ar"];
var We = [["italy", "IT", "it", ["ITALY", "ITALIA", "ITALIAN"]], ["sweden", "SE", "sv", ["SWEDEN", "SWEDISH"]], ["germany", "DE", "de", ["GERMANY", "GERMAN", "DEUTSCH", "ALMANIA", "ألمانية", "ألمانيه"]], ["france", "FR", "fr", ["FRANCE", "FRENCH", "FR", "FRANCAIS", "FRANÇAISE", "فرنسية"]], ["spain", "ES", "es", ["SPAIN", "SPANISH", "ES", "ESPANA", "ESPAÑA"]], ["united-kingdom", "GB", null, ["UK", "UNITED KINGDOM", "BRITISH"]], ["united-states", "US", null, ["USA", "UNITED STATES", "AMERICAN"]], ["canada", "CA", null, ["CANADA", "CANADIAN", "QUEBEC"]], ["portugal", "PT", "pt", ["PORTUGAL", "PORTUGUESE"]], ["netherlands", "NL", "nl", ["NETHERLAND", "NETHERLANDS", "DUTCH"]], ["belgium", "BE", null, ["BELGIUM", "BELGIAN"]], ["austria", "AT", null, ["AUSTRIA", "AUSTRIAN"]], ["switzerland", "CH", null, ["SWISS", "SWITZERLAND"]], ["poland", "PL", "pl", ["POLAND", "POLISH", "POLONIA", "POLSKIE", "PL"]], ["greece", "GR", "el", ["GREECE", "GREEK", "GR"]], ["cyprus", "CY", null, ["CYPRUS"]], ["latvia", "LV", null, ["LATVIA"]], ["denmark", "DK", "da", ["DENMARK", "DANMARK", "DANISH"]], ["norway", "NO", "no", ["NORWAY", "NORWEGIAN"]], ["finland", "FI", "fi", ["FINLAND", "FINNISH"]], ["iceland", "IS", null, ["ICELAND", "ICELANDIC"]], ["hungary", "HU", "hu", ["HUNGARY", "HUNGARIA", "HUNGARIAN"]], ["romania", "RO", "ro", ["ROMANIA", "ROMANIAN"]], ["albania", "AL", "sq", ["ALBANIA", "ALBANIAN"]], ["kosovo", "XK", null, ["KOSOVO"]], ["russia", "RU", "ru", ["RUSSIA", "RUSSIAN", "روسيه"]], ["ukraine", "UA", "uk", ["UKRAINE", "UKRAINIAN"]], ["israel", "IL", "he", ["ISRAEL", "HEBREW"]], ["australia", "AU", null, ["AUSTRALIA", "AUSTRALIAN"]], ["new-zealand", "NZ", null, ["NEW ZEALAND"]], ["lithuania", "LT", "lt", ["LITHUANIA", "LITHUANIAN"]], ["estonia", "EE", "et", ["ESTONIA", "ESTONIAN"]], ["slovenia", "SI", "sl", ["SLOVENIA", "SLOVENIAN"]], ["czechia", "CZ", "cs", ["CZECH", "CZECHIA"]], ["bulgaria", "BG", "bg", ["BULGARIA", "BULGARY", "BULGARIAN"]], ["armenia", "AM", "hy", ["ARMENIA", "ARMENIAN"]], ["georgia", "GE", "ka", ["GEORGIA", "GEORGIE", "GEORGIAN"]], ["malta", "MT", null, ["MALTA", "MALTESE"]], ["turkey", "TR", "tr", ["TURKEY", "TURKISH", "TURK", "تركية"]], ["india", "IN", "hi", ["INDIA", "INDIAN", "BOLLYWOOD", "هندية", "هندي"]], ["pakistan", "PK", "ur", ["PAKISTAN", "PAKISTANI"]], ["iran", "IR", "fa", ["IRAN", "IRANIAN"]], ["iraq", "IQ", null, ["IRAQ", "IRAQI", "عراقية", "عراقي"]], ["azerbaijan", "AZ", "az", ["AZERBAIJAN", "AZERBAIJANI", "AZERBAYCAN", "AZERBAJAN"]], ["kazakhstan", "KZ", "kk", ["KAZAKHSTAN", "KAZACHSTAN"]], ["afghanistan", "AF", null, ["AFGHANISTAN", "AFGHAN"]], ["philippines", "PH", "fil", ["PHILIPPINES", "PHILIPPINE", "PHILIPINES", "PHILIPINNES"]], ["china", "CN", "zh", ["CHINA", "CHINESE", "صيني"]], ["japan", "JP", "ja", ["JAPAN", "JAPANESE"]], ["south-korea", "KR", "ko", ["SOUTH KOREA", "SOUTHKOREA", "KOREA", "KOREAN"]], ["thailand", "TH", "th", ["THAILAND", "THAILLAND", "THAILANDE", "THAI"]], ["vietnam", "VN", "vi", ["VIETNAM", "VIETNAMESE"]], ["indonesia", "ID", "id", ["INDONESIA", "INDONESIAN"]], ["malaysia", "MY", "ms", ["MALAYSIA", "MALAYSIAN"]], ["singapore", "SG", null, ["SINGAPORE"]], ["bangladesh", "BD", "bn", ["BANGLADESH", "BENGALI"]], ["sri-lanka", "LK", null, ["SRI LANKA"]], ["somalia", "SO", "so", ["SOMALIA", "SOMALI"]], ["brazil", "BR", null, ["BRAZIL", "BRASIL"]], ["argentina", "AR", null, ["ARGENTINA"]], ["mexico", "MX", null, ["MEXICO"]], ["chile", "CL", null, ["CHILE"]], ["colombia", "CO", null, ["COLOMBIA"]], ["uruguay", "UY", null, ["URUGUAY"]], ["paraguay", "PY", null, ["PARAGUAY"]], ["peru", "PE", null, ["PERU"]], ["ecuador", "EC", null, ["ECUADOR"]], ["venezuela", "VE", null, ["VENEZUELA"]], ["panama", "PA", null, ["PANAMA"]], ["bolivia", "BO", null, ["BOLIVIA"]], ["costa-rica", "CR", null, ["COSTA RICA"]], ["dominican-republic", "DO", null, ["DOMINICAN"]], ["puerto-rico", "PR", null, ["PUERTO RICO"]], ["el-salvador", "SV", null, ["EL SALVADOR"]], ["guatemala", "GT", null, ["GUATEMALA"]], ["nicaragua", "NI", null, ["NICARAGUA"]], ["honduras", "HN", null, ["HONDURAS"]], ["cuba", "CU", null, ["CUBA"]], ["haiti", "HT", null, ["HAITI"]], ["jamaica", "JM", null, ["JAMAICA"]], ["morocco", "MA", null, ["MOROCCO", "MOROCCAN", "MAGHREB", "مغربية", "مغربي"]], ["algeria", "DZ", null, ["ALGERIA", "ALGERIE", "ALGERIAN", "جزائرية", "جزائري"]], ["tunisia", "TN", null, ["TUNISIA", "TUNIS", "TUNISIAN", "تونسية", "تونسي"]], ["egypt", "EG", null, ["EGYPT", "EGYPTE", "MASR", "مصرية", "مصريه", "مصري"]], ["libya", "LY", null, ["LIBYA", "LIBYAN", "ليبيا", "ليبي"]], ["sudan", "SD", null, ["SUDAN", "SUDANESE"]], ["lebanon", "LB", null, ["LEBANON", "LEBANESE", "لبناني", "لبنانية"]], ["syria", "SY", null, ["SYRIA", "SYRIAN", "سورية", "سوري"]], ["jordan", "JO", null, ["JORDAN", "JORDANIAN", "أردني"]], ["palestine", "PS", null, ["PALESTINE", "PALESTINIAN", "فلسطيني"]], ["saudi-arabia", "SA", null, ["SAUDI", "SAUDI ARABIA"]], ["united-arab-emirates", "AE", null, ["UAE", "EMIRATES"]], ["qatar", "QA", null, ["QATAR"]], ["kuwait", "KW", null, ["KUWAIT"]], ["bahrain", "BH", null, ["BAHRAIN"]], ["oman", "OM", null, ["OMAN"]], ["yemen", "YE", null, ["YEMEN", "YEMENI", "يمنية", "يمني"]], ["ireland", "IE", null, ["IRELAND", "IRISH"]], ["slovakia", "SK", "sk", ["SLOVAKIA", "SLOVAK"]], ["serbia", "RS", "sr", ["SERBIA", "SRBIJA"]], ["bosnia", "BA", "bs", ["BOSNIA"]], ["croatia", "HR", "hr", ["CROATIA"]], ["north-macedonia", "MK", "mk", ["MACEDONIA", "NORTH MACEDONIA"]], ["montenegro", "ME", null, ["MONTENEGRO"]], ["mauritania", "MR", "ar", ["MAURITANIA"]], ["cameroon", "CM", null, ["CAMEROON", "CAMEROONIAN"]], ["ghana", "GH", null, ["GHANA"]], ["ethiopia", "ET", null, ["ETHIOPIA"]], ["kenya", "KE", null, ["KENYA"]], ["congo", "CG", null, ["CONGO"]], ["senegal", "SN", null, ["SENEGAL"]], ["nigeria", "NG", null, ["NIGERIA"]], ["uganda", "UG", null, ["UGANDA"]], ["suriname", "SR", null, ["SURINAME"]], ["taiwan", "TW", null, ["TAIWAN"]], ["cambodia", "KH", null, ["CAMBODIA"]], ["hong-kong", "HK", null, ["HONG KONG", "HONGKONG"]], ["saint-lucia", "LC", null, ["SAINT LUCIA"]], ["uzbekistan", "UZ", "uz", ["UZBEKISTAN"]], ["tajikistan", "TJ", "tg", ["TAJIKISTAN"]], ["myanmar", "MM", null, ["MYANMAR"]], ["arabic", null, "ar", ["ARABIC", "ARABE", "ARAB"]], ["africa", null, null, ["AFRICA", "AFRICAN", "AFRIQUE"]], ["latin-america", null, null, ["LATINO", "LATIN AMERICA"]], ["scandinavia", null, null, ["SCANDINAVIA", "SCANDINAVIAN", "SCANDINAVE", "NORDIC"]], ["ex-yugoslavia", null, null, ["EXYU", "EX YU"]], ["caribbean", null, null, ["CARIBBEAN", "CARRIBEAN"]], ["kurdish", null, null, ["KURDISH", "KURD", "KURDISTAN"]], ["asia", null, null, ["ASIA", "ASIAN", "ASIATIC"]]];
var F = arg => String(arg || "").normalize("NFKD").replace(new RegExp("\\p{M}", "gu"), "").toUpperCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
var Fe = (arg, arg2) => (" " + arg + " ").includes(" " + arg2 + " ");
var Be = /体育|運動|直播|频道|頻道|电视|電視|(?:sports?|sportifs?|deportes?|esportes?|sportivi|sportkanaler|live|direct|diretta|direto|en\s+vivo|ao\s+vivo|channels?|canales?|chaines?|sender|kanaler|canali|canais|tv)|(?:القنوات|قنوات|القناة|قناة|رياضة|رياضية|مباشر)/giu;
var xe = /体育|運動|sports?|sportifs?|deportes?|esportes?|sportivi|sportkanaler|رياضة|رياضية/iu;
var Je = /直播|live|direct|diretta|direto|en\s+vivo|ao\s+vivo|مباشر/iu;
function ge(arg, arg2, arg3) {
  try {
    return new Intl.DisplayNames([arg3], {
      type: arg,
      fallback: "none"
    }).of(arg2) || "";
  } catch {
    return "";
  }
}
var Xe = We.map(([arg, arg2, arg3, arg4]) => {
  let set = new Set([arg.replaceAll("-", " "), ...arg4]);
  for (let value4 of Ge) {
    if (arg2) {
      set.add(ge("region", arg2, value4));
    }
    if (arg3) {
      set.add(ge("language", arg3, value4));
    }
  }
  return {
    id: arg,
    labelTerms: [...new Set(arg4.map(F).filter(Boolean))],
    aliases: [...new Set([...set].map(F).filter(Boolean))]
  };
});
function Ye(arg, arg2) {
  if (arg === arg2) {
    return true;
  } else if (arg.includes(" ") || arg2.includes(" ") || arg2.length < 4) {
    return false;
  } else {
    return (arg.startsWith(arg2) || arg2.startsWith(arg)) && Math.abs(arg.length - arg2.length) <= 6;
  }
}
function Ke(arg) {
  let text = String(arg || "");
  let value4 = xe.test(text);
  let value5 = value4 || Je.test(text);
  let value6 = F(text.replace(Be, " ").replace(/\b(?:THE|LES|DIE|DER|DAS|LOS|LAS|OS|AS|I|LE|LA|DE|DEL|DES|DI|DA|DO|DAS)\b/giu, " ").replace(/[的]+/gu, " "));
  if (!value6) {
    return null;
  }
  let value7 = Xe.filter(arg2 => arg2.aliases.some(arg3 => Ye(value6, arg3)));
  if (value7.length !== 1) {
    return null;
  } else {
    return {
      definition: value7[0],
      scope: value5 ? "live" : "all",
      sports: value4
    };
  }
}
function $e(arg, arg2) {
  let value4 = F(arg);
  return arg2.labelTerms.some(arg3 => Fe(value4, arg3));
}
function me(arg, arg2) {
  let value4 = Ke(arg2);
  if (!value4) {
    return null;
  }
  let value5 = value4.scope === "live" ? ["live"] : ["live", "movies", "series"];
  let options = {
    live: [],
    movies: [],
    series: []
  };
  for (let value7 of value5) {
    options[value7] = (arg?.[value7] || []).filter(arg3 => $e(arg3.label, value4.definition) && (!value4.sports || /SPORT|DEPORT|رياض/iu.test(F(arg3.label))));
  }
  let value6 = Object.values(options).reduce((arg3, arg4) => arg3 + arg4.length, 0);
  if (value6) {
    return {
      id: value4.definition.id,
      scope: value4.scope,
      sports: value4.sports,
      matches: options,
      count: value6
    };
  } else {
    return null;
  }
}
var qe = {
  live: /^(直播|直播频道|频道|live|live channels)$/iu,
  movies: /^(电影|电影包|movies|films)$/iu,
  series: /^(电视剧|剧集|series)$/iu
};
function Z(arg, arg2) {
  let list = ["live", "movies", "series"];
  let value4 = Object.fromEntries(list.map(arg3 => [arg3, new Set(arg[arg3].filter(plan => plan.selected).map(arg4 => arg4.id))]));
  let set = new Set();
  let list2 = [];
  for (let {
    op: value5,
    target: value6
  } of arg2) {
    if (!["add", "remove", "only"].includes(value5)) {
      throw Error("invalid_operation");
    }
    let value7 = list.find(arg3 => qe[arg3].test(value6));
    let list3 = [];
    if (value7) {
      list3 = arg[value7];
      if (value5 === "only") {
        throw Error("请说明只保留哪个国家或具体分类；例如“只要德国直播”。");
      }
    } else {
      let value8 = me(arg, value6);
      if (value8) {
        if (value5 === "only") {
          for (let value9 of value8.scope === "live" ? ["live"] : list) {
            value4[value9].clear();
            for (let value10 of value8.matches[value9]) {
              value4[value9].add(value10.id);
            }
            set.add(value9);
          }
        } else {
          for (let value9 of list) {
            if (value8.matches[value9].length) {
              for (let value10 of value8.matches[value9]) {
                if (value5 === "remove") {
                  value4[value9].delete(value10.id);
                } else {
                  value4[value9].add(value10.id);
                }
              }
              set.add(value9);
            }
          }
        }
        list2.push((value5 === "add" ? "添加" : value5 === "remove" ? "移除" : "仅保留") + " " + value6 + "（" + value8.count + " 个国家模组分类）");
        continue;
      } else {
        let value9 = value6.toUpperCase().replace(/\s+/g, "");
        for (let value10 of list) {
          let value11 = arg[value10].filter(arg3 => arg3.label.toUpperCase().replace(/\s+/g, "") === value9 || arg3.label.split("|").at(-1).trim().toUpperCase().replace(/\s+/g, "") === value9);
          if (value11.length) {
            if (value7) {
              throw Error("该名称对应多种内容，请提供完整分类名称。");
            }
            value7 = value10;
            list3 = value11;
          }
        }
      }
    }
    if (!value7 || !list3.length) {
      throw Error("未找到明确分类：" + value6 + "。请提供后台完整分类名称；单个电视频道不一定可单独选择。");
    }
    if (!list.includes(value7)) {
      throw Error("invalid_scope");
    }
    if (value5 === "only") {
      value4[value7].clear();
    }
    for (let value8 of list3) {
      if (value5 === "remove") {
        value4[value7].delete(value8.id);
      } else {
        value4[value7].add(value8.id);
      }
    }
    set.add(value7);
    list2.push((value5 === "add" ? "添加" : value5 === "remove" ? "移除" : "仅保留") + " " + value6 + "（" + list3.length + " 个分类）");
  }
  if (list.every(arg3 => value4[arg3].size === 0)) {
    throw Error("不能生成没有任何内容的账号。");
  }
  return {
    selected: Object.fromEntries(list.map(arg3 => [arg3, [...value4[arg3]]])),
    changed: [...set],
    descriptions: list2
  };
}
var fe = "0.4.12";
var ze = arg => /^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(String(arg || "").toUpperCase());
var H = arg => arg && ["live", "movies", "series"].every(arg2 => Array.isArray(arg[arg2]) && arg[arg2].length > 0 && arg[arg2].length <= 5000 && arg[arg2].every(plan => typeof plan.id == "string" && plan.id && plan.id.length <= 100 && typeof plan.label == "string" && plan.label && plan.label.length <= 300 && typeof plan.selected == "boolean") && new Set(arg[arg2].map(arg3 => arg3.id)).size === arg[arg2].length);
function P(arg) {
  return arg?.credits === 0 && arg.trialLabel === "24 Hours - 0 Credits" && Number.isInteger(arg.remaining) && arg.remaining >= 0 && Number.isFinite(arg.balance) && arg.balance >= 0;
}
function Ae(arg) {
  try {
    let url = new URL(arg);
    return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password && !!url.hostname;
  } catch {
    return false;
  }
}
var Ze = arg => Object.fromEntries(["live", "movies", "series"].map(arg2 => [arg2, arg[arg2].filter(plan => plan.selected).map(arg3 => arg3.id).sort()]));
var Te = (arg, plan) => JSON.stringify(Ze(arg)) === JSON.stringify(Object.fromEntries(["live", "movies", "series"].map(arg2 => [arg2, [...plan.selected[arg2]].sort()])));
function Ne(arg, {
  timeoutMs: arg2 = 140000,
  canExceedLimit: fn27 = () => false,
  getConfig: fn28 = () => ({
    mutationsEnabled: false,
    maxMacCreates: 1
  })
} = {}) {
  arg.exec("CREATE TABLE IF NOT EXISTS mega_mag_jobs(id TEXT PRIMARY KEY,action TEXT,args TEXT,state TEXT,result TEXT,error TEXT,created_at TEXT);\n CREATE TABLE IF NOT EXISTS mega_mag_accounts(id TEXT PRIMARY KEY,account TEXT NOT NULL,catalog TEXT NOT NULL,source TEXT NOT NULL);\n UPDATE mega_mag_jobs SET state=CASE WHEN action IN ('prepare','inspect','recover') THEN 'failed' ELSE 'needs_review' END,error='服务重启，写操作禁止自动重试' WHERE state IN ('queued','running');");
  let map = new Map();
  let value4 = 0;
  let fn29 = () => Date.now() - value4 < 65000;
  function fn30() {
    let value8 = fn28();
    return {
      server: "MEGA",
      mode: "browser-mag",
      version: fe,
      extensionReady: fn29(),
      mutationsEnabled: value8.mutationsEnabled === true,
      createRemaining: Math.max(0, (Number.isInteger(value8.maxMacCreates) ? value8.maxMacCreates : 1) - arg.prepare("SELECT count(*) n FROM mega_mag_jobs WHERE action='create'").get().n),
      accounts: arg.prepare("SELECT id,account,source FROM mega_mag_accounts").all().map(arg3 => {
        let account = JSON.parse(arg3.account);
        return {
          id: arg3.id,
          macAddress: account.macAddress,
          expiryLabel: account.expiryLabel,
          source: arg3.source
        };
      }),
      jobs: arg.prepare("SELECT id,action,state,error,created_at FROM mega_mag_jobs ORDER BY rowid DESC LIMIT 10").all()
    };
  }
  function value5(arg3) {
    if (arg3 !== fe) {
      return {
        job: null
      };
    }
    value4 = Date.now();
    if (arg.prepare("SELECT id FROM mega_mag_jobs WHERE state='running'").get()) {
      return {
        job: null
      };
    }
    let value8 = arg.prepare("SELECT * FROM mega_mag_jobs WHERE state='queued' ORDER BY rowid LIMIT 1").get();
    if (value8) {
      arg.prepare("UPDATE mega_mag_jobs SET state='running' WHERE id=?").run(value8.id);
      return {
        job: {
          id: value8.id,
          server: "MEGA",
          action: value8.action,
          args: JSON.parse(value8.args)
        }
      };
    } else {
      return {
        job: null
      };
    }
  }
  function value6(arg3, account = {}) {
    if (!["prepare", "create", "inspect", "edit", "recover"].includes(arg3)) {
      throw Error("MAG 操作不支持");
    }
    if (!fn29()) {
      throw Error("请重载扩展至 0.4.12 并保持 MEGA 标签已绑定");
    }
    if (arg.prepare("SELECT id FROM mega_mag_jobs WHERE state IN ('queued','running')").get()) {
      throw Error("已有 MAG 任务待处理，禁止重复操作");
    }
    if (arg3 !== "recover" && arg.prepare("SELECT id FROM mega_mag_jobs WHERE state='needs_review'").get()) {
      throw Error("已有 MAG 写操作待核查，禁止重复操作");
    }
    let value8 = String(account.macAddress || account.account?.macAddress || "").toUpperCase();
    if (!ze(value8)) {
      throw Error("MAC 地址格式无效");
    }
    let value9 = fn11();
    let options = {
      macAddress: value8
    };
    if (arg3 === "create") {
      if (fn28().mutationsEnabled !== true) {
        throw Error("MAG 网页开户仍处于禁用状态");
      }
      if (fn30().createRemaining < 1 && !fn27(account.requestId, "MEGA")) {
        throw Error("本轮 MAG 网页开户数量上限已达到");
      }
      if (!/^[A-Za-z0-9-]{8,80}$/.test(account.requestId || "")) {
        throw Error("MAG 请求编号无效");
      }
      value9 = account.requestId;
      if (arg.prepare("SELECT id FROM mega_mag_jobs WHERE id=?").get(value9)) {
        throw Error("该 MAG 开户请求已有记录");
      }
      options = {
        macAddress: value8,
        requestId: value9,
        marker: "IPTVBOT-MAC-" + value9.toUpperCase(),
        operations: Array.isArray(account.operations) ? account.operations : []
      };
    } else if (arg3 === "edit") {
      let account2 = account.account;
      if (fn28().mutationsEnabled !== true) {
        throw Error("MAG 网页编辑仍处于禁用状态");
      }
      if (!account2 || !/^[0-9]+$/.test(String(account2.id || "")) || account2.macAddress !== value8 || typeof account2.marker != "string" || !account2.marker.startsWith("IPTVBOT-MAC-")) {
        throw Error("MAG 账号绑定无效");
      }
      let value10 = arg.prepare("SELECT account FROM mega_mag_accounts WHERE id=?").get(String(account2.id));
      if (!value10) {
        throw Error("仅允许编辑已绑定的 MAG 测试账号");
      }
      let account3 = JSON.parse(value10.account);
      if (account3.macAddress !== value8 || account3.marker !== account2.marker) {
        throw Error("MAG 账号归属不符");
      }
      options = {
        account: account3,
        operations: Array.isArray(account.operations) ? account.operations : []
      };
    } else if (arg3 === "inspect") {
      if (!/^[0-9]+$/.test(String(account.id || ""))) {
        throw Error("MAG 账号 ID 无效");
      }
      options = {
        id: String(account.id),
        macAddress: value8,
        ...(typeof account.marker == "string" ? {
          marker: account.marker
        } : {})
      };
    } else if (arg3 === "recover") {
      if (!/^[A-Za-z0-9-]{8,80}$/.test(account.requestId || "")) {
        throw Error("MAG 核查请求编号无效");
      }
      let value10 = arg.prepare("SELECT * FROM mega_mag_jobs WHERE id=? AND action='create' AND state='needs_review'").get(account.requestId);
      if (!value10) {
        throw Error("仅允许只读核查原先结果不明的开户任务");
      }
      let account2 = JSON.parse(value10.args);
      if (account2.macAddress !== value8 || typeof account2.marker != "string") {
        throw Error("MAG 原始开户绑定不符");
      }
      let job = arg.prepare("SELECT * FROM mega_mag_jobs WHERE action='prepare' AND state='done' AND created_at<=? ORDER BY rowid DESC").all(value10.created_at).find(job2 => {
        try {
          return JSON.parse(job2.args).macAddress === value8 && P(JSON.parse(job2.result).summary);
        } catch {
          return false;
        }
      });
      if (!job) {
        throw Error("MAG 原始免费预检证据缺失");
      }
      options = {
        originalRequestId: value10.id,
        macAddress: value8,
        marker: account2.marker,
        expectedBefore: JSON.parse(job.result).summary
      };
    }
    arg.prepare("INSERT INTO mega_mag_jobs VALUES(?,?,?,?,NULL,NULL,?)").run(value9, arg3, JSON.stringify(options), "queued", new Date().toISOString());
    return new Promise((arg4, fn32) => {
      let value10 = setTimeout(() => {
        map.delete(value9);
        arg.prepare("UPDATE mega_mag_jobs SET state=?,error='结果不明，禁止自动重试' WHERE id=? AND state IN ('queued','running')").run(["prepare", "inspect", "recover"].includes(arg3) ? "failed" : "needs_review", value9);
        fn32(Error("MAG 浏览器结果不明，已阻止自动重试"));
      }, arg2);
      map.set(value9, {
        resolve: arg4,
        reject: fn32,
        timer: value10
      });
    });
  }
  function fn31(arg3, arg4, arg5) {
    let value8 = arg5 ? ["prepare", "inspect", "recover"].includes(arg3.action) ? "failed" : "needs_review" : "done";
    arg.prepare("UPDATE mega_mag_jobs SET state=?,result=?,error=? WHERE id=?").run(value8, JSON.stringify(arg4 || null), arg5 || null, arg3.id);
    let value9 = map.get(arg3.id);
    if (value9) {
      clearTimeout(value9.timer);
      map.delete(arg3.id);
      if (arg5) {
        value9.reject(Error(arg5));
      } else {
        value9.resolve(arg4);
      }
    }
  }
  function value7(server) {
    let job = arg.prepare("SELECT * FROM mega_mag_jobs WHERE id=?").get(server.id);
    if (!job || server.server !== "MEGA") {
      throw Error("MAG 任务归属不符");
    }
    if (["done", "failed"].includes(job.state)) {
      return {
        received: true
      };
    }
    if (job.state !== "running") {
      throw Error("MAG 过期结果需人工核查");
    }
    let value8 = null;
    let value9 = server.error ? /^mega_mag_[a-z_]{1,100}$/.test(server.error) ? server.error : "MAG 操作未完成，需核查后台；禁止自动重试" : null;
    let account = JSON.parse(job.args);
    try {
      if (!value9) {
        let plan = server.result;
        if (job.action === "prepare") {
          if (plan?.exists !== false || !P(plan.summary) || plan.summary.remaining < 1 || !H(plan.catalog)) {
            throw Error("MAG 免费预检或频道目录核验失败");
          }
          value8 = plan;
        } else if (job.action === "create") {
          let account2 = plan?.account;
          if (!account2 || !/^[0-9]+$/.test(String(account2.id)) || account2.serverId !== "MEGA" || account2.macAddress !== account.macAddress || account2.marker !== account.marker || !Ae(account2.portalUrl) || typeof account2.expiryLabel != "string" || !account2.expiryLabel.trim() || account2.expiryLabel.length > 100 || !P(plan.before) || !P(plan.after) || plan.before.balance !== plan.after.balance || plan.after.remaining !== plan.before.remaining - 1 || plan.verified !== true || !H(plan.catalog)) {
            throw Error("MAG 账号、免费名额、积分或 Portal 回读不符");
          }
          if (!H(plan.baseCatalog) || !Te(plan.catalog, Z(plan.baseCatalog, account.operations))) {
            throw Error("MAG 创建频道回读不符");
          }
          value8 = {
            account: account2,
            catalog: plan.catalog
          };
          arg.prepare("INSERT INTO mega_mag_accounts VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog,source=excluded.source").run(String(account2.id), JSON.stringify(account2), JSON.stringify(plan.catalog), "extension-verified");
        } else if (job.action === "inspect") {
          if (!plan || String(plan.id) !== account.id || plan.macAddress !== account.macAddress || typeof plan.marker != "string" || account.marker && plan.marker !== account.marker || !H(plan.catalog)) {
            throw Error("MAG 账号或频道回读不符");
          }
          value8 = {
            id: plan.id,
            macAddress: plan.macAddress,
            note: plan.marker,
            catalog: plan.catalog
          };
        } else if (job.action === "recover") {
          let value10 = arg.prepare("SELECT * FROM mega_mag_jobs WHERE id=? AND action='create' AND state='needs_review'").get(account.originalRequestId);
          let account2 = plan?.account;
          if (!value10 || !account2 || !/^[0-9]+$/.test(String(account2.id)) || account2.serverId !== "MEGA" || account2.macAddress !== account.macAddress || account2.marker !== account.marker || !Ae(account2.portalUrl) || typeof account2.expiryLabel != "string" || !account2.expiryLabel.trim() || !H(plan.catalog) || !P(account.expectedBefore) || !P(plan.after) || plan.after.balance !== account.expectedBefore.balance || plan.after.remaining !== account.expectedBefore.remaining - 1 || plan.verified !== true) {
            throw Error("MAG 只读核查未能确认唯一免费账号");
          }
          value8 = {
            account: account2,
            catalog: plan.catalog
          };
          arg.prepare("INSERT INTO mega_mag_accounts VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET account=excluded.account,catalog=excluded.catalog,source=excluded.source").run(String(account2.id), JSON.stringify(account2), JSON.stringify(plan.catalog), "extension-recovered");
          arg.prepare("UPDATE mega_mag_jobs SET state='done',result=?,error=NULL WHERE id=? AND state='needs_review'").run(JSON.stringify(value8), account.originalRequestId);
        } else {
          let plan2 = arg.prepare("SELECT catalog FROM mega_mag_accounts WHERE id=?").get(account.account.id);
          let value10 = plan2 && JSON.parse(plan2.catalog);
          let plan3 = value10 && Z(value10, account.operations);
          if (plan?.updated !== true || plan.refreshRequired !== true || plan.id !== account.account.id || plan.macAddress !== account.account.macAddress || plan.marker !== account.account.marker || !H(plan.catalog) || !H(value10) || !Te(plan.catalog, plan3)) {
            throw Error("MAG 频道保存回读不符");
          }
          value8 = {
            updated: true,
            refreshRequired: true,
            descriptions: plan3.descriptions
          };
          arg.prepare("UPDATE mega_mag_accounts SET catalog=? WHERE id=?").run(JSON.stringify(plan.catalog), account.account.id);
        }
      }
    } catch {
      value9 = job.action === "create" ? "MAG 账号、免费名额、积分或 Portal 回读不符，需人工核查" : job.action === "recover" ? "MAG 只读核查失败，原开户仍需人工核查" : "MAG 页面回读不符";
    }
    fn31(job, value8, value9);
    return {
      received: true
    };
  }
  return {
    status: fn30,
    next: value5,
    enqueue: value6,
    result: value7,
    close() {
      for (let value8 of map.values()) {
        clearTimeout(value8.timer);
        value8.reject(Error("bridge_closed"));
      }
      map.clear();
    }
  };
}
import value2 from "node:http";
import { DatabaseSync as value3 } from "node:sqlite";
import { randomBytes as fn12, randomUUID as fn13, createHash as fn14, timingSafeEqual as fn15 } from "node:crypto";
import { readFileSync as fn16, writeFileSync as fn17, existsSync as fn18, mkdirSync as fn19 } from "node:fs";
import { join as fn20 } from "node:path";
import { fileURLToPath as fn21 } from "node:url";
import { readFileSync as fn22, writeFileSync as fn23, existsSync as fn24 } from "node:fs";
import { join as fn25 } from "node:path";
import { randomBytes as fn26 } from "node:crypto";
function er(arg) {
  if (arg?.status === false) {
    throw Error("MegaOTT 拒绝请求：" + String(arg.message || "unknown"));
  }
  return arg;
}
function Re(arg, arg2 = Date.now()) {
  if (!arg || arg.packageId !== 1 || arg.templateId !== 4779 || arg.label !== "24 Hours - 0 Credits" || arg.credit !== 0 || !Number.isInteger(arg.remaining) || arg.remaining < 1 || !Number.isFinite(arg.observedAt) || arg2 - arg.observedAt < 0 || arg2 - arg.observedAt > 120000) {
    throw Error("缺少两分钟内的零积分套餐和免费额度核验，已停止开户");
  }
}
function we(arg, fn27 = fetch) {
  async function fn28(arg2, arg3) {
    let value4 = fn25(arg, "panel-api-config.json");
    let value5 = fn25(arg, "megaott-api-token");
    let value6 = (fn24(value4) ? JSON.parse(fn22(value4, "utf8")).MEGA?.key : null) || (fn24(value5) ? fn22(value5, "utf8").trim() : "");
    if (!value6) {
      throw Error("MEGA_API_KEY_REQUIRED");
    }
    let result = await fn27("https://megaott.net/api/v1/" + arg2, {
      method: arg3 ? "POST" : "GET",
      headers: {
        Accept: "application/json",
        Authorization: "Bearer " + value6,
        ...(arg3 ? {
          "Content-Type": "application/x-www-form-urlencoded"
        } : {})
      },
      ...(arg3 ? {
        body: new URLSearchParams(arg3)
      } : {}),
      redirect: "error",
      signal: AbortSignal.timeout(30000)
    });
    if (!result.ok) {
      let result2 = await result.json().catch(() => ({}));
      fn23(fn25(arg, "api-last-error.json"), JSON.stringify({
        status: result.status,
        errors: result2.errors,
        message: result2.message
      }, null, 2));
      throw Error("MegaOTT API HTTP " + result.status + "; validation fields: " + Object.keys(result2.errors || {}).join(", "));
    }
    if (!(result.headers.get("content-type") || "").includes("application/json")) {
      throw Error("MegaOTT API returned non-JSON");
    }
    return result.json();
  }
  return {
    user: () => fn28("user"),
    read: arg2 => {
      if (!/^\d+$/.test(String(arg2))) {
        throw Error("invalid_id");
      }
      return fn28("subscriptions/" + arg2);
    },
    async createFreeTest(arg2) {
      if (!q.apiCreateEnabled) {
        throw Error("API 开户尚未启用，需先完成零积分试用验收");
      }
      Re(arg2);
      let value4 = fn25(arg, "api-free-test.json");
      if (fn24(value4)) {
        throw Error("API 测试已有提交记录，禁止重复开户");
      }
      let result = await fn28("user");
      if (typeof result.username != "string" || !result.username.trim() || !Number.isFinite(Number(result.credit))) {
        throw Error("account_mismatch");
      }
      Re(arg2);
      let value5 = fn26(8).toString("hex").toUpperCase();
      let text = "IPTVBOT-API-" + value5;
      fn23(value4, JSON.stringify({
        status: "submitting",
        marker: text,
        creditBefore: result.credit
      }), {
        flag: "wx"
      });
      let result2 = await fn28("subscriptions", {
        type: "M3U",
        username: "T" + value5.slice(0, 10),
        package_id: "1",
        template_id: "4779",
        max_connections: "1",
        forced_country: "ALL",
        adult: "0",
        note: text,
        whatsapp_telegram: "",
        enable_vpn: "0",
        paid: "0"
      });
      fn23(value4, JSON.stringify({
        status: "created_pending_verification",
        marker: text,
        creditBefore: result.credit,
        account: result2
      }));
      if (result2.status === false) {
        fn23(value4, JSON.stringify({
          status: "rejected",
          marker: text,
          creditBefore: result.credit,
          response: result2
        }));
        er(result2);
      }
      if (!result2.id) {
        throw Error("incomplete_create_response");
      }
      let result3 = await fn28("subscriptions/" + result2.id);
      let result4 = await fn28("user");
      let value6 = result3.note === text && result3.package?.id === 1 && result3.template?.id === 4779 && Number(result4.credit) === Number(result.credit);
      fn23(value4, JSON.stringify({
        status: value6 ? "verified" : "needs_review",
        marker: text,
        creditBefore: result.credit,
        creditAfter: result4.credit,
        account: result3
      }, null, 2));
      if (!value6) {
        throw Error("开户核验不一致，已停止后续开户");
      }
      return {
        id: result3.id,
        package: result3.package,
        template: result3.template,
        creditBefore: result.credit,
        creditAfter: result4.credit
      };
    }
  };
}
function ee(account, arg, account2, plan) {
  if (String(account.id) !== String(plan.id) || account.note !== account2.marker || account.username !== account2.username || account.package?.id !== 1 || account.template?.id !== 4779 || !Number.isFinite(Number(arg.credit)) || Number(arg.credit) !== account2.creditBefore || !account.password || !account.dns_link) {
    throw Error("开户资料或余额核验失败");
  }
  let value4 = plan.expiryLabel || account.expiring_at || (account.expiring_at === null ? "Waiting for first login (not activated yet)" : null);
  if (!value4) {
    throw Error("到期时间字段缺失，需核查");
  }
  return {
    id: String(account.id),
    username: account.username,
    password: account.password,
    server: account.dns_link,
    package: "24 Hours",
    template: "test-huberyliu",
    expiryLabel: value4,
    marker: account.note,
    descriptions: plan.descriptions || []
  };
}
function cr({
  data: arg,
  api: arg2 = we(arg),
  timeoutMs: arg3 = 140000
}) {
  fn19(arg, {
    recursive: true
  });
  let value4 = fn20(arg, "megaott-local-key");
  if (!fn18(value4)) {
    fn17(value4, fn12(32).toString("hex"));
  }
  let value5 = fn16(value4, "utf8").trim();
  let value6 = new value3(fn20(arg, "chrome-bridge.sqlite"));
  value6.exec("CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, action TEXT, args TEXT, state TEXT, result TEXT, error TEXT, created_at TEXT, write_dispatched INTEGER NOT NULL DEFAULT 0);");
  if (!value6.prepare("SELECT 1 FROM pragma_table_info('jobs') WHERE name='write_dispatched'").get()) {
    value6.exec("ALTER TABLE jobs ADD COLUMN write_dispatched INTEGER NOT NULL DEFAULT 0");
    value6.exec("UPDATE jobs SET write_dispatched=1 WHERE action IN ('create','edit') AND state IN ('failed','needs_review','running')");
  }
  value6.exec("UPDATE jobs SET state='needs_review',error='bridge restarted during operation' WHERE state IN ('queued','running'); UPDATE jobs SET state='needs_review' WHERE action IN ('create','edit') AND state='failed' AND write_dispatched=1;");
  let job = ie(value6);
  let fn27 = (arg4, arg5) => ae(arg, arg4, arg5);
  let job2 = ne(value6, {
    data: arg,
    maxCreates: 2,
    canExceedLimit: fn27
  });
  let job3 = ue(value6, {
    maxCreates: 1,
    canExceedLimit: fn27
  });
  let job4 = pe(value6, {
    maxCreates: {
      DINO: 2,
      TREX: 1
    },
    canExceedLimit: fn27
  });
  let map = new Map();
  let set = new Set();
  let value7 = 0;
  let value8 = fn20(arg, "chrome-bridge-config.json");
  if (!fn18(value8)) {
    fn17(value8, JSON.stringify({
      mutationsEnabled: false,
      maxCreates: 1,
      maxMacCreates: 1
    }, null, 2));
  }
  let fn28 = () => JSON.parse(fn16(value8, "utf8"));
  let job5 = Ne(value6, {
    timeoutMs: arg3,
    getConfig: fn28,
    canExceedLimit: fn27
  });
  function fn29({
    server: arg4,
    requestId: arg5
  }) {
    if (!["MEGA", "LION", "DINO", "TREX", "STRONG"].includes(arg4) || !/^[A-Za-z0-9-]{8,100}$/.test(arg5 || "")) {
      throw Error("invalid_review_reference");
    }
    if (!oe(arg, arg5, arg4)) {
      throw Error("designated_test_review_required");
    }
    let value10 = "designated test contact reset; archived without retry";
    let value11 = 0;
    value6.exec("BEGIN IMMEDIATE");
    try {
      if (arg4 === "MEGA") {
        value11 += Number(value6.prepare("UPDATE jobs SET state='discarded',error=? WHERE id=? AND action='create' AND state='needs_review'").run(value10, arg5).changes);
        if (value11 === 0) {
          value11 += Number(value6.prepare("UPDATE mega_mag_jobs SET state='discarded',error=? WHERE id=? AND action='create' AND state='needs_review'").run(value10, arg5).changes);
        }
      } else if (arg4 === "LION") {
        value11 = Number(value6.prepare("UPDATE lion_browser_jobs SET state='discarded',error=? WHERE id=? AND action='create' AND state='needs_review'").run(value10, arg5).changes);
      } else if (arg4 === "STRONG") {
        value11 = Number(value6.prepare("UPDATE strong_browser_jobs SET state='discarded',error=? WHERE id=? AND action='create' AND state='needs_review'").run(value10, arg5).changes);
      } else {
        value11 = Number(value6.prepare("UPDATE classic_browser_jobs SET state='discarded',error=? WHERE id=? AND server=? AND action='create' AND state='needs_review'").run(value10, arg5, arg4).changes);
      }
      if (value11 === 0) {
        let value12 = arg4 === "MEGA" ? value6.prepare("SELECT state FROM jobs WHERE id=? AND action='create'").get(arg5) || value6.prepare("SELECT state FROM mega_mag_jobs WHERE id=? AND action='create'").get(arg5) : arg4 === "LION" ? value6.prepare("SELECT state FROM lion_browser_jobs WHERE id=? AND action='create'").get(arg5) : arg4 === "STRONG" ? value6.prepare("SELECT state FROM strong_browser_jobs WHERE id=? AND action='create'").get(arg5) : value6.prepare("SELECT state FROM classic_browser_jobs WHERE id=? AND server=? AND action='create'").get(arg5, arg4);
        if (["queued", "running"].includes(value12?.state)) {
          throw Error("review_job_still_running");
        }
        value6.exec("COMMIT");
        return {
          discarded: true,
          ...(value12 ? {
            alreadySettled: true
          } : {
            jobMissing: true
          })
        };
      }
      value6.exec("COMMIT");
      return {
        discarded: true
      };
    } catch (value12) {
      try {
        value6.exec("ROLLBACK");
      } catch {}
      throw value12;
    }
  }
  let fn30 = () => [["jobs"], ["mega_mag_jobs"], ["strong_browser_jobs"], ["lion_browser_jobs"], ["classic_browser_jobs"], ["panel_jobs"]].some(([arg4]) => value6.prepare("SELECT 1 FROM " + arg4 + " WHERE state='queued' LIMIT 1").get());
  let fn31 = (arg4, arg5) => {
    if (set.delete(arg4)) {
      clearTimeout(arg4.timer);
      arg4.resolve({
        ready: arg5
      });
    }
  };
  let fn32 = () => {
    for (let value10 of [...set]) {
      fn31(value10, true);
    }
  };
  let fn33 = arg4 => fn30() ? Promise.resolve({
    ready: true
  }) : new Promise(arg5 => {
    let options = {
      resolve: arg5,
      timer: null
    };
    options.timer = setTimeout(() => fn31(options, fn30()), arg4);
    set.add(options);
  });
  function fn34(arg4, arg5) {
    if (Date.now() - value7 > 65000) {
      throw Error("Chrome 网页助手尚未连接，请绑定现有后台标签");
    }
    let value10 = fn13();
    if (arg4 === "create") {
      if (!fn28().mutationsEnabled) {
        throw Error("网页开户仍处于禁用状态");
      }
      if (!/^[a-zA-Z0-9-]{8,80}$/.test(arg5.requestId || "")) {
        throw Error("invalid_request_id");
      }
      let value12 = fn27(arg5.requestId, "MEGA");
      if (value12) {
        value6.prepare("UPDATE jobs SET state='discarded',error='designated test contact superseded stale review; no retry performed' WHERE action='create' AND state='needs_review'").run();
      } else if (value6.prepare("SELECT id FROM jobs WHERE action='create' AND state='needs_review'").get()) {
        throw Error("MEGA_CREATE_REQUIRES_RECOVERY");
      }
      value10 = arg5.requestId;
      let job6 = value6.prepare("SELECT * FROM jobs WHERE id=?").get(value10);
      if (job6 && job6.state === "done") {
        return Promise.resolve(JSON.parse(job6.result));
      }
      if (job6 && (job6.state !== "failed" || !!job6.write_dispatched)) {
        throw Error("此开户请求已有记录，禁止重复提交");
      }
      if (!value12 && value6.prepare("SELECT count(*) AS n FROM jobs WHERE action='create' AND (state IN ('done','needs_review') OR write_dispatched=1)").get().n >= fn28().maxCreates) {
        throw Error("本轮网页开户数量上限已达到");
      }
      arg5 = {
        ...arg5,
        username: "T" + fn14("sha256").update(value10).digest("hex").slice(0, 10).toUpperCase(),
        marker: "IPTVBOT-" + value10
      };
    }
    if (arg4 === "edit" && !fn28().mutationsEnabled) {
      throw Error("网页编辑仍处于禁用状态");
    }
    let value11 = value6.prepare("SELECT state,write_dispatched FROM jobs WHERE id=?").get(value10);
    if (value11?.state === "failed" && !value11.write_dispatched) {
      value6.prepare("UPDATE jobs SET action=?,args=?,state='queued',result=NULL,error=NULL,created_at=?,write_dispatched=0 WHERE id=?").run(arg4, JSON.stringify(arg5), new Date().toISOString(), value10);
    } else {
      value6.prepare("INSERT INTO jobs(id,action,args,state,result,error,created_at,write_dispatched) VALUES(?,?,?,?,?,?,?,0)").run(value10, arg4, JSON.stringify(arg5), "queued", null, null, new Date().toISOString());
    }
    return new Promise((arg6, fn36) => {
      let value12 = setTimeout(() => {
        map.delete(value10);
        value6.prepare("UPDATE jobs SET state=?,error='timeout; do not retry' WHERE id=? AND state IN ('queued','running')").run(arg4 === "recover" ? "failed" : "needs_review", value10);
        fn36(Error(arg4 === "recover" ? "只读恢复超时，原开户仍保持待核查" : "浏览器操作超时，已停止重复执行"));
      }, arg3);
      map.set(value10, {
        resolve: arg6,
        reject: fn36,
        timer: value12
      });
    });
  }
  function fn35(arg4) {
    let value10 = Buffer.from(arg4.headers["x-local-key"] || "");
    let value11 = Buffer.from(value5);
    return value10.length === value11.length && fn15(value10, value11);
  }
  let value9 = value2.createServer(async (arg4, arg5) => {
    arg5.setHeader("Cache-Control", "no-store");
    arg5.setHeader("Content-Type", "application/json; charset=utf-8");
    let fn36 = (arg6, arg7) => {
      arg5.writeHead(arg6);
      arg5.end(JSON.stringify(arg7));
    };
    if (arg4.headers.host !== "127.0.0.1:" + value9.address().port) {
      return fn36(403, {
        error: "invalid_host"
      });
    }
    if (arg4.method === "GET" && arg4.url === "/status") {
      return fn36(200, {
        mode: "existing_chrome_tab",
        extensionConnected: Date.now() - value7 < 65000,
        mutationsEnabled: fn28().mutationsEnabled
      });
    }
    if (arg4.method === "GET" && arg4.url === "/panels/status") {
      return fn36(200, job.status());
    }
    if (arg4.method === "GET" && arg4.url === "/strong/status") {
      return fn36(200, job2.status());
    }
    if (arg4.method === "GET" && arg4.url === "/lion/status") {
      return fn36(200, job3.status());
    }
    if (arg4.method === "GET" && arg4.url === "/classic/status") {
      return fn36(200, job4.status());
    }
    if (arg4.method === "GET" && arg4.url === "/mag/status") {
      return fn36(200, job5.status());
    }
    if (!fn35(arg4)) {
      return fn36(403, {
        error: "local authorization required"
      });
    }
    if (arg4.method === "GET" && arg4.url === "/connection-check") {
      return fn36(200, {
        ok: true
      });
    }
    try {
      if (arg4.method === "GET" && arg4.url.startsWith("/wait")) {
        let value13 = Number(new URL(arg4.url, "http://local").searchParams.get("timeout") || 20000);
        if (!Number.isInteger(value13) || value13 < 10 || value13 > 25000) {
          throw Error("invalid_wait_timeout");
        }
        return fn36(200, await fn33(value13));
      }
      if (arg4.method === "GET" && arg4.url.startsWith("/strong/next?")) {
        return fn36(200, job2.next(new URL(arg4.url, "http://local").searchParams.get("version")));
      }
      if (arg4.method === "GET" && arg4.url.startsWith("/lion/next?")) {
        return fn36(200, job3.next(new URL(arg4.url, "http://local").searchParams.get("version")));
      }
      if (arg4.method === "GET" && arg4.url.startsWith("/classic/next?")) {
        let value13 = new URL(arg4.url, "http://local").searchParams;
        return fn36(200, job4.next(value13.get("server"), value13.get("version")));
      }
      if (arg4.method === "GET" && arg4.url.startsWith("/mag/next?")) {
        value7 = Date.now();
        return fn36(200, job5.next(new URL(arg4.url, "http://local").searchParams.get("version")));
      }
      if (arg4.method === "GET" && arg4.url.startsWith("/panels/next?")) {
        return fn36(200, job.next(new URL(arg4.url, "http://local").searchParams.get("server")));
      }
      if (arg4.method === "GET" && arg4.url === "/next") {
        value7 = Date.now();
        if (value6.prepare("SELECT id FROM jobs WHERE state='running'").get()) {
          return fn36(200, {
            job: null
          });
        }
        let value13 = value6.prepare("SELECT * FROM jobs WHERE state='queued' ORDER BY created_at LIMIT 1").get();
        if (value13) {
          value6.prepare("UPDATE jobs SET state='running' WHERE id=?").run(value13.id);
          return fn36(200, {
            job: {
              id: value13.id,
              action: value13.action,
              args: JSON.parse(value13.args)
            }
          });
        } else {
          return fn36(200, {
            job: null
          });
        }
      }
      if (arg4.method !== "POST") {
        return fn36(404, {
          error: "route"
        });
      }
      let value10 = "";
      for await (let value13 of arg4) {
        value10 += value13;
        if (value10.length > 500000) {
          throw Error("request_too_large");
        }
      }
      let server = JSON.parse(value10 || "{}");
      if (arg4.url === "/discard-review") {
        return fn36(200, fn29(server));
      }
      if (arg4.url === "/strong/result") {
        return fn36(200, job2.result(server));
      }
      if (["/strong/recover", "/strong/prepare", "/strong/create", "/strong/inspect", "/strong/edit"].includes(arg4.url)) {
        let value13 = job2.enqueue(arg4.url.split("/").at(-1), server);
        fn32();
        return fn36(200, await value13);
      }
      if (arg4.url === "/lion/result") {
        return fn36(200, job3.result(server));
      }
      if (["/lion/recover", "/lion/prepare", "/lion/create", "/lion/inspect", "/lion/edit"].includes(arg4.url)) {
        let value13 = job3.enqueue(arg4.url.split("/").at(-1), server);
        fn32();
        return fn36(200, await value13);
      }
      if (arg4.url === "/classic/result") {
        return fn36(200, job4.result(server));
      }
      if (["/classic/recover", "/classic/prepare", "/classic/create", "/classic/inspect", "/classic/edit"].includes(arg4.url)) {
        let value13 = job4.enqueue(arg4.url.split("/").at(-1), server);
        fn32();
        return fn36(200, await value13);
      }
      if (arg4.url === "/mag/result") {
        return fn36(200, job5.result(server));
      }
      if (["/mag/prepare", "/mag/create", "/mag/inspect", "/mag/edit", "/mag/recover"].includes(arg4.url)) {
        let value13 = job5.enqueue(arg4.url.split("/").at(-1), server);
        fn32();
        return fn36(200, await value13);
      }
      if (arg4.url === "/panels/prepare") {
        let value13 = job.enqueue(server.server);
        fn32();
        return fn36(200, await value13);
      }
      if (arg4.url === "/panels/result") {
        return fn36(200, job.result(server));
      }
      if (arg4.url === "/dispatched") {
        let job6 = value6.prepare("SELECT action,state FROM jobs WHERE id=?").get(server.id);
        if (!job6) {
          throw Error("unknown_job");
        }
        if (!["create", "edit"].includes(job6.action) || job6.state !== "running") {
          throw Error("write_dispatch_state_invalid");
        }
        value6.prepare("UPDATE jobs SET write_dispatched=1 WHERE id=?").run(server.id);
        return fn36(200, {
          recorded: true
        });
      }
      if (arg4.url === "/result") {
        let job6 = value6.prepare("SELECT * FROM jobs WHERE id=?").get(server.id);
        if (!job6) {
          throw Error("unknown_job");
        }
        if (job6.state === "done" || job6.state === "failed") {
          return fn36(200, {
            received: true
          });
        }
        if (job6.state !== "running") {
          throw Error("late_result_requires_review");
        }
        let value13 = JSON.parse(job6.args);
        let value14 = server.result;
        let value15 = server.error;
        let value16 = !!job6.write_dispatched || !!server.writeDispatched || !value15 && !!["create", "edit"].includes(job6.action) && !!value14;
        if (!value15 && job6.action === "create") {
          try {
            let result = await arg2.read(value14.id);
            let result2 = await arg2.user();
            value14 = {
              account: ee(result, result2, value13, value14)
            };
          } catch (value19) {
            value15 = value19.message;
          }
        }
        let value17 = value15 ? ["create", "edit"].includes(job6.action) && value16 ? "needs_review" : "failed" : "done";
        value6.prepare("UPDATE jobs SET state=?,result=?,error=?,write_dispatched=? WHERE id=?").run(value17, JSON.stringify(value14 || null), value15 || null, value16 ? 1 : 0, job6.id);
        let value18 = map.get(job6.id);
        if (value18) {
          clearTimeout(value18.timer);
          map.delete(job6.id);
          if (value15) {
            value18.reject(Error(value15));
          } else {
            value18.resolve(value14);
          }
        }
        return fn36(200, {
          received: true
        });
      }
      if (arg4.url === "/recover") {
        if (!/^[a-zA-Z0-9-]{8,80}$/.test(server.requestId || "")) {
          throw Error("invalid_request_id");
        }
        let job6 = value6.prepare("SELECT * FROM jobs WHERE id=? AND action='create' AND state='needs_review'").get(server.requestId);
        if (!job6) {
          throw Error("MEGA_RECOVERY_RECORD_REQUIRED");
        }
        let account = JSON.parse(job6.args);
        let value13 = JSON.parse(job6.result || "null");
        if (!value13?.id) {
          let value15 = fn34("recover", {
            requestId: server.requestId,
            username: account.username,
            marker: account.marker
          });
          fn32();
          value13 = await value15;
        }
        if (!value13?.id) {
          throw Error("MEGA_RECOVERY_ID_UNAVAILABLE");
        }
        let result = await arg2.read(value13.id);
        let result2 = await arg2.user();
        let value14 = ee(result, result2, account, value13);
        value6.prepare("UPDATE jobs SET state='done',result=?,error=NULL WHERE id=? AND state='needs_review'").run(JSON.stringify({
          account: value14,
          recovered: true
        }), job6.id);
        return fn36(200, {
          account: value14,
          recovered: true
        });
      }
      let value11 = arg4.url.slice(1);
      if (!["prepare", "inspect", "create", "edit"].includes(value11)) {
        return fn36(404, {
          error: "route"
        });
      }
      if (value11 === "inspect" && !/^\d+$/.test(String(server.id))) {
        throw Error("invalid_id");
      }
      if (value11 === "edit") {
        let account = server.account;
        if (!account?.id || !account.marker?.startsWith("IPTVBOT-")) {
          throw Error("missing_account_binding");
        }
        let result = await arg2.read(account.id);
        if (result.username !== account.username || result.note !== account.marker || result.package?.id !== 1) {
          throw Error("账号归属或试用套餐不匹配");
        }
      }
      if (value11 === "prepare" || value11 === "create") {
        let result = await arg2.user();
        if (typeof result.username != "string" || !result.username.trim() || !Number.isFinite(Number(result.credit))) {
          throw Error("account_mismatch");
        }
        if (value11 === "create") {
          server.creditBefore = Number(result.credit);
        }
      }
      let value12 = fn34(value11, server);
      fn32();
      return fn36(200, await value12);
    } catch (value10) {
      return fn36(400, {
        error: String(value10.message).slice(0, 500)
      });
    }
  });
  return {
    server: value9,
    close: () => {
      job5.close();
      job2.close();
      job3.close();
      job4.close();
      job.close();
      for (let value10 of map.values()) {
        clearTimeout(value10.timer);
        value10.reject(Error("bridge_closed"));
      }
      map.clear();
      for (let value10 of [...set]) {
        fn31(value10, false);
      }
      value9.close();
      value6.close();
    }
  };
}
if (process.env.IPTV_RUNTIME_ENTRY === "chrome-bridge.mjs" || !process.env.IPTV_RUNTIME_ENTRY && process.argv[1] && fn21(import.meta.url) === process.argv[1]) {
  let e = cr({
    data: fn21(new URL("../data/", import.meta.url))
  });
  e.server.listen(3212, "127.0.0.1", () => console.log("Existing Chrome bridge listening on 127.0.0.1:3212; browser not launched"));
  process.on("SIGINT", () => e.close());
}
export { cr as createChromeBridge };